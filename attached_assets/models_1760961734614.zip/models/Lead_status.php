<?php

class Lead_status extends Title_description
{
    static $connection='smart_real_estate';
    static $table='lead_statuses';
    static $title="Lead Status";
   

}