<?php
class Reservation_cancellation extends pPort_model
{
    static $table = 'enquiries_reservation_cancellations';
    static $title = "Reservation";
    static $description = "(Record reservations)";
    static $connection = 'smart_real_estate';
    static $before_save = ["check_reservation_uniqueness", "add_account_creator", "add_meta_data"];
    static $after_save = ["update_enquiry_status", "update_unit_status"];
    static $belongs_to = [
        'enquiry' => ['enquiry', 'class_name' => 'Enquiry', 'foreign_key' => 'enquiry_id']
    ];

    public function update_unit_status()
    {
        $unit = Unit::find($this->unit_id);
        if ($this->cancelled) {
            $unit->status = "available";
        } else {
            $unit->status = "reserved";
        }
        $unit->save();
    }

    public function update_enquiry_status()
    {
        $enquiry = Enquiry::find($this->enquiry_id);
        if ($this->cancelled) {
            $enquiry->status = "reservation_cancelled";
        } else {
            $enquiry->status = "reserved";
        }
        $enquiry->save();
    }

    public function check_reservation_uniqueness()
    {
        if ($this->cancelled) {
            return;
        }
        $reservation = Sale_interest::last(['conditions' => ['unit_id=? AND cancelled=0', $this->unit_id]]);
        if ($reservation) {
            if ($reservation->enquiry_id != $this->enquiry_id) {

                exit(json_encode(['info' => 'error', 'message' => 'Unit is already reserved for another client.']));
            }
        }
    }

    public function add_meta_data()
    {
        $unit = Unit::find($this->unit_id);
        $this->apartment_id = $unit->apartment_id;
        $this->project_id = $unit->project_id;
        $this->court_id = $unit->court_id;
        $this->block_id = $unit->block_id;
    }


    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "enquiry_id" => array(
                    "label" => "Enquiry Lead", "required" => true, "model" => array(
                        "Enquiry", "id", array("name"),
                        [
                            'prepend' => ['' => '-Select Lead-'],
                            'conditions' => ['account_id=?', Acl_user::account_id()]
                        ]
                    )
                ),
                "reservation_date" => array("label" => "Reservation Date", "format" => "date", "required" => true, "type" => "date"),
                "unit_id" => array("label" => "Unit", 'required' => true, 'model' => array(
                    'Unit', 'id',
                    ['title'], ["prepend" => ["" => "-Select Unit-"], 'conditions' => ['account_id=?', Acl_user::account_id()], "prepend" => ["0" => "--Unit--"]]
                )),

            ),
            "conditions" => array("account_id=? AND cancelled=?", Acl_user::account_id(), 0),
            "grid_actions" => static::grid_actions(),
            'form_actions' => static::form_actions(),
            "form" => static::form_attrs(),

        );
        return $config;
    }

    public static function config_active($vars)
    {
        $status = arr('status', $vars, 'open');


        $grid_actions = [
            'cancel' => [
                'text' => 'Cancel',
                'href' => Url::form_panel('Reservation/{@id}/config/cancel')

            ]
        ];
        $config = static::config($vars);
        $config['grid_actions'] = $grid_actions;
        return $config;
    }

    public static function config_cancelled($vars)
    {
        return static::config_cancel($vars);
    }

    public static function config_cancel($vars)
    {
        return array(
            "fields" => array(
                "enquiry_id" => array(
                    "label" => "Enquiry Lead", "required" => true, "model" => array(
                        "Enquiry", "id", array("name"),
                        [
                            'prepend' => ['' => '-Select Lead-'],
                            'conditions' => ['account_id=?', Acl_user::account_id()]
                        ]
                    )
                ),
                "reservation_date" => array("label" => "Reservation Date", "format" => "date", "required" => true, "type" => "date"),
                "unit_id" => array("label" => "Unit", 'required' => true, 'model' => array(
                    'Unit', 'id',
                    ['title'], ["prepend" => ["" => "-Select Unit-"], 'conditions' => ['account_id=?', Acl_user::account_id()], "prepend" => ["0" => "--Unit--"]]
                )),
                "cancelled" => array("label" => "Is Cancelled?", 'required' => true, 'params' => array("0" => "No", "1" => "Yes")),
                "date_cancelled" => array("label" => "Date Cancelled", 'type' => 'date'),
            ),
            "conditions" => array("account_id=? AND cancelled=?", Acl_user::account_id(), 1),
            "grid_actions" => [],
            'form_actions' => static::form_actions(['save']),
            "form" => static::form_attrs(['window_location' => Url::form_panel('Reservation/' . static::$model_id . '/config/cancel')]),

        );
    }

    public static function config_interest($vars)
    {
        return array(
            "fields" => array(
                "enquiry_id" => array(
                    "label" => "Enquiry Lead", "required" => true, "model" => array(
                        "Enquiry", "id", array("name"),
                        [
                            'prepend' => ['' => '-Select Lead-'],
                            'conditions' => ['account_id=?', Acl_user::account_id()]
                        ]
                    )
                ),
                "reservation_date" => array("label" => "Reservation Date", "format" => "date", "required" => true, "type" => "date"),
                "unit_id" => array("label" => "Unit", 'required' => true, 'model' => array(
                    'Unit', 'id',
                    ['title'], ["prepend" => ["" => "-Select Unit-"], 'conditions' => ['account_id=?', Acl_user::account_id()], "prepend" => ["0" => "--Unit--"]]
                )),
                "cancelled" => array("label" => "Is Cancelled?", 'required' => true, 'params' => array("0" => "No", "1" => "Yes")),
                "date_cancelled" => array("label" => "Date Cancelled", 'type' => 'date'),
            ),
            "conditions" => array("account_id=? AND cancelled=?", Acl_user::account_id(), 1),
            "grid_actions" => static::grid_actions(),
            'form_actions' => static::form_actions(),
            "form" => static::form_attrs(),

        );
    }





    public function listener_date_cancelled($params)
    {
        if ($params['is_active'] == 1) {
            return date('Y-m-d');
        } else {
            return NULL;
        }
    }


    public static function summary_panels()
    {
        return [
            'customer_type' => [
                'title' => 'By Customer Type',
                'entity' => 'Customer_type'
            ],
            'lead_source' => [
                'title' => 'By Lead Source',
                'entity' => 'Lead_source'
            ],
            'project' => [
                'title' => 'By Project',
                'entity' => 'Project'
            ],
            'court' => [
                'title' => 'By Court',
                'entity' => 'Court'
            ],
            'block' => [
                'title' => 'By Block',
                'entity' => 'Block'
            ],
            'apartment' => [
                'title' => 'By Apartment',
                'entity' => 'Apartment'
            ],
            'agent' => [
                'title' => 'By Agent',
                'entity' => 'Agent'
            ]
        ];
    }
}