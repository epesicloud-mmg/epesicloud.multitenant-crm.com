<?php

/**
 * Handles User lead_activities
 *
 * User Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Priority_level extends pPort_model
{

    static $table = 'priority_levels';
    static $name = 'Priority Levels';
    static $before_save = array('add_account');
    static $connection = 'smart_real_estate';



    public static function fields_config()
    {
        return array(
            "title" => array("label" => "Type Name"),
            "description" => array("label" => "Description", "type" => "textarea"),

        );
    }



    public static function config($vars = [])
    {
        return array(
            "fields" => static::fields(),
            "colspan" => 6,
            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions(),
            "form" => static::form_attrs(),
        );
    }
}