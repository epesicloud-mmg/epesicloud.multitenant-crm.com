<?php
class Kpi_invoice extends Title_description
{
    static $connection='smart_real_estate';
    static $table='kpi_invoices';
    static $title="KPI Invoice";
    static $description="(KPI Invoices)";
    static $belongs_to=[
        "kpi_user"=>[
            "kpi_user",
            "class_name"=>"Kpi_user",
            "foreign_key"=>"kpi_user_id"
        ]
    ];
    public static $before_save=[
        "calculate_rewardable_amount",
        "calculate_commissionable_amount",
        "calculate_commission"
    ];

    public function calculate_rewardable_amount()
    {
        $this->rewardable_amount=$this->rewardable_percentage*0.01*$this->set_target;
    }

    public function calculate_commissionable_amount()
    {
        $this->commissionable_amount=$this->rewardable_amount-$this->target_achieved;
    }

    public function calculate_commission()
    {
        $this->commission_amount=$this->commissionable_amount*$this->commission_rate*0.01;
    }

    public function get_month_year()
    {
        return date("Y-m",strtotime($this->year."-".$this->month."-01"));
    }
    

    public static function config($vars=[])
    {
        return array(
            "before_form"=>function($result){
                if($result->id)
                {
                    return "<a target='_blank' href='".Url::portlet('main/component_panel/Kpi_invoice/print/'.$result->id)."'> Preview Invoice</a>";
                }                
            },
            "fields"=>array(
                //Is this necessarily for agents,supervisors
                "kpi_user_id"=>array("label"=>"Personnel Name","required"=>true,"enable_quick_entry"=>true,"model"=>["Kpi_user","id",["first_name","last_name"]]),
                "bill_to"=>array("label"=>"Bill To","main"=>Session::user()->account->title,"required"=>true),
                "year"=>array("label"=>"Year","params"=>years(),"required"=>true),
                "month"=>array("label"=>"Month","params"=>months(),"required"=>true),
                "set_target"=>array("label"=>"Set Target","required"=>true),
                "target_achieved"=>array("label"=>"Target Achieved","required"=>true),
                "rewardable_percentage"=>array("label"=>"Rewardable (%)","params"=>["80"=>"80%"]),
                "commission_rate"=>array("label"=>"Commission Rate (%)","type"=>"number","main"=>1,"required"=>true)
            ),
            "form"=>static::form_attrs(),
            "grid_actions"=>[
                "edit"=>["label"=>"Edit","href"=>Url::batch_panel("Kpi_invoice/{@id}")],
                "preview"=>["label"=>"Preview","target"=>"blank","href"=>Url::component("Kpi_invoice/print/{@id}")],
            ],
        );
    }
    
}