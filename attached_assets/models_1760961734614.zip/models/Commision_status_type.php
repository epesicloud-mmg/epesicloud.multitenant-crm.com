<?php
/**
 *
 * @author <Martin Muriithi> <martin@pporting.org>
 */
class Commision_status_type extends Title_description
{

    static $table="commision_status_types";
    static $primary_key="id";
    static $connection = 'smart_real_estate';
    static $title='Status Type';
    static $description='Status Type';
}

?>