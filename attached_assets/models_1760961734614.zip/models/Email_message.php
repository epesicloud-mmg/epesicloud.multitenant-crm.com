<?php
class Email_message extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'email_messages';
    static $title = "Email Message";
    static $before_save = ["add_agent_id","add_message_date", "send_email"];
    static $after_create = ["add_lead_activity"];

    function add_message_date()
    {
        $this->email_message_date=$this->email_message_date??date("Y-m-d H:i:s");
    }


    function add_lead_activity()
    {
        Lead_activity::create([
            'enquiry_id' => $this->enquiry_id,
            'followup_type_id' => Lead_activity_type::alias_id_or_create("email"),
            'description' => $this->body,
            'linked_entity' => 'Email_message',
            'linked_entity_reference' => $this->id,
            "account_id" => $this->account_id,
            'agent_id' => $this->agent_id,
            'followup_date' => date("Y-m-d",strtotime($this->email_message_date)),
            'followup_time' => $this->email_message_date
        ]);
    }


    function send_email()
    {
        $agent = Agent::find($this->agent_id);
        $enquiry = Enquiry::find($this->enquiry_id);
        if ($enquiry->email || $this->to_email) {
            $attachments = [];
            $mail_response = Mail::send([
                'body' => $this->body,
                'mail_template_id' => $this->mail_template_id,
                'to' => $this->to_email,
                'subject' => $this->subject,
                'from' => $this->from_email,
                'from_name' => $agent->first_name . " " . $agent->last_name,
                'attachments' => $attachments,
                'meta_data' => $enquiry->to_array()
            ]);
            $this->mailer_response = $mail_response;
        } else {
            json_error("Could not send. Ensure the lead has a valid e-mail on their account");
        }
    }



    function add_agent_id()
    {
        if (!$this->agent_id) {
            $user = Session::user();
            $this->agent_id = $user->id;
            $this->supervisor_id = $user->supervisor_id;
        }
    }

    public static function config($vars = [])
    {

        $body = NULL;
        if (isset($_REQUEST['enquiry_id'])) {
            $enquiry = Enquiry::find($_REQUEST['enquiry_id']);
            $_REQUEST['to'] = $enquiry->email;
        }
        if (isset($_REQUEST['mail_template_id'])) {
            $mail_template = Mail_template::find($_REQUEST['mail_template_id']);
            $body = $mail_template->body;
        }
        $config_data = [
            'fields' => [
                "mail_template_id" => array("label" => "Mail Template", "model" => ["Mail_template", "id", "subject"]),
                'from_email' => ['label' => 'From', "readonly" => true, "required" => true, "value" => Session::user("email")],
                'to_email' => ['label' => 'To', "required" => true, "value" => arr("to", $_REQUEST, NULL)],
                'subject' => ['label' => 'Subject', "required" => true],
                'body' => ['label' => 'Body', "type" => "textarea", "required" => true],
                "enquiry_id" => array("label" => "Select Lead", "model" => ["Enquiry", "id", "name", ["prepend" => ["" => "-Select Client-"], "conditions" => ["account_id=?", Acl_user::account_id()]]]),
            ],
            "form_actions" => static::form_actions(["save"]),
            "conditions" => ['account_id=?', Session::user('account_id')],
        ];

        if (isset($_REQUEST['enquiry_id'])) {
            $config_data['before_form'] = function ($result) {
                if (isset($_REQUEST['enquiry_id'])) {
                    $enquiry = Enquiry::find($_REQUEST['enquiry_id']);
                    echo "Send an E-mail to : " . $enquiry->name;
                }
            };
            $config_data['fields']['enquiry_id'] = ['label' => "Select Lead", "type" => "hidden", "value" => $_REQUEST['enquiry_id']];
        }
        return $config_data;
    }
}
