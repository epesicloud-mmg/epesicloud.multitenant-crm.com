<?php
class Batch_enquiry_agent_rollback extends pPort_model
{
    static $table = 'batch_enquiry_agent_rollbacks';
    static $after_create = ["roll_back_leads"];
    //static $after_create=["reassign_leads","send_sms"];
    static $connection = 'smart_real_estate';

    function roll_back_leads()
    {
        $batch_enquiry_agent = Batch_enquiry_agent::find($this->batch_enquiry_agent_id);
        $enquiries = Enquiry::all(["conditions" => ["batch_enquiry_agent_id=? AND 
        account_id=?", $this->batch_enquiry_agent_id, Acl_user::account_id()]]);
        vd(count($enquiries));

        $reassigned_leads_count = 0;
        foreach ($enquiries as $enquiry) {
            $assignment_created = Enquiry_account_executive::create(
                [
                    "enquiry_id" => $enquiry->id,
                    "agent_id" => $batch_enquiry_agent->from_agent_id,
                    "date_assigned" => date("Y-m-d"),
                    "is_active" => 1,
                    "description" => "Rollback Re-assignment",
                    "is_reassignment" => 1,
                    "reassignment_from_id" => $batch_enquiry_agent->to_agent_id,
                    "account_id" => $this->account_id,
                    "batch_enquiry_agent_id" => $batch_enquiry_agent->id,
                    "batch_enquiry_agent_rollback_id" => $this->id,
                ]
            );

            if ($assignment_created) {
                $reassigned_leads_count += 1;
            }

            /**$enquiry->agent_id = $batch_enquiry_agent->from_agent_id;
            $enquiry->batch_enquiry_agent_rollback_id = $this->id;
            $enquiry->save();
            $this->from_agent_id = $batch_enquiry_agent->to_agent_id;
            $this->to_agent_id = $batch_enquiry_agent->from_agent_id;
            $this->save();**/
        }
        Enquiry_account_executive::update_all([
            "set" => ["deleted" => 1],
            ["conditions" => "batch_enquiry_agent_id=? AND account_id=?", $batch_enquiry_agent->id, Acl_user::account_id()]
        ]);
        $batch_enquiry_agent->is_rolled_back = 1;
        $batch_enquiry_agent->save();
    }

    public static function config($vars = [])
    {
        $reassignment_from_id = arr('from_id', $vars, NULL);
        $is_reassignment = $reassignment_from_id ? 1 : 0;

        return array(
            "fields" => array(
                "batch_enquiry_agent_id" => array("label" => "From Account Executive", "required" => true, "model" => [
                    "Batch_enquiry_agent", 'id', ['title', 'actual_reassigned_leads'],
                    [
                        'prepend' => ["" => "-Select Account Exec-"],
                        'conditions' => ["account_id=?", Acl_user::account_id()],
                        'order' => 'id DESC'
                    ]
                ]),
                //"leads_rolled_back"=>array("label"=>"Leads Rolled Back"),
            ),

        );
    }
}