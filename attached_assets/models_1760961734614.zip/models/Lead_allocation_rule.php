<?php
class Lead_allocation_rule extends Acl_report
{
    static $title = "Lead Auto Allocation Rules";


    public static function config($vars = [])
    {
        $config_data = parent::config($vars);
        $config_data["fields"]["report_entity"] = [
            'label' => 'Data Entity',
            "onchange" => static::select_refresh("report_entity"), "prepend" => [
                "" => "-Select Item-"
            ], 'params' => Portlet::models()
        ];

        $config_data['fields']['report_entity'] = ["label" => "Lead Entity", "readonly" => true, "value" => arr("report_entity", $_GET)];

        $config_data['fields']["agent_id"] = ["label" => "Agent", "required" => true, "model" => ["Agent", "id", ["first_name", "last_name"]]];

        //$config_data['fields']['category_id']=["label"=>"Category","model"=>["Acl_report_category","id","title"]];

        return $config_data;
    }
}