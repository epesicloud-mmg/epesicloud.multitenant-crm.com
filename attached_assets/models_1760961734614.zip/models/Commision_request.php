<?php

class Commision_request extends pPort_Model
{
    static $table = 'commision_requests';
    static $title = "Commision";
    static $connection = 'smart_real_estate';
    static $before_save = ['add_parent_units', 'add_supervisor_id'];
    static $belongs_to = [
        "sale_interest" => ["sale_interest", "class_name" => "Sale_interest", "foreign_key" => "sale_interest_id"],
        "agent" => ["agent", "class_name" => "Agent", "foreign_key" => "agent_id"],
        "developer_company" => ["developer_company", "class_name" => "Developer_company", "foreign_key" => "developer_company_id"]
    ];


    public function add_supervisor_id()
    {
        if ($this->agent_id) {
            $agent = Agent::find($this->agent_id);
            $this->supervisor_id = $agent->supervisor_id;
        }
    }

    public function add_parent_units()
    {
        $unit = Unit::find($this->unit_id);
        if ($unit) {
            foreach (['project_id', 'unit_group_id', 'court_id', 'apartment_id'] as $field) {
                $this->{$field} = $unit->{$field};
            }
        }
    }


    public static function config_approved($vars)
    {
        $config = static::config($vars);
        $config['conditions'] = array("account_id=? AND deleted=? AND is_approved=0", Acl_user::account_id(), 0);
        $config['grid_actions'] = [
            "approve" => [
                "href" => Url::form_panel("Commission_request/{@id}/c/approver")
            ]
        ];
        $config["fields"]["is_approved"] = ['label' => 'Status', 'params' => [
            "0" => "Pending",
            "1" => "Approved",
            "2" => "Rejected",
        ]];
        return $config;
    }


    public static function config_approver()
    {
        $config = static::config($vars);
        $config['conditions'] = array("account_id=? AND deleted=? AND is_approved=0", Acl_user::account_id(), 0);
        $config['grid_actions'] = [
            "approve" => [
                "label" => "Approve",
                "href" => Url::form_panel("Commission_request/{@id}/c/approver")
            ]
        ];
        $config["fields"]["is_approved"] = ['label' => 'Approved Status', 'params' => [
            "0" => "Pending",
            "1" => "Approved",
            "2" => "Rejected",
        ]];
        return $config;
    }


    public static function config_supervisor($vars = [])
    {
        $config_data = static::config($vars);
        $config_data['grid_actions'] = [
            "agent_print" => [
                "href" => function ($result) {
                    $unpaid_amount = Commision_request::sum(['sum' => 'commision_amount', 'conditions' => ['supervisor_id=? AND is_paid=0', $result->supervisor_id]]);
                    if ($unpaid_amount > 0) {
                        return Url::portlet("main/component/Commision_request/invoice/" . $result->id . "?supervisor_id=" . $result->supervisor_id);
                    } else {
                        return "javascript:alert('There are currently no unpaid commissions. Cannot generate invoice.')";
                    }
                },
                //"href"=>Url::portlet("main/component/Commision_request/invoice/{@id}?supervisor_id={@supervisor_id}"),
                "target" => function ($result) {
                    $unpaid_amount = Commision_request::sum(['sum' => 'commision_amount', 'conditions' => ['supervisor_id=? AND is_paid=0', $result->supervisor_id]]);
                    if ($unpaid_amount > 0) {
                        return "blank";
                    } else {
                        return "_self";
                    }
                },
                "text" => "Print Commission",
                "label" => "Print Commission"
            ]
        ];

        $config_data['fields']['paid_amount'] = array("label" => "Paid Amount", "value" => function ($result) {
            return Commision_request::sum(['sum' => 'commision_amount', 'conditions' => ['supervisor_id=? AND is_paid=1', $result->supervisor_id]]);
        }, "required" => true);
        $config_data['fields']['unpaid_amount'] = array("label" => "Unpaid Amount", "value" => function ($result) {
            return Commision_request::sum(['sum' => 'commision_amount', 'conditions' => ['supervisor_id=? AND is_paid=0', $result->supervisor_id]]);
        }, "required" => true);
        $config_data["fields"]['supervisor_id'] = array(
            "label" => "Supervisor", 'required' => true,
            'model' => array(
                'Acl_user', 'id',
                ['first_name', 'last_name'],
                [
                    "conditions" => ['role_id=?', Role::alias_id("supervisor")],
                    "prepend" => ["0" => "--Supervisor--"]
                ]
            )
        );

        unset($config_data["fields"]["commision_amount"]);
        unset($config_data["fields"]["agent_id"]);
        $config_data['conditions'] = ["account_id=?", Session::user("account_id")];
        $config_data['group'] = 'supervisor_id';
        $config_data['group_by'] = 'supervisor_id';
        array_reverse($config_data);
        return $config_data;
    }



    public static function config_agent($vars = [])
    {
        $config_data = static::config($vars);
        $config_data['grid_actions'] = [
            "agent_print" => [
                "href" => function ($result) {
                    $unpaid_amount = Commision_request::sum(['sum' => 'commision_amount', 'conditions' => ['agent_id=? AND is_paid=0', $result->agent_id]]);
                    if ($unpaid_amount > 0) {
                        $last_commision = Commision_request::last(['conditions' => ['agent_id=? AND is_paid=0', $result->agent_id]]);
                        return Url::portlet("main/component/Commision_request/invoice/" . $last_commision->id);
                    } else {
                        return "javascript:alert('There are currently no unpaid commissions. Cannot generate invoice.')";
                    }
                },
                "target" => function ($result) {
                    $unpaid_amount = Commision_request::sum(['sum' => 'commision_amount', 'conditions' => ['agent_id=? AND is_paid=0', $result->agent_id]]);
                    if ($unpaid_amount > 0) {
                        return "blank";
                    } else {
                        return "_self";
                    }
                },
                "text" => "Print Commission",
                "label" => "Print Commission"
            ]
        ];

        /**$config_data['fields']['paid_amount']=array("label"=>"Paid Amount","value"=>function($result){
            return Commision_request::sum(['sum'=>'commision_amount','conditions'=>['agent_id=? AND is_paid=1',$result->agent_id]]);
        },"required"=>true);
        $config_data['fields']['unpaid_amount']=array("label"=>"Unpaid Amount","value"=>function($result){
            return Commision_request::sum(['sum'=>'commision_amount','conditions'=>['agent_id=? AND is_paid=0',$result->agent_id]]);
        },"required"=>true);**/
        //unset($config_data["fields"]["commision_amount"]);
        $config_data['conditions'] = ["account_id=?", Session::user("account_id")];
        $config_data['group'] = 'agent_id';
        $config_data['group_by'] = 'agent_id';


        return $config_data;
    }

    public static function fields_config()
    {
        if (Session::user()->role->alias == "agent") {
            $agent_condition = ["role_id=? AND id=" . Session::user("id") . " AND account_id=? AND deleted=0", Role::alias_id('agent'), Acl_user::account_id()];
        } else {
            $agent_condition = ["role_id=? AND account_id=? AND deleted=0", Role::alias_id('agent'), Acl_user::account_id()];
        }
        return array(

            "agent_id" => array(
                "label" => "Agent", 'required' => true,
                'model' => array(
                    'Acl_user', 'id',
                    ['first_name', 'last_name'],
                    [
                        "conditions" => $agent_condition,
                        "prepend" => ["0" => "--Assigned Agent--"]
                    ]
                )
            ),
            "commision_amount" => array("label" => "Commission Amount", "required" => true),
            "name" => array("label" => "Client Name"),
            "email" => array("label" => "Client Email"),
            "phone" => array("label" => "Client Phone"),

            "sale_price" => array("label" => "Sale Price", "readonly" => true, "required" => true),
            "deposit" => array("label" => "Client Deposit", "required" => true),
            "total_paid_to_date" => array("label" => "Total Paid to-date ", "required" => true),
            "cash_price" => array("label" => "Cash Price", "required" => true),
            "lease_type" => array("label" => "Lease Type", "params" => ["for_sale" => "For Sale", "for_rent" => "For Rent"], "required" => true),
            "developer_company_id" => array("label" => "Company Unit", "required" => true, "model" => ["Developer_company", "id", "name"]),

        );
    }


    public static function config($vars = [])
    {




        return array(
            "fields" => static::fields(),
            "grid_fields" => static::fields(["lease_type"], false),
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),
            "order" => "id DESC",
            'form_actions' => static::form_actions(['save']),
            'grid_actions' => [],
            "form" => static::form_attrs(["window_location" => Url::grid_panel("Commision_request")])
        );
    }

    public static function workflow_config()
    {
        return [
            'verified' => [
                'editor_roles' => ['supervisor', 'admin'],
                'permitted_roles' => ['admin', 'supervisor'],
                "condition" => "is_verified=0 AND is_commision_declined=0",
                'pending_label' => 'Pending Supervisor',
                "shared_stages" => ["commision_declined"]
            ],
            'approved_by_manager' => [
                'editor_roles' => ['admin'],
                'pending_label' => 'Pending Manager',
                "condition" => "is_verified=1  AND is_commision_declined=0",
                "do_label" => "Approve Commission",
                "shared_stages" => ["commision_declined"]
            ],
            'commision_declined' => [
                'editor_roles' => [],
                'pending_label' => 'Declined Commissions',
                "condition" => "is_approved_by_manager=0",
                "do_label" => "Decline Commission"
            ],
            'paid' => [
                'editor_roles' => ['accountant','admin'],
                'pending_label' => 'Unpaid Commissions',
                "do_label" => "Pay Commission",
                "condition" => "is_commision_declined=0 AND is_approved_by_manager=1",
            ],
            /**'supervisor_paid' => [
                'editor_roles' => ['admin'],
                'pending_label' => 'Unpaid Supervisor Comms.',
                "do_label" => "Pay Supervisor",
                "condition" => "is_commision_declined=0 AND is_approved_by_manager=1",
            ],
            'manager_paid' => [
                'editor_roles' => ['admin'],
                'pending_label' => 'Unpaid Manager Comms.',
                "do_label" => "Pay Supervisor",
                "condition" => "is_commision_declined=0 AND is_approved_by_manager=1",
            ]**/
        ];
    }
}