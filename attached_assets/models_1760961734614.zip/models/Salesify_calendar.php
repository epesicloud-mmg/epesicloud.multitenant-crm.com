<?php

class Salesify_calendar_event_type extends pPort_model
{
    static $connection='smart_real_estate';
    static $table='calendar_event_types';
    static $title="Calendar";
    static $description="(Events Calendar)";
    
    

    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "title"=>array("label"=>"Title","required"=>true),                
                "start"=>array("required"=>true,"label"=>"Start","type"=>"date"),
                "end"=>array("label"=>"End","required"=>true,"type"=>"date"),
                "description"=>array("label"=>"Description","required"=>true),
            ),
        );
    }
}