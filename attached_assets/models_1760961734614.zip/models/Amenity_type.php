<?php
class Amenity_type extends Title_description
{
    static $connection='smart_real_estate';
    static $table='amenity_types';
    static $title="Amenity Type";
    static $has_many=[
       'amenities'=>['amenities','class_name'=>'Amenity','foreign_key'=>'amenity_type_id'],
    ];
}