<?php
/**
 * @author Martin Muriithi <martin@pporting.org>
 *
 *
 **/
class Location extends Title_description
{
    static $connection='smart_real_estate';
    static $table='locations';
    static $name="Location";

    public static function bulk_action_test($bulk_entries,$bulk_action_entity)
    {
        vd($bulk_action_entity);
    }
    
}