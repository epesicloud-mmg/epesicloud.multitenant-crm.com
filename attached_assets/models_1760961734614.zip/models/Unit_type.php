<?php

/**
 * Handles User to Groups Many-to-many Lead_activitys
 *
 * User_group Model
 * @author Martin Muriithi <martin@pporting.org>
 *
 *
 **/
class Unit_type extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'unit_types';
    static $title = "Unit_type";
    static $description = "(Manage Unit_type)";

    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "title" => array("label" => "Title *"),
                "description" => array("label" => " Description", "type" => "textarea"),
            ),
            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions(),
        );
    }
}
