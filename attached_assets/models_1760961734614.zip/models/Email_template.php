<?php
class Email_template extends Mail_template
{
}
