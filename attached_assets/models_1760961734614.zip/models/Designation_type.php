<?php

/**
 *
 * @author <Martin Muriithi> <martin@pporting.org>
 */
class Designation_type extends pPort_model
{

    static $table_name = "designation_types";
    static $primary_key = "id";
    static $connection = 'smart_real_estate';


    static $title = 'Designation Type';
    static $description = 'Manage Designation types';

    public static function fields_config()
    {
        return array(
            "title" => array("label" => "Title"),
            "description" => array("label" => "Description (Optional)", "type" => "textarea")
        );
    }

    public static function config($vars = [])
    {
        return array(
            "fields" => static::fields(),
            "cols" => 1
        );
    }
}