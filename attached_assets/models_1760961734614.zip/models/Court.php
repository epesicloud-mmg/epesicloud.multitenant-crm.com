<?php
class Court extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'courts';
    static $title = "Courts";
    static $description = "(Manage Courts)";
    static $before_save = array('add_account_creator');



    static $has_many = [

        'enquiries' => ['enquiries', 'class_name' => 'Enquiry', 'foreign_key' => 'court_id'],
        'sale_interests' => ['sale_interests', 'class_name' => 'Sale_interest', 'foreign_key' => 'court_id'],
        'sales' => ['sales', 'class_name' => 'Sale', 'foreign_key' => 'court_id'],
        'sale_payments' => ['sale_payments', 'class_name' => 'Sale_payment', 'foreign_key' => 'court_id', 'summary_metric' => 'SUM(amount)'],
        //'courts'=>['courts','class_name'=>'Court','foreign_key'=>'project_id'],
        'apartments' => ['apartments', 'class_name' => 'Apartment', 'foreign_key' => 'court_id'],
        'court_blocks' => ['court_blocks', 'class_name' => 'Court_block', 'foreign_key' => 'court_id', 'disable_summary' => true],
        'court_apartments' => ['court_apartments', 'class_name' => 'Court_apartment', 'foreign_key' => 'court_id', 'disable_summary' => true],
        'units' => ['units', 'class_name' => 'Unit', 'foreign_key' => 'court_id'],

    ];

    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "title" => array("label" => "Court Title * ", "required" => true),
                "project_id" => array("label" => "Project * ", "required" => true, "model" => array(
                    'Project', 'id',
                    array('title'), array('conditions' => array('account_id=?', Acl_user::account_id()))
                )),
                "no_blocks" => array("label" => "No of Blocks * ", "required" => true),

                "description" => array("label" => "Additional Notes", "type" => "textarea"),
            ),
            "fields" => array(
                "title" => array("label" => "Court Title * ", "required" => true),
                "project_id" => array("label" => "Project * ", "required" => true, "model" => array(
                    'Project', 'id',
                    array('title'), array('conditions' => array('account_id=?', Acl_user::account_id()))
                )),

                "no_units" => array("label" => "No of Units * ", "value" => function ($result) {
                    return Unit::count(['conditions' => ['court_id=?', $result->id]]);
                }),
            ),
            "conditions" => array("account_id=?", Acl_user::account_id()),
            "build_attrs" => true
        );
    }



    public static function config_unit_availability($vars = [])
    {

        $config_data = static::config($vars);

        foreach (['available', 'reserved', 'unavailable', 'sold'] as $status) {
            $config_data["fields"][$status] = ["label" => ucfirst($status), "value" => function ($result) use ($status) {
                return Unit::count(["conditions" => ["court_id=? AND status=?", $result->id, $status]]);
            }];
        }

        $config_data['grid_actions'] = [
            "manage_availability" => [
                "label" => "Manage Availability",
                "href" => Url::batch_panel("Court/units/{@id}")
            ]
        ];
        return $config_data;
    }

    public function get_blocks()
    {
        $blocks = [];

        foreach ($this->court_blocks as $court_block) {
            $blocks[] = $court_block->block;
        }
        return $blocks;
    }

    public function get_apartments()
    {
        $apartments = [];
        foreach ($this->court_apartments as $court_apartment) {
            $apartments[] = $court_apartment->apartment;
        }
        return $apartments;
    }
}