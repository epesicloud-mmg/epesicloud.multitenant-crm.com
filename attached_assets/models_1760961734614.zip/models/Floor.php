<?php
class Floor extends Title_description
{
    static $connection='smart_real_estate';
    static $table='floors';
    static $title="Floors";
}