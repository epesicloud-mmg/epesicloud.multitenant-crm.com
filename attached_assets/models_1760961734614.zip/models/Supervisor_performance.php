<?php
class Supervisor_performance extends Agent
{
    public static function global_conditions()
    {
        return [
            "role_check"=>["role_id","=",Role::alias_id("supervisor")]
        ];
    }
}