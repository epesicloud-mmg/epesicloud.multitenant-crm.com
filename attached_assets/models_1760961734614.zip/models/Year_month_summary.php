<?php
class Year_month_summary extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'year_month_summaries';
    static $title = "Year Month Summary";
    static $year_month = NULL;


    public static function summary_analysis_fields()
    {

        $summaries = ['enquiries', 'followups', 'followup_calls', 'followup_sms', 'sale_interests', 'sale_offers', 'sales'];
        $summaries = [
            'enquiries', "qualified_enquiries", 'followups', "meetings", 'sale_interests', 'sale_offers', 'sales',
            "planned_visits", "done_visits", "cancelled_visits"

        ];
        if (isset($_REQUEST['summary_fields'])) {
            return explode(",", $_REQUEST['summary_fields']);
        }
        return $summaries;
    }

    public static function qualified_deals_value()
    {
        $sql = "SELECT SUM(deal_amount) AS result_count FROM " . Enquiry::t() . " WHERE " . Enquiry::dynamic_date_filter();
        $result_count = Enquiry::find_by_sql($sql);


        return $result_count[0]->result_count;
    }


    public static function pull_summaries()
    {
        $summaries = static::summary_analysis_fields();
        $year = date("Y");
        for ($i = 0; $i < 1; $i++) {

            for ($j = 1; $j < 13; $j++) {
                $month = str_pad($j, 2, "0", STR_PAD_LEFT);
                $year_month = $year . "-" . $month;
                static::$year_month = $_REQUEST['year_month'] = $year_month;
                $results[$year_month] =
                    [
                        'year_month_entry' => $year_month,
                        'year' => $year,
                        'month' => $month
                    ];
                foreach ($summaries as $summary) {
                    $_REQUEST['summary'] = $summary;
                    $result_summary = static::query_summaries_count();
                    $results[$year_month][$summary] = $result_summary;
                }
            }
            $year = $year - 1;
        }




        foreach ($results as $result) {
            if ($year_summary = Year_month_summary::find_by_year_and_month_and_account_id($result['year'], $result['month'], Acl_user::account_id())) {
                $year_summary->update_attributes($result);
            } else {
                static::create($result);
            }
        }
        return $results;
    }

    public static function pull_summary($year, $month, $summary)
    {
        $_REQUEST['summary'] = $summary;
        $month = str_pad($month, 2, "0", STR_PAD_LEFT);
        $year_month = $year . "-" . $month;

        $_REQUEST["year_month"] = Year_month_summary::$year_month = $year_month;
        $results_count = static::query_summaries_count();
        return $results_count;
    }



    public static function qualified_enquiries()
    {
        $sql = "SELECT COUNT(*) AS result_count FROM " . Enquiry::t() . " WHERE is_qualified=1 AND " . Enquiry::dynamic_date_filter();
        $result_count = Enquiry::find_by_sql($sql);
        return $result_count[0]->result_count;
    }

    public static function year_month_filter()
    {
        return static::filter_date_field() . ' LIKE "%' . static::$year_month . '%"';
    }

    public static function done_visits()
    {
        $sql = "SELECT COUNT(*) AS result_count FROM " . Lead_meeting::t() . " WHERE  is_checked_out=1 AND meeting_type_id=1 AND " . Lead_meeting::dynamic_date_filter();
        $result_count = Lead_meeting::find_by_sql($sql);
        $summary_count = $result_count[0]->result_count;
        return $summary_count;
    }

    public static function planned_visits()
    {
        $sql = "SELECT COUNT(*) AS result_count FROM " . Lead_meeting::t() . "  WHERE  deleted=0 AND meeting_type_id=1 AND " . Lead_meeting::dynamic_date_filter();
        $result_count = Lead_meeting::find_by_sql($sql);
        $summary_count = $result_count[0]->result_count;
        return $summary_count;
    }

    public static function cancelled_visits()
    {

        $sql = "SELECT COUNT(*) AS result_count FROM " . Lead_meeting::t() . " WHERE  is_cancelled=1 AND meeting_type_id=1 AND " . Lead_meeting::dynamic_date_filter();
        $result_count = Lead_meeting::find_by_sql($sql);
        $summary_count = $result_count[0]->result_count;
        return $summary_count;
    }


    public static function pending_followups()
    {

        $sql = "SELECT COUNT(*) AS summary_result_count
        FROM enquiries WHERE is_qualified=1 
        AND " . Enquiry::dynamic_date_filter("enquiry_date") . " AND account_id=" . Acl_user::account_id() . "
        AND enquiries.id NOT IN(SELECT enquiry_id FROM followups WHERE account_id=" . Acl_user::account_id() . ")";


        $result_sql = Enquiry::find_by_sql($sql);
        return $result_sql[0]->summary_result_count;
    }

    public static function query_summaries_count()
    {

        $summary_count = 0;
        $summary_func = $_REQUEST['summary'];
        if (method_exists("Year_month_summary", $summary_func)) {
            $summary_count = static::$summary_func();
        } else {
            if (class_exists(($class_entity = ucfirst(singularize(str_replace(" ", "_", $_REQUEST['summary'])))))) {
                $result_count = $class_entity::find_by_sql('SELECT COUNT(*) AS result_count FROM ' . $class_entity::t() . " 
                WHERE " . $class_entity::dynamic_date_filter());

                $summary_count = $result_count[0]->result_count;
            }
        }
        return $summary_count;
    }



    public static function fetch_result_count($year, $month = NULL)
    {
        if ($month) {
            return Year_month_summary::sum(['sum' => 'pending_count', 'conditions' => ['account_id=? AND year=? AND month=?', Acl_user::account_id(), $year, $month]]);
        } else {
            return Year_month_summary::sum(['sum' => 'pending_count', 'conditions' => ['account_id=? AND year=?', Acl_user::account_id(), $year]]);
        }
    }

    public static function summary_field_links($field = NULL, $year_month_entry = NULL)
    {
        $start_date = $year_month_entry . "-01";
        $end_date = the_future("1", "month", $start_date, "Y-m-d");
        $filter_sql = " BETWEEN '" . $start_date . "' AND '" . $end_date . "'";
        $field_links =
            [
                'qualified_enquiries' => Url::grid_panel("Enquiry/config/qualified?" . urlencode("filter_sql=enquiry_date " . $filter_sql)),
                'planned_visits' => Url::grid_panel("Lead_meeting/c/report?filter_sql=" . urlencode("meeting_type_id=1 AND meeting_date " . $filter_sql)),
                'done_visits' => Url::grid_panel("Lead_meeting/c/report?filter_sql=" . urlencode("is_checked_out=1 AND meeting_type_id=1 AND meeting_date " . $filter_sql)),
                'cancelled_visits' => Url::grid_panel("Lead_meeting/c/report?filter_sql=" . urlencode("is_cancelled=1 AND meeting_type_id=1 AND meeting_date " . $filter_sql))
            ];
        if ($field) {
            return arr($field, $field_links, NULL);
        }
        return $field_links;
    }

    public static function summary_field_link($field, $year_month_entry)
    {
        $field_link = static::summary_field_links($field, $year_month_entry);
        if ($field_link) {
            return $field_link;
        } else {
            $entity = ucfirst(singularize($field));
            if (class_exists($entity)) {
                $start_date = $year_month_entry . "-01";
                $end_date = the_future("1", "month", $start_date, "Y-m-d");
                $filter_sql = "filter_sql=" . urlencode($entity::filter_date_field() . " BETWEEN '" . $start_date . "' AND '" . $end_date . "'");
                $field = singularize($field);
                $field_link = Url::grid_panel(ucfirst($field)) . "?" . $filter_sql;
            } else {
                $field_link = 'javascript:;';
            }
        }

        return $field_link;
    }

    public static function config($vars = [])
    {
        $fields["year_month_entry"] = array("label" => "Year Month", "type" => "text");
        foreach (static::summary_analysis_fields() as $field) {
            $fields[$field] = array("label" => ucwords(str_replace("_", " ", $field)), "type" => "text", "href" => function ($result) use ($field) {
                $field_link = Year_month_summary::summary_field_link($field, $result->year_month_entry);
                return $field_link;
            });
        }
        $results = static::pull_summaries();
        //unset($fields['year']);
        //unset($fields['month']);

        return array(
            "results" => $results,
            "filter_entity" => NULL,
            "parent_filters" => ["lead_source", "project", "agent"],
            "fields" => $fields,
            "order" => "id ASC",
            "grid_actions" => []
        );
    }
}