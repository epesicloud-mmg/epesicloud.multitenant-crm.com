<?php
class Floor_plan extends pPort_model
{
    static $connection='smart_real_estate';
    static $table='floor_plans';
    static $title="Floor Plan";
    
    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "photo_1" => array(
                    "label" => "Photo 1",
                    "title" => " ",
                    "type" => "ajax_file",
                    "style"=>"height:150px;width:150px",
                    "target" => APP_PATH . 'storage/uploads',
                    'base_relative' => 'app/storage/uploads',
                    "max_size" => 500000,
                    "entity" => "Unit_group",
                    "parent" => "Unit_group",
                    "formats" => "jpeg,png,jpg",
                ),
                "project_id"=>array("label"=>"Project","required"=>true,"model"=>array('Property','id','title',array('conditions'=>array('account_id=?',Session::user('account_id'))))),              
                "unit_group_id"=>array("label"=>"Unit Group","required"=>true,"model"=>array('Unit_group','id','title',array('conditions'=>array('account_id=?',Session::user('account_id'))))),              
                "area_size"=>array("label"=>"Total Sqft","required"=>true),
                "rooms_size"=>array("label"=>"Rooms Sqft *","required"=>true),
                "baths_size"=>array("label"=>"Baths Sqft","required"=>true,"type"=>"text"),
                "price"=>array("label"=>"Price","required"=>true,"type"=>"text"),
            ),
            "grid_actions"=>[],
            
        );
    }
}