<?php

/**
 * Handles User to Groups Many-to-many Lead_activitys
 *
 * User_group Model
 * @author Martin Muriithi <martin@pporting.org>
 *
 *
 **/
class Unit_size extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'unit_sizes';
    static $title = "Unit_size";
    static $description = "(Manage Unit Size)";

    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "title" => array("label" => "Title *"),
                "description" => array("label" => " Description", "type" => "textarea"),
            ),
            "conditions" => array("account_id=?", Acl_user::account_id()),

        );
    }
}
