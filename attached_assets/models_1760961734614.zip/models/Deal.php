<?php
class Deal extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'projects';
    static $title = "Project";
    static $description = "(Manage Projects)";

    static $belongs_to = [
        "location" => ["location", "class_name" => "Location", "foreign_key" => "location_id"]

    ];

    static $has_many = [
        'enquiries' => ['enquiries', 'class_name' => 'Enquiry', 'foreign_key' => 'project_id'],
        'sale_interests' => ['sale_interests', 'class_name' => 'Sale_interest', 'foreign_key' => 'project_id'],
        'sales' => ['sales', 'class_name' => 'Sale', 'foreign_key' => 'project_id'],
        'sale_payments' => ['sale_payments', 'class_name' => 'Sale_payment', 'foreign_key' => 'project_id', 'summary_metric' => 'SUM(amount)'],
    ];





    public static function config($vars = [])
    {
        if (Session::user()->role->alias == 'admin') {
            $conditions = array("account_id=?", Acl_user::account_id());
        } else {
            $conditions = array("user_id=?", Session::user("id"));
        }
        return array(
            "fields" => array(
                "photo_1" => array(
                    "label" => "Photo (1)",
                    "title" => " ",
                    "type" => "ajax_file",
                    "style" => "width:150px;height:150px;",
                    "target" => APP_PATH . 'storage/uploads/',
                    'base_relative' => 'app/storage/uploads/',
                    "max_size" => 500000,
                    "entity" => "Gallery",
                    "formats" => "jpeg,png,jpg",
                ),
                "photo_2" => array(
                    "label" => "Photo (2)",
                    "title" => " ",
                    "type" => "ajax_file",
                    "style" => "width:150px;height:150px;",
                    "target" => APP_PATH . 'storage/uploads/',
                    'base_relative' => 'app/storage/uploads/',
                    "max_size" => 500000,
                    "entity" => "Gallery",
                    "formats" => "jpeg,png,jpg",
                ),
                "photo_3" => array(
                    "label" => "Photo (3)",
                    "title" => " ",
                    "type" => "ajax_file",
                    "style" => "width:150px;height:150px;",
                    "target" => APP_PATH . 'storage/uploads/',
                    'base_relative' => 'app/storage/uploads/',
                    "max_size" => 500000,
                    "entity" => "Gallery",
                    "formats" => "jpeg,png,jpg",
                ),
                "photo_4" => array(
                    "label" => "Photo (4)",
                    "title" => " ",
                    "type" => "ajax_file",
                    "style" => "width:150px;height:150px;",
                    "target" => APP_PATH . 'storage/uploads/',
                    'base_relative' => 'app/storage/uploads/',
                    "max_size" => 500000,
                    "entity" => "Gallery",
                    "formats" => "jpeg,png,jpg",
                ),
                "title" => array("label" => "Deal Name *", "required" => true),
                "offer" => array("label" => "Offer Details *"),
                "description" => array("label" => "Deal Description *", "type" => "textarea", "class" => "wysiwig form-control"),
                "value_proposition" => array("label" => "Value Proposition", "type" => "textarea", "class" => "wysiwig form-control"),
            ),
            "conditions" => array("account_id=?", Acl_user::account_id()),
            "grid_fields" => ["logo", "title", 'location_id'],
            "cols" => 2,
            "limit" => 30,
            "order" => "id DESC",
            "form_actions" => static::form_actions(),
            "grid_actions" => static::grid_actions(['view', 'delete']),
            "form" => static::form_attrs(),
        );
    }
}