<?php
class Activity extends Unit_group
{
    static $connection = 'smart_real_estate';
    static $table = 'unit_groups';
    static $name = "Activity";

    static $belongs_to = array(
        'project' => array("project", "class_name" => "Project", "foreign_key" => "project_id"),
    );




    public static function config($vars = [])
    {
        return array(
            "fields" => static::fields(["project_id", "title", "start_date", "end_date", "description"]),
            "grid_fields" => array("project_id", "title", "purpose", "unit_category_id", "unit_type_id"),
            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions()
        );
    }
}