<?php
class Lead_activity extends pPort_model
{
    static $table = 'followups';
    static $title = 'Followups';
    static $description = '(Manage Followups)';
    static $after_create = array('update_enquiry_status', 'check_for_reminders_and_schedule');
    static $connection = 'smart_real_estate';
    static $belongs_to = [
        'enquiry' => ["enquiry", "foreign_key" => "enquiry_id", "class_name" => "Enquiry"],
        'account_executive' => ["account_executive", "foreign_key" => "agent_id", "class_name" => "Agent"],
        'agent' => ["agent", "foreign_key" => "agent_id", "class_name" => "Agent"],
        'followup_type' => ["followup_type", "foreign_key" => "followup_type_id", "class_name" => "Followup_type"],
        'lead_activity_type' => ["lead_activity_type", "foreign_key" => "followup_type_id", "class_name" => "Lead_activity_type"]
    ];
    static $has_many = [
        'followup_actions' => ["followup_actions", "foreign_key" => "followup_id", "class_name" => "Followup_action"],
    ];

    function check_for_reminders_and_schedule()
    {

        $lead_activity_type = Lead_activity_type::find($this->followup_type_id);

        if ($lead_activity_type) {
            if ($lead_activity_type->alias == "reminder") {
                //Add to reminders
                Reminder::create([
                    'user_id' => $this->agent_id,
                    'reminder_type_id' => $this->reminder_type_id,
                    'enquiry_id' => $this->enquiry_id,
                    'reminder_date' => $this->reminder_date,
                    'reminder_time' => $this->reminder_time,
                    'description' => $this->description
                ]);
            }
        }
    }

    function update_enquiry_status()
    {
        $enquiry = Enquiry::find($this->enquiry_id);
        if ($enquiry) {
            $enquiry->status = "followup";
            $enquiry->save();
        }
    }


    public static function config($vars = [])
    {
        $config_data = array(
            "grid_actions" => [],
            "fields" => array(
                "agent_id" => array("label" => "Account Exec", "model" => array("Account_executive", "id", array("first_name", "last_name"), ["conditions" => ['account_id=?', Session::user('account_id')]])),
                "enquiry_id" => array("label" => "Lead", "model" => array("Enquiry", "id", array("name"), ["conditions" => ["account_id=?", Session::user("account_id")]])),
                "followup_date" => array("label" => "Lead_activity Date", "type" => "date"),
                "followup_type_id" => array("label" => "Type", "model" => array("Followup_type", "id", array("title"))),
                "description" => array("label" => "Notes", "type" => "textarea"),
                "lead_interest_level_id" => array("label" => "Interest Level (Optional)", 'model' => array(
                    'Lead_interest_level', 'id',
                    ['title'], ["conditions" => ["account_id=?", Acl_user::account_id()], "prepend" => ["0" => "--Interest Level--"]]
                )),
            ),
            "limit" => 100,
        );

        if (isset($_REQUEST['filter_check'])) {
            $config_data['results'] = static::fetch_all();
        } else {
            $config_data['filter'] = true;
        }
        return $config_data;
    }

    public static function config_report($vars = [])
    {
        $config_data = parent::config_report($vars);
        $config_data['fields']['location'] = ['label' => 'Location', 'value' => function ($result) {
            if ($result->location_meta_data && $result->location_meta_data <> "null") {
                return Url::location_viewer($result->location_meta_data);
            }
        }];

        return $config_data;
    }






    public static function fetch_all($filter = NULL, $count = NULL)
    {

        $filter_request = isset($_REQUEST['filter_check']) ? $_REQUEST['filter_check'] : $filter;
        $filter = $filter ?: $filter_request;
        if ($filter) {
            if ($filter == "call") {
                $filter_sql = " AND followup_type_id=" . Followup_type::alias_id("call");
            } else {
                $filter_sql = " AND followup_type_id=" . Followup_type::alias_id($filter);
            }
        }

        if ($count) {
            return static::count([
                "conditions" => [
                    "account_id=? " . $filter_sql, Session::user('account_id')
                ],
                "limit" => "100"
            ]);
        } else {
            return static::all([
                "conditions" => [
                    "account_id=? " . $filter_sql, Session::user('account_id')
                ],
                "limit" => "100"
            ]);
        }
    }


    public static function ajaxfy_display()
    {
        $agent_sql = isset($_REQUEST['agent']) && $_REQUEST['agent'] <> "" ? " AND agent_id=" . $_REQUEST['agent'] : "";
        //,".Followup_type::alias_id("meeting_checkout")."
        //$main_condition=Acl_user::account_id()==2?"":"";
        $main_condition = "";
        $followup_type_sql = isset($_REQUEST['followup_type'])  && $_REQUEST['followup_type'] <> "" ? " AND followup_type_id=" . $_REQUEST['followup_type'] : $main_condition;

        $followup_date_sql = isset($_REQUEST['start'])  && isset($_REQUEST['end']) ? " AND (
            meeting_date BETWEEN '" . $_REQUEST['start'] . "' AND '" . $_REQUEST['end'] . "' OR
            followup_date  BETWEEN '" . $_REQUEST['start'] . "' AND '" . $_REQUEST['end'] . "'
             
             OR visit_date BETWEEN '" . $_REQUEST['start'] . "' AND '" . $_REQUEST['end'] . "' 
             OR reminder_date  BETWEEN '" . $_REQUEST['start'] . "' AND '" . $_REQUEST['end'] . "')" : "";


        if (Session::user()->role->alias == "agent") {
            $followups = Followup::find_by_sql("SELECT " . Followup::t("*") . " FROM " . Followup::t() . " 
        INNER JOIN " . Followup_type::t() . " 
        ON " . Followup::t("followup_type_id") . "=" . Followup_type::t("id") . " 
        WHERE agent_id=" . Session::user("id") . " " . $followup_type_sql . $agent_sql . $followup_date_sql . " ORDER BY followups.id DESC");
        } elseif (Session::user()->role->alias == "supervisor") {
            $followups = Followup::find_by_sql("SELECT " . Followup::t("*") . " FROM " . Followup::t() . " 
        INNER JOIN " . Followup_type::t() . " 
        ON " . Followup::t("followup_type_id") . "=" . Followup_type::t("id") . " 
        WHERE supervisor_id=" . Session::user("id") . "  " . $followup_type_sql . $agent_sql . $followup_date_sql . " ORDER BY followups.id DESC");
        } else {
            $followups = Followup::find_by_sql("SELECT " . Followup::t("*") . " FROM " . Followup::t() . " 
        INNER JOIN " . Followup_type::t() . " 
        ON " . Followup::t("followup_type_id") . "=" . Followup_type::t("id") . " 
        WHERE " . Followup::t("account_id") . "=" . Session::user("account_id") . " " . $followup_type_sql . $agent_sql . $followup_date_sql . " ORDER BY followups.id DESC");
        }



        $colors = [
            0 => "#000000",
            "call" => "#d68910",
            "email" => "#8e44ad",
            "sms" => "#808b96",
            "site_visit_checkout" => "#1e8449",
            "meeting_checkout" => "#1e8449",
            "site_visit_scheduling" => "#FF0000",
            "site_visit_checkin" => "#1e8449",
            "meeting_checkin" => "#1e8449",
            "meeting_scheduling" => "#FF0000",
            "reminder" => "#3498db",
            "followup_note" => "#000000",
        ];
        $titles = [
            0 => "#000000",
            "site_visit_checkout" => "Attended Site Visit",
            "meeting_checkout" => "Attended Meeting",
            "site_visit_scheduling" => "Planned SiteVisit",
            "site_visit_checkin" => "Attended SiteVisit",
            "meeting_checkin" => "Attended Meeting",
            "meeting_scheduling" => "Planned Meeting",

        ];
        $results = [];

        foreach ($followups as $followup) {

            $end_date = NULL;
            if ($followup->end_time) {
                $end_date = date("Y-m-d", strtotime($followup->meeting_date)) . " " . $followup->end_time;
            }

            if ($followup->meeting_date && $followup->end_time) {
                $planned_followup_date = date("Y-m-d", strtotime($followup->meeting_date)) . " " . $followup->start_time;
            } elseif ($followup->meeting_date) {
                $planned_followup_date = $followup->meeting_date;
            } elseif ($followup->visit_date) {
                $planned_followup_date = $followup->visit_date;
            } elseif ($followup->reminder_date) {
                $planned_followup_date = $followup->reminder_date;
            } else {
                $planned_followup_date = $followup->followup_date;
            }

            $other_title = "";
            if ($followup->followup_type->alias == "reminder") {
                $other_title = "-" . obj("title", $followup->reminder_type);
            }

            $lead_activity_title = arr("title", $titles, obj("title", $followup->followup_type) . "-" . $other_title . " : " . obj("name", $followup->enquiry) . "( by " . obj("first_name", $followup->account_executive) . " " . obj("last_name", $followup->account_executive) . ")");
            if (in_array(obj("alias", $followup->followup_type), ['site_visit_scheduling', 'meeting_scheduling', 'meeting_rescheduling', 'site_visit_rescheduling'])) {
                //Get the meeting and check if is cancelled
                if ($followup->meeting->is_cancelled) {
                    continue;
                }
            }



            $results[] = [
                'id' => $followup->id,
                'title' => $lead_activity_title,
                'url' => $followup->meeting_id && Session::user()->role->alias == "agent" ? Url::form_panel("Agent_meeting/" . $followup->meeting_id) : Url::component_panel("Enquiry/timeline/" . $followup->enquiry_id),
                'start' => $followup->start_time ? $planned_followup_date : date("Y-m-d", strtotime($planned_followup_date)),
                'end' => $end_date,
                "backgroundColor" => arr($followup->followup_type->alias, $colors, "#3498db"),
                "borderColor" => arr($followup->followup_type->alias, $colors, "#3498db")
            ];
        }

        return ($results);
        $sql = "SELECT * FROM " . static::t();
        $results = static::find_by_sql($sql);
        $result_data = [];
        foreach ($results as $result) {
            $result_data[] = [
                'id' => $result->id,
                'title' => $result->title,
                'start' => $result->start,
                /**"eventColor"=>$result->event_color,
                "backgroundColor"=>$result->event_background_color,
                "borderColor"=>$result->event_border_color,
                "textColor"=>$result->event_text_color,**/

            ];
        }
    }



    public function get_linked_object()
    {
        $linked_entity = $this->linked_entity;
        $linked_entity_id = $this->linked_entity_reference;
        $linked_entity_object = $linked_entity::find($linked_entity_id);
        if ($linked_entity_object) {
            return $linked_entity_object;
        }
    }


    public function param($param_key)
    {
        if (isset($this->{$param_key}) && $this->{$param_key}) {
            return $this->{$param_key};
        } elseif ($this->meta_data) {
            $params = json_decode($this->meta_data, TRUE);
            return arr($param_key, $params);
        } else {
            $linked_entity = $this->linked_entity;
            $linked_entity_id = $this->linked_entity_reference;
            if ($linked_entity) {
                $linked_entity_object = $linked_entity::find($linked_entity_id);
                if ($linked_entity_object && isset($linked_entity_object->{$param_key}) && $linked_entity_object->{$param_key}) {
                    return $linked_entity_object->{$param_key};
                }
            }
        }

        return NULL;
    }


    public static function ajaxfy_fix_lead_activities()
    {
        $agents = Agent::all(['conditions' => ['account_id=? AND role_id<>?', Acl_user::account_id(), Role::alias_id("agent")]]);
        foreach ($agents as $agent) {
            $followups = Followup::all(['conditions' => ['agent_id=?', $agent->id]]);

            foreach ($followups as $followup) {
                $followup_type = Followup_type::find($followup->followup_type_id);
                $followup->followup_type_id = Followup_type::alias_id($followup_type->alias);
                $followup->account_id = Acl_user::account_id();
                $followup->save();
            }
        }
    }
}