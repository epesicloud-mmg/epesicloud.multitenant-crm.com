<?php
class User_last_location extends Location_log
{
    static $title="Last Location";
    static $name="Last Location";
}