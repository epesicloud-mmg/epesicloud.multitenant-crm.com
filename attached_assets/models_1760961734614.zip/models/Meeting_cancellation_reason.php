<?php
class Meeting_cancellation_reason extends Title_description
{
    static $table_name="meeting_cancellation_reasons";
    static $primary_key="id";
    static $connection='smart_real_estate';
}