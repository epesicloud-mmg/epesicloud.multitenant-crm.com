<?php
class Developer_company extends pPort_model
{
    
    static $table='developer_companies';
    static $title='Developer Company';
    static $description='(Developer Companies)';
    static $connection='smart_real_estate';


    

    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "name"=>array("label"=>"Company Name","required"=>true),
                "physical_address"=>array("label"=>"Physical Address"),
                "phone"=>array("label"=>"Phone"),
                "email"=>array("label"=>"Email"),
                "postal_address"=>array("label"=>"Postal Address","type"=>"textarea"),
                "bank_name"=>array("label"=>"Bank Name"),
                "bank_account_name"=>array("label"=>"Bank Account Name"),
                "bank_account_number"=>array("label"=>"Bank Account Number"),
                "bank_code"=>array("label"=>"Bank Code"),
                "bank_branch_name"=>array("label"=>"Branch Name"),
                "bank_branch_code"=>array("label"=>"Branch Code"),
                "bank_swift_code"=>array("label"=>"Swift Code"),
                "is_main"=>array("label"=>"Set As main","params"=>["0"=>"No","1"=>"Yes"],"required"=>true),
                "description" => array("label" => "Description", "type" => "textarea"),
                
             ),
            "cols"=>2,
            "conditions"=>array("account_id=? AND deleted=?",Acl_user::account_id(),0),
            
            "grid_actions"=>static::grid_actions(),
            "form_actions"=>static::form_actions(),
            "form"=>static::form_attrs(),
        );
    }

}