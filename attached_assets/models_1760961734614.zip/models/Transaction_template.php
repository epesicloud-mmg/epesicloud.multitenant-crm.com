<?php

/**
 * Handles User to Groups Many-to-many Lead_activitys
 *
 * User_group Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Transaction_template extends pPort_model
{
    static $connection = 'smart_real_estate';

    static $table = 'transaction_templates';
    static $title = "Templates";
    static $name = "Sale Offer";
    static $description = "(Add and Manage Templates)";



    public static function config($vars = [])
    {
        $transaction_template = Transaction_template::last(['conditions' => ['account_id=?', Session::user("account_id")]]);
        return array(
            "before_form" => "<div style='position:fixed;top:30%;right:0px;z-index:8000000'>
            <button class='undo_button btn btn-info' onclick='save_editor()'><i class='la la-clipboard'></i> Save</button>
            <br/> <br/>
            <button class='undo_button btn' onclick='undo_editor()'><i class='la la-undo'></i> Undo</button><br/> <br/> 
            <button class='redo_button btn' onclick='redo_editor()'><i class='la la-repeat'></i> Redo</button>
            <br/>
            <br/>
            
            </div> 
            ",
            "fields" => array(
                "template_type" => array("label" => "Template Type", "params" => ["letter_of_offer" => "Letter of Offer"]),
                "editor" => array("label" => "Editor", "editor_entity" => "Transaction_template", "type" => "textarea", "value" => function ($result) {
                    if ($result->content) {
                        return $result->content;
                    }
                }),

                "content" => array("label" => "Content", "type" => "textarea", "readonly" => true, "style" => "display:none;"),
            ),
            "grid_fields" => [
                "template_type" => array("label" => "Template Type", "params" => ["letter_of_offer" => "Letter of Offer"]),
                //"content"=>array("label"=>"Content","type"=>"textarea"),
            ],
            "cols" => 1,
            "form_actions" => static::form_actions([]),
            "grid_actions" => static::grid_actions(),
            "form" => static::form_attrs()


        );
    }
}
