<?php

/**
 *
 * @author <Martin Muriithi> <martin@pporting.org>
 */
class Lead_source extends pPort_model
{

    static $table_name = "lead_sources";
    static $primary_key = "id";
    static $connection = 'smart_real_estate';


    static $title = 'Lead Source';

    static $has_many = [
        'enquiries' => ['enquiries', 'class_name' => 'Enquiry', 'foreign_key' => 'lead_source_id'],
        'sale_interests' => ['sale_interests', 'class_name' => 'Sale_interest', 'foreign_key' => 'lead_source_id'],
        'sales' => ['sales', 'class_name' => 'Sale', 'foreign_key' => 'lead_source_id'],
    ];



    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "lead_source_category_id" => array("label" => "Lead Source Category", "model" => ["Lead_source_category", "id", "title"]),
                "title" => array("label" => "Lead Source Title"),
                "description" => array(
                    "label" => "Description (Optional)",
                    "type" => "textarea"
                ),
                "enable_app_tracking" => array("label" => "Enable Tracking on App", "params" => ['0' => 'No', '1' => "Yes"]),
            ),
            "grid_actions" => array(
                'view' => array('text' => 'View', 'href' => Url::base() . 'move/main/form/Lead_source/{@id}', "icon-eye"),
                'delete' => array('text' => 'Delete', 'href' => Url::base() . 'move/main/delete/Lead_source/{@id}', "icon-eye", "delete" => TRUE)
            ),

            "conditions" => array("account_id=?", Acl_user::account_id()),
            "form" => static::form_attrs(),
            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions()

        );
    }

    public static function fetch_all_trackable()
    {
        return Lead_source::all([
            'conditions' => ['enable_app_tracking=1 AND account_id=?', Session::user("account_id")]
        ]);
    }
}