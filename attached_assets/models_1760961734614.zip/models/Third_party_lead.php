<?php
class Third_party_lead  extends Lead
{

    public static function config($vars = [])
    {
        $config_data = parent::config($vars);
        $config_data['fields']['originator_type_id'] = ['label' => "Originator Type", "value" => Originator_type::alias_id("third_party"), "type" => "hidden"];
        $config_data['fields']['third_party_agent_id'] = ['label' => "Third Party Agent", "model" => ["Third_party_agent", "id", ["first_name", "last_name"]]];

        $config_data['fields']['agent_id'] = array(
            "enable_quick_entry" => true,
            "quick_entry_link" => Url::form_panel("Third_party_agent"),
            "label" => "Agent", "permitted_roles" => "admin", "prepend" => ["" => "-Select Agent-"], 'required' => true,
            'model' => array(
                'Agent', 'id',
                ['first_name', 'last_name'], [
                    "prepend" => ["" => "-Select Agent-"],
                    "conditions" => [
                        "role_id=? AND account_id=? AND deleted=0", Role::alias_id('third_party'), Acl_user::account_id()
                    ]
                ]
            )
        );
        return $config_data;
    }
}