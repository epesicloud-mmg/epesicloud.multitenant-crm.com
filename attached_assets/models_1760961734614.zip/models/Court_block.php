<?php
class Court_block extends pPort_model
{
    static $connection='smart_real_estate';
    static $table='court_blocks';
    static $title="Court Blocks";
    static $description="(Manage Court Blocks)";
    static $before_save=array('add_account_creator');

    static $belongs_to=[
        'project'=>['project','class_name'=>'Project','foreign_key'=>'project_id'],
        'block'=>['block','class_name'=>'Block','foreign_key'=>'block_id'],
        'court'=>['court','class_name'=>'Court','foreign_key'=>'court_id']
    ];
   
    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "title"=>array("label"=>"Title * ","required"=>true),
                "project_id"=>array("label"=>"Project * ","required"=>true,"model"=>array('Project','id',
                array('title'),array('conditions'=>array('account_id=?',Acl_user::account_id())))),
                "court_id"=>array("label"=>"Court * ","required"=>true,"model"=>array('Court','id',
                array('title'),array('conditions'=>array('account_id=?',Acl_user::account_id())))),
                "block_id"=>array("label"=>"Block * ","required"=>true,"model"=>array('Block','id',
                array('title'),array('conditions'=>array('account_id=?',Acl_user::account_id())))),
            ),
            "conditions"=>array("account_id=?",Acl_user::account_id()),
            "build_attrs"=>true
        );
    }
}