<?php
/**
 *
 * @author <Martin Muriithi> <martin@pporting.org>
 */
class Commision_item extends pPort_model
{

    static $table_name="commision_items";
    static $primary_key="id";
    static $connection='smart_real_estate';

    static $title='Commision Items';
    static $description='Manage Commision Items';
    static $belongs_to=[
        "unit"=>["unit","class_name"=>"Unit","foreign_key"=>'unit_id'],
        "commision"=>["commision","class_name"=>"Unit","foreign_key"=>'commision_id']

    ];

    static $before_save=["add_user_details"];
    static $before_create=['calculate_amount'];
    static $currency_fields=['paid_amount','amount','sale_price'];

    public function calculate_amount()
    {
        if($this->amount==NULL)
        {
            $this->amount=$this->paid_amount*0.03;
        }        
    }


    public function add_user_details()
    {
        if($this->user_id)
        {
            $user=User::find($this->user_id);
        }
        else
        {
            $commision=Commision::find($this->commision_id);
            $user=$commision->user;
        }
        if($user)
        {
            $this->payee_first_name=$user->first_name;
            $this->payee_last_name=$user->last_name;
            $this->payee_phone=$user->phone;
            $this->agent_id=$user->role->alias=="agent"?$user->id:NULL;
            $this->supervisor_id=$user->role->alias=="agent"?$user->supervisor_id:NULL;


        }
    }
    
    public function add_client_details()
    {
        $reservation=Sale_interest::first(['conditions'=>['id=?',$this->sale_interest_id]]);
        $this->title=$reservation->name;
    }
    
    public static function fields_config()
    {
       return array(
        "commision_id"=>array("label"=>"Commission Ref","model"=>["Commision","id",["payee_first_name","payee_last_name","commision_date"]]),
        "sale_interest_id"=>array("label"=>"Reservation","model"=>["Sale_interest","id",["id","name"]]),
        "unit_id"=>array("label"=>"Unit","params"=>function(){
            $units=Unit::all();
            $units_arr=[];
            foreach($units as $unit)
            {
                $project_title=$unit->project?$unit->project->title:"";
                $units_arr[$unit->id]=$project_title.' : '.$unit->title;
            }
            return $units_arr;
        }),
        "title"=>array("label"=>"Client Name"),
        "sale_price"=>array("label"=>"Sale Price","required"=>true),
        "paid_amount"=>array("label"=>"Deposit Paid","required"=>true),
        "amount"=>array("label"=>"Commission Amount","required"=>true)
       );
    }

    public static function config($vars=[])
    {
        return array(
            "fields"=>static::fields(['title'],false),
            "cols"=>1,
            "build_config"=>true,
            "conditions"=>["account_id=?",Acl_user::account_id()]
        );
    }
}

?>