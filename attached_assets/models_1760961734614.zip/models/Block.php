<?php
class Block extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'blocks';
    static $title = "Blocks";
    static $description = "(Manage Blocks)";
    static $before_save = array('add_account_creator');

    static $has_many = [
        'enquiries' => ['enquiries', 'class_name' => 'Enquiry', 'foreign_key' => 'block_id'],
        'sale_interests' => ['sale_interests', 'class_name' => 'Sale_interest', 'foreign_key' => 'block_id'],
        'sales' => ['sales', 'class_name' => 'Sale', 'foreign_key' => 'block_id'],
        'sale_payments' => ['sale_payments', 'class_name' => 'Sale_payment', 'foreign_key' => 'block_id', 'summary_metric' => 'SUM(amount)']
    ];

    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "project_id" => array("label" => "Project * ", "required" => true, "model" => array(
                    'Project', 'id',
                    array('title'), array('conditions' => array('account_id=?', Acl_user::account_id()))
                )),
                //"court_id"=>array("label"=>"Court * ","required"=>true,"model"=>array('Court','id',array('title'),array('conditions'=>array('account_id=?',Acl_user::account_id())))),
                //"apartment_id"=>array("label"=>"Apartment * ","required"=>true,"model"=>array('Apartment','id',array('title'),array('conditions'=>array('account_id=?',Acl_user::account_id())))),

                "title" => array("label" => "Block Title * ", "required" => true),
                //"no_units"=>array("label"=>"No of Units * ","required"=>true),
                "description" => array("label" => "Block Description", "type" => "textarea"),
            ),
            "conditions" => array("account_id=?", Acl_user::account_id()),
            "build_attrs" => true
        );
    }
}