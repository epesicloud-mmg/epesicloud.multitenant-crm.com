<?php
class Court_apartment extends pPort_model
{
    static $connection='smart_real_estate';
    static $table='court_apartments';
    static $title="Court Apartments";
    static $description="(Manage Court Apartments)";
    static $before_save=array('add_account_creator');

    static $belongs_to=[
        'project'=>['project','class_name'=>'Project','foreign_key'=>'project_id'],
        'apartment'=>['apartment','class_name'=>'Apartment','foreign_key'=>'apartment_id'],
        'court'=>['court','class_name'=>'Court','foreign_key'=>'court_id']
    ];
   
    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "title"=>array("label"=>"Description * ","required"=>true),
                "project_id"=>array("label"=>"Project * ","required"=>true,"model"=>array('Project','id',
                array('title'),array('conditions'=>array('account_id=?',Acl_user::account_id())))),
                "court_id"=>array("label"=>"Court * ","required"=>true,"model"=>array('Court','id',
                array('title'),array('conditions'=>array('account_id=?',Acl_user::account_id())))),
                "apartment_id"=>array("label"=>"Apartment * ","required"=>true,"model"=>array('Apartment','id',
                array('title'),array('conditions'=>array('account_id=?',Acl_user::account_id())))),
            ),
            "conditions"=>array("account_id=?",Acl_user::account_id()),
            "build_attrs"=>true
        );
    }
}