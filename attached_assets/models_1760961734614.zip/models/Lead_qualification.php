<?php

/**
 * @author Martin Muriithi <martin@pporting.org>
 *
 *
 **/
class Lead_qualification extends Title_description
{
    static $connection = 'smart_real_estate';
    static $table = 'lead_qualifications';
    static $name = "Lead Qualification";

    static $belongs_to = [
        "agent" => ["agent", "class_name" => "Agent", "foreign_key" => "agent_id"],
        "lead" => ["lead", "class_name" => "Lead", "foreign_key" => "lead_id"]

    ];

    static $after_create = [
        'process_action'
    ];

    public  function process_action()
    {
        if ($this->action == "qualify_lead") {

            $this->lead->is_qualified = 1;
            $this->lead->qualify_status = "qualified";
            $this->lead->qualification_status_type_id = Qualification_status_type::alias_id("qualified");
            $this->lead->save();
        }
        if ($this->action == "decline_lead") {
            $this->lead->is_qualified = 0;
            $this->lead->is_declined = 1;
            $this->lead->qualify_status = "not_qualified";
            $this->lead->qualification_status_type_id = Qualification_status_type::alias_id("declined");
            $this->lead->save();
        }
    }

    public static function send_bulk_qualify_sms($bulk_action_token = NULL)
    {
        $leads_qualified_per_agent = Lead_qualification::find_by_sql("SELECT agent_id,COUNT(*) AS leads_count FROM " . static::t() . " WHERE bulk_action_token='" . $bulk_action_token . "' GROUP BY agent_id");

        foreach ($leads_qualified_per_agent as $qualification) {
            $message = "Hello " . $qualification->agent->first_name . ", you have " . $qualification->leads_count . " new leads qualified and assigned to you. Access the leads on your app.";
            $agent_phone = $qualification->agent->phone;
            //$agent_phone="254729934932";
            Sms::send($message, $agent_phone);
        }
    }

    public static function bulk_process_entries($bulk_entries, $bulk_action_entity = NULL)
    {
        $processed_entries_message = "";
        $processed_entries_count = 0;
        foreach ($bulk_entries as $bulk_entry) {
            $session_user = Session::user();
            $enquiry = Enquiry::find($bulk_entry);

            if (!Lead_qualification::exists([
                'conditions' => [
                    "lead_id=? AND agent_id=? AND bulk_action_token=?", $bulk_entry, $enquiry->agent_id, $bulk_action_entity::$bulk_action_token
                ]
            ])) {
                $processed_entries_count++;
                Lead_qualification::create([
                    'lead_id' => $bulk_entry,
                    "agent_id" => $enquiry->agent_id,
                    'qualified_by' => Session::user("id"),
                    'account_id' => $session_user->account_id,
                    'qualification_date' => date("Y-m-d"),
                    "action" => $bulk_action_entity::$bulk_action,
                    "is_bulk_action" => 1,
                    "bulk_action_token" => $bulk_action_entity::$bulk_action_token,

                ]);
            }
        }

        if ($bulk_action_entity::$bulk_action == "qualify_lead") {
            static::send_bulk_qualify_sms($bulk_action_entity::$bulk_action_token);
        }

        $processed_entries_message = $processed_entries_count;
        return $processed_entries_message;
    }
}