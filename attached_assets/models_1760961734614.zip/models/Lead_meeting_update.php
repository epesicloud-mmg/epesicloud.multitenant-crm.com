<?php
class Lead_meeting_update extends pPort_model
{
    
    static $table='lead_meeting_updates';
    static $name='Meeting Update';
    static $connection='smart_real_estate';
    static $after_create=["update_meeting"];

    public function update_meeting()
    {
        $meeting=Lead_meeting::find($this->meeting_id);
        $meeting->lead_interest_level_id=$this->lead_interest_level_id;
        $meeting->action=$this->action;
        if($this->location_meta_data)
        {
            $meeting->location_meta_data=$this->location_meta_data;
        }
        
        
        if($this->action=="checkin"||$this->action=="checkout")
        {
            if($this->is_checked_in)
            {
                $meeting->description=$this->description;
                $meeting->action_date=date("Y-m-d");
                $meeting->action_time=$this->checkin_time;
                $meeting->checkin_time=$this->checkin_time;
                $meeting->is_checked_in=1;
                $meeting->status="checked_in";
            }

            if($this->is_checked_out)
            {
                $meeting->description=$this->description;
                $meeting->checkout_time=$this->checkin_time;
                $meeting->action_date=date("Y-m-d");
                $meeting->action_time=$this->checkin_time;
                $meeting->is_checked_out=1;
                $meeting->is_closed=1;            
                $meeting->status="checked_out";
            }
        }
        elseif($this->action=="rescheduling")
        {
            $meeting->description=$this->description;
            $meeting->reschedule_date=$this->reschedule_date;
            $meeting->reschedule_time=$this->reschedule_time;
            $meeting->is_checked_out=1;
            $meeting->is_rescheduled=1;
            $meeting->action_date=$this->reschedule_date;
            $meeting->action_time=$this->reschedule_time;
            //Creating a New Meeting from the Reschedule
            
            Lead_meeting::create(
                [
                    'meeting_type_id'=>$meeting->meeting_type_id,
                    'enquiry_id'=>$meeting->enquiry_id,
                    'meeting_date'=>$this->reschedule_date,
                    'meeting_time'=>$this->reschedule_time,
                    'start_time'=>$this->reschedule_time,
                    'description'=>$this->description,
                    'meeting_id'=>$meeting->id,
                    'agent_id'=>$meeting->agent_id,
                    'account_id'=>$meeting->account_id


                ]
            );
            $meeting->is_closed=1;
            $meeting->status="rescheduled";
        }
        
        elseif($this->action=="cancellation")
        {
            $meeting->description=$this->description;
            $meeting->cancellation_date=date("Y-m-d");
            $meeting->cancellation_time=date("H:i");
            $meeting->action_date=date("Y-m-d");
            $meeting->action_time=date("H:i");
            $meeting->is_cancelled=1;
            $meeting->is_closed=1;
            $meeting->status="cancelled";
        }
        $meeting->save();
    }
   

    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "action"=>array("label"=>"Action"),
                "agent_id"=>array("label"=>"Related To","model"=>["Agent","id",["first_name","last_name"],
                [
                    "prepend"=>[""=>"-Select Agent-"],
                    "conditions"=>["account_id=?",Acl_user::account_id()]]
                    ]
                ),
                "enquiry_id"=>array("label"=>"Related To","model"=>["Enquiry","id","name",
                [
                    "prepend"=>[""=>"-Select Client-"],
                    "conditions"=>["account_id=?",Acl_user::account_id()]]
                    ]
                ),
                "checkin_time"=>array("label"=>"Checkin Time"),
                "checkout_time"=>array("label"=>"Checkout Time"),
                
             ),
            "cols"=>1,
            "conditions"=>array("account_id=? AND deleted=?",Acl_user::account_id(),0),
            
             "grid_actions"=>static::grid_actions(),
            "form_actions"=>static::form_actions(),
            "form"=>static::form_attrs(),
        );
    }

    
}