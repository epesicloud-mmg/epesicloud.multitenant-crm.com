<?php
class Supervisor extends Acl_user
{
    static $name = "Supervisor";

    static $child_before_save = [
        'check_leads_before_delete'
    ];

    static $child_after_save = [
        'update_mail_accounts'
    ];

    public static function global_conditions()
    {
        return [
            "role_check" => ["role_id", "=", Role::alias_id("supervisor")]
        ];
    }


    public function check_leads_before_delete()
    {
        if ($this->deleted) {
            $enquiries_exist = Enquiry::exists(['conditions' => ['supervisor_id=' . $this->id]]);
            if ($enquiries_exist) {
                json_render(['info' => 'error', 'message' => 'Could not delete. The account has some existing leads.']);
            }
        }
    }

    public static function pending_qualifications_rating()
    {
        $ratings = [
            '80' => ['score' => 80, 'rating' => 'Poor', 'advisory' => "This is a very high number of unqualified leads. It's a very low turn-around time on qualifications by the team supervisor."],
            '65' => ['score' => 65, 'rating' => 'Average', 'advisory' => 'There is a high number of unqualified leads. Team supervision has a low turn-around. There needs to be an improvement on the time taken to qualify leads.'],
            '40' => ['score' => 40, 'rating' => 'Good', 'advisory' => 'Supervision is doing a good job around qualifying and following up on leads submitted. There is room for improvement'],
            '25' => ['score' => 25, 'rating' => 'Excellent', 'advisory' => 'Excellent performance around lead qualification. There is a quick turn-around time in qualifying leads.'],
        ];
        return $ratings;
    }

    public static function pending_qualification_rating($score = NULL)
    {
        $pending_qualifications = Enquiry::count(['conditions' => [
            'account_id=? AND qualify_status="pending"',
            Session::user("account_id")
        ]]);

        $ratings = static::pending_qualifications_rating();
        $score = $pending_qualifications;
        foreach ($ratings as $rating) {
            if ($score > $rating['score']) {
                break;
            }
        }
        return $rating;
    }

    public static function config($vars = [])
    {

        return array(
            "fields" => array(
                "branch_id" => array("label" => "Branch", 'model' => array('Branch', 'id', 'title', array('conditions' => array('account_id=?',  Session::user("account_id"))))),

                "role_id" => array("label" => "Role", 'model' => array('Role', 'id', 'title', array('conditions' => array('account_id=? AND id=?', Acl_user::account_id(), Role::alias_id('supervisor'))))),
                "first_name" => array("label" => "First Name"),
                "last_name" => array("label" => "Last Name"),
                "email" => array("label" => "Email"),
                "phone" => array("label" => "Phone"),
                "password" => array("label" => "Password", "type" => "password"),
                "confirm_password" => array("label" => "Confirm Password", "type" => "password"),
                "number_of_agents" => array("label" => "Number of Agents", "value" => function ($result) {
                    return Agent::count(["conditions" => ["supervisor_id=? AND account_id=?", $result->id, Acl_user::account_id()]]);
                }),
                "deleted" => ["label" => "Is Active?", "params" => ["0" => "Yes", "1" => "No"]]
            ),
            "grid_fields" => ["first_name", "last_name", "email", "phone", "number_of_agents"],
            "conditions" => array("account_id=? AND role_id=? AND deleted=0", Acl_user::account_id(), Role::alias_id("supervisor")),
            "form" => static::form_attrs(),
            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions(),
        );
    }
}
