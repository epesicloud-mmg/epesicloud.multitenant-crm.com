<?php

class Salesify_calendar_event extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'calendar_events';
    static $title = "Calendar";
    static $description = "(Events Calendar)";



    public static function ajaxfy_display()
    {
        $agent_sql = isset($_REQUEST['agent']) && $_REQUEST['agent'] <> "" ? " AND agent_id=" . $_REQUEST['agent'] : "";
        //,".Followup_type::alias_id("meeting_checkout")."
        //$main_condition=Acl_user::account_id()==2?"":"";
        $main_condition = "";
        $followup_type_sql = isset($_REQUEST['followup_type'])  && $_REQUEST['followup_type'] <> "" ? " AND followup_type_id=" . $_REQUEST['followup_type'] : $main_condition;

        $followup_date_sql = isset($_REQUEST['start'])  && isset($_REQUEST['end']) ? " AND (
            meeting_date BETWEEN '" . $_REQUEST['start'] . "' AND '" . $_REQUEST['end'] . "' OR
            followup_date  BETWEEN '" . $_REQUEST['start'] . "' AND '" . $_REQUEST['end'] . "'
             
             OR visit_date BETWEEN '" . $_REQUEST['start'] . "' AND '" . $_REQUEST['end'] . "' 
             OR reminder_date  BETWEEN '" . $_REQUEST['start'] . "' AND '" . $_REQUEST['end'] . "')" : "";


        if (Session::user()->role->alias == "agent") {
            $followups = Followup::find_by_sql("SELECT " . Followup::t("*") . " FROM " . Followup::t() . " 
        INNER JOIN " . Followup_type::t() . " 
        ON " . Followup::t("followup_type_id") . "=" . Followup_type::t("id") . " 
        WHERE agent_id=" . Session::user("id") . " " . $followup_type_sql . $agent_sql . $followup_date_sql . " ORDER BY followups.id DESC");
        } elseif (Session::user()->role->alias == "supervisor") {
            $followups = Followup::find_by_sql("SELECT " . Followup::t("*") . " FROM " . Followup::t() . " 
        INNER JOIN " . Followup_type::t() . " 
        ON " . Followup::t("followup_type_id") . "=" . Followup_type::t("id") . " 
        WHERE supervisor_id=" . Session::user("id") . "  " . $followup_type_sql . $agent_sql . $followup_date_sql . " ORDER BY followups.id DESC");
        } else {
            $followups = Followup::find_by_sql("SELECT " . Followup::t("*") . " FROM " . Followup::t() . " 
        INNER JOIN " . Followup_type::t() . " 
        ON " . Followup::t("followup_type_id") . "=" . Followup_type::t("id") . " 
        WHERE " . Followup::t("account_id") . "=" . Session::user("account_id") . " " . $followup_type_sql . $agent_sql . $followup_date_sql . " ORDER BY followups.id DESC");
        }



        $colors = [
            0 => "#000000",
            "call" => "#d68910",
            "email" => "#8e44ad",
            "sms" => "#808b96",
            "site_visit_checkout" => "#1e8449",
            "meeting_checkout" => "#1e8449",
            "site_visit_scheduling" => "#FF0000",
            "site_visit_checkin" => "#1e8449",
            "meeting_checkin" => "#1e8449",
            "meeting_scheduling" => "#FF0000",
            "reminder" => "#3498db",
            "followup_note" => "#000000",
        ];
        $titles = [
            0 => "#000000",
            "site_visit_checkout" => "Attended Site Visit",
            "meeting_checkout" => "Attended Meeting",
            "site_visit_scheduling" => "Planned SiteVisit",
            "site_visit_checkin" => "Attended SiteVisit",
            "meeting_checkin" => "Attended Meeting",
            "meeting_scheduling" => "Planned Meeting",

        ];
        $results = [];

        foreach ($followups as $followup) {

            $end_date = NULL;
            if ($followup->end_time) {
                $end_date = date("Y-m-d", strtotime($followup->meeting_date)) . " " . $followup->end_time;
            }

            if ($followup->meeting_date && $followup->end_time) {
                $planned_followup_date = date("Y-m-d", strtotime($followup->meeting_date)) . " " . $followup->start_time;
            } elseif ($followup->meeting_date) {
                $planned_followup_date = $followup->meeting_date;
            } elseif ($followup->visit_date) {
                $planned_followup_date = $followup->visit_date;
            } elseif ($followup->reminder_date) {
                $planned_followup_date = $followup->reminder_date;
            } else {
                $planned_followup_date = $followup->followup_date;
            }

            $other_title = "";
            if ($followup->followup_type->alias == "reminder") {
                $other_title = "-" . obj("title", $followup->reminder_type);
            }

            if ($followup->followup_type->alias == "other_activity") {
                $other_title = "-" . $followup->title;
            }

            

            $lead_activity_title = arr("title", $titles, obj("title", $followup->followup_type) . "-" . $other_title . " : " . obj("name", $followup->enquiry) . "( by " . obj("first_name", $followup->user) . " " . obj("last_name", $followup->user) . ")");
            
            if (in_array(obj("alias", $followup->followup_type), ['site_visit_scheduling', 'meeting_scheduling', 'meeting_rescheduling', 'site_visit_rescheduling'])) {
                //Get the meeting and check if is cancelled
                if ($followup->meeting->is_cancelled) {
                    continue;
                }
            }



            $eventItem=[
                'id' => $followup->id,
                'title' => $lead_activity_title,
                'start' => $followup->start_time ? $planned_followup_date : date("Y-m-d", strtotime($planned_followup_date)),
                'end' => $end_date,
                "backgroundColor" => arr($followup->followup_type->alias, $colors, "#3498db"),
                "borderColor" => arr($followup->followup_type->alias, $colors, "#3498db")
            ];
            if($followup->enquiry_id)
            {
                 $eventItem['url'] =$followup->meeting_id && Session::user()->role->alias == "agent" ? Url::portlet("main/feed/" . $followup->enquiry_id) : Url::portlet("main/feed/" . $followup->enquiry_id);
                
            }
            $results[] = $eventItem;
        }

        return ($results);
        $sql = "SELECT * FROM " . static::t();
        $results = static::find_by_sql($sql);
        $result_data = [];
        foreach ($results as $result) {
            $result_data[] = [
                'id' => $result->id,
                'title' => $result->title,
                'start' => $result->start,
                /**"eventColor"=>$result->event_color,
                "backgroundColor"=>$result->event_background_color,
                "borderColor"=>$result->event_border_color,
                "textColor"=>$result->event_text_color,**/

            ];
        }
    }

    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "calendar_event_type_id" => array("label" => "Event Type", "required" => true),
                "title" => array("label" => "Title", "required" => true),
                "start_time" => array("required" => true, "label" => "Event Date", "type" => "date"),
                "end_time" => array("label" => "End", "required" => true, "type" => "date"),
                "description" => array("label" => "Description", "required" => true),
                'url' => array("label" => "Linked URl", "required" => true),
                'is_all_day' => array("label" => "All Day Event?", "params" => ["0" => "No", "1" => "Yes"]),

            ),
        );
    }
}