<?php

class Salesify_calendar_event_type extends pPort_model
{
    static $connection='smart_real_estate';
    static $table='calendar_event_types';
    static $title="Calendar";
    static $description="(Events Calendar)";
    
    

    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "title"=>array("label"=>"Title","required"=>true),                
                "background_color"=>array("required"=>true,"label"=>"Background Color","type"=>"date"),
                "border_color"=>array("label"=>"Border Color","required"=>true,"type"=>"date"),
                "text_color"=>array("label"=>"Text Color","required"=>true),
                'url'=>array("label"=>"Linked URl","required"=>true),
            ),
        );
    }
}