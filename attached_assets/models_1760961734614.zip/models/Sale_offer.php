<?php
class Sale_offer extends pPort_model
{
    static $table = 'sale_offers';
    static $title = "Sales";
    static $description = "(Record sales made in your business)";
    static $connection = 'smart_real_estate';
    static $enabled_for_time_range = true;
    static $before_save = ["add_tax_rate_id", "auto_add_data", "add_is_deleted_if_cancelled"];
    static $after_save = ["propagate_status"];
    static $after_create = ["auto_create_sale"];
    static $filter_date = "sale_offer_date";
    static $permissions = [
        'review_letter_of_offers',
        'append_director_signature_to_letter_of_offers'
    ];

    static $has_many = [
        'payment_plans' => ['payment_plans', 'class_name' => 'Payment_plan', 'foreign_key' => 'sale_offer_id', 'show' => 'grid'],
        'sale_offer_documents' => ['sale_offer_documents', 'class_name' => 'Sale_offer_document', 'foreign_key' => 'sale_offer_id', 'show' => 'grid'],
    ];

    static $belongs_to = [
        'unit' => ['unit', 'class_name' => 'Unit', 'foreign_key' => 'unit_id', 'show' => 'grid'],
        'project' => ['project', 'class_name' => 'Project', 'foreign_key' => 'project_id', 'show' => 'grid', "visualize" => true],
        'unit_group' => ['unit_group', 'class_name' => 'Unit_group', 'foreign_key' => 'unit_group_id', 'show' => 'grid', "visualize" => true],
        'court' => ['court', 'class_name' => 'Court', 'foreign_key' => 'court_id', 'show' => 'grid'],
        'block' => ['block', 'class_name' => 'Block', 'foreign_key' => 'block_id', 'show' => 'grid'],
        'apartment' => ['apartment', 'class_name' => 'Apartment', 'foreign_key' => 'apartment_id', 'show' => 'grid'],
        'customer_type' => ['customer_type', 'class_name' => 'Customer_type', 'foreign_key' => 'customer_type_id', 'show' => 'grid', "visualize" => true],
        'lead_source' => ['lead_source', 'class_name' => 'Lead_source', 'foreign_key' => 'lead_source_id', 'show' => 'grid', "visualize" => true],
        'salesify_campaign' => ['salesify_campaign', 'class_name' => 'Salesify_campaign', 'foreign_key' => 'salesify_campaign_id', 'show' => 'grid', "visualize" => true],
        'lead_interest_level' => ['lead_interest_level', 'class_name' => 'Lead_interest_level', 'foreign_key' => 'lead_interest_level_id', 'show' => 'grid', "visualize" => true],
        'lead_budget' => ['lead_budget', 'class_name' => 'Lead_budget', 'foreign_key' => 'lead_budget_id', 'show' => 'grid', "visualize" => true],
        'tax_rate' => ['tax_rate', 'class_name' => 'Tax_rate', 'foreign_key' => 'tax_rate_id', 'show' => 'grid'],
    ];



    /**static $entity_status_logs=[
        'Enquiry'=>[
            'entity'=>'Enquiry',
            'status'=>"interest_form_added",
            "entity_reference_key"=>'enquiry_id' 
        ]
            
    ];**/

    public function auto_add_data()
    {
        if ($this->is_auto_sale) {
        }
    }

    public function auto_create_sale()
    {
        if ($this->is_auto_sale) {
            foreach (Sale::transaction_fields() as $field) {
                if ($field == "id") {
                    continue;
                }
                if (isset($this->{$field})) {
                    $sale_data[$field] = $this->{$field};
                }
            }
            $sale_data['sale_offer_id'] = $this->id;
            $sale_data['is_auto_sale'] = 1;
            $sale_data['account_id'] = $this->account_id;
            $sale = Sale::create($sale_data);
        }
    }

    public function add_tax_rate_id()
    {
        if (!$this->tax_rate_id) {
            $unit = Unit::find($this->unit_id);
            $unit_group = $unit->unit_group;
            $this->tax_rate_id = $unit_group->tax_rate_id;
        }
    }

    public function propagate_status()
    {
        if ($this->unit_id) {
            $unit = Unit::find($this->unit_id);
            if ($this->is_cancelled) {
                if ($this->sale_interest_id) {
                    $sale_interest = Sale_interest::find($this->sale_interest_id);
                    $sale_interest->is_cancelled = 1;
                    $sale_interest->save();
                }
            } elseif ($this->is_verified) {
                $unit->status = "sold";
                $unit->enquiry_id = $this->enquiry_id;
                $unit->save();
            }
        }
    }


    public static function workflow_config()
    {
        return [
            'verified' => [
                "permissions" => ["review_letter_of_offers"],
                "condition" => "is_verified=0",
                'pending_label' => 'Pending Review',
                "after_approved" => ['update_unit_reservation'],
                /**"after_approve"=>function($workflow,$stage,$entity_data){
                    return;
                        $users=$workflow::workflow_stage_permitted_users('director_signed');
                        
                        foreach($users as $user)
                        {
                            $sms_message="A new Letter of offer has been queued pending your signature.";
                            die($sms_message);
                            Sms::send($sms_message,$user->phone);
                        }
                },**/
                "after_rejected" => function ($workflow, $stage, $entity_data) {
                    return;
                    $users = $workflow::workflow_stage_permitted_users($stage);
                    foreach ($users as $user) {
                        $sms_message = "The letter of offer submitted for review has been rejected.";
                        die($sms_message);
                        Sms::send($sms_message, $user->phone);
                    }
                },
                "use_batch_panel" => "payment_plans"
            ],
            'signed_by_directors' => [
                "permissions" => ["append_director_signature_to_letter_of_offers"],
                "condition" => "is_verified=1",
                'pending_label' => 'Pending Director',
            ],
            'client_emailed' => [
                'pending_label' => 'Pending ClientMail',
                "condition" => "is_signed_by_directors=1",
                "do_label" => "Email Client"
            ],
            'signed_by_client' => [
                'pending_label' => 'Pending ClientSign',
                "condition" => "is_client_emailed=1 AND is_signed_by_directors=1",
            ],
            'deposit_paid' => [
                'pending_label' => 'Pending Deposit',
                "condition" => "is_signed_by_client=1",
                "show_approved_menu" => true,
                'approved_label' => 'Deposit Paid',
            ],
            'cancelled' => [
                'editor_roles' => ['admin'],
                'cancel_roles' => ['admin'],
                'pending_label' => 'Cancel LOF',
                'approved_label' => 'Cancelled LOF',
                //"condition"=>"is_cancelled=0",
                //"after_approved"=>['update_unit_reservation'],
                "do_label" => "Cancel Reservation",
                "show_pending_menu" => false,
                "show_approved_menu" => true
            ],
        ];
    }





    public static function global_grid_actions()
    {
        $global_grid_actions = Sale_interest::global_grid_actions();
        $sale_offer_grid_actions = [
            'letter_of_offer' => [
                "text" => 'Preview',
                'target' => '_blank',
                'href' => Url::component("Sale_offer/print/{@id}"),
                //Exclude in these configs
                'excluded_configs' => []
            ]
        ];
        return array_merge($global_grid_actions, $sale_offer_grid_actions);
    }



    public static function config_edit_details($vars)
    {
        $config_data = static::config($vars);
        $config_data['grid_actions'] = [
            'view_payment_plans' => [
                'label' => 'Payment Plans',
                'text' => 'Payment Plans',
                'href' => Url::batch_panel('Sale_offer/payment_plans/{@id}')
            ],
            "upload_drawings" => [
                "label" => "Upload Drawings",
                "href" => Url::batch_panel("Sale_offer/sale_offer_documents/{@id}")
            ]
        ];
        return $config_data;
    }

    public static function config($vars = [])
    {


        return array(
            "before_form" => function ($result) {

                if ($result->is_verified) {
                    //return "<a target='_blank' href='".Url::component("Sale_offer/letter_of_offer/".$result->id)."'> Preview LOF</a>";
                }
            },
            "fields" => array(
                "name" => array("label" => "Client Name"),
                "email" => array("label" => "Client Email"),
                "phone" => array("label" => "Client Phone"),
                "company" => array("label" => "Company/Employer"),
                "customer_type_id" => array(
                    "label" => "Buyer Type", 'required' => true,
                    'model' => array('Customer_type', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])
                ),


                "interest_form_upload" => ['label' => 'Interest Form Upload', 'type' => 'file'],
                "nationality" => array("label" => "Nationality", "required" => true),
                "postal_address" => array("label" => "Postal Address"),
                "postal_code" => array("label" => "Postal Code"),
                "residential_address" => array("label" => "Residential Address"),
                "current_ownership_status" => array("label" => "Residential Category", "params" => ["owned" => "Owned", "rental" => "Rental"]),
                // "phone"=>array("label"=>"Phone","required"=>true),
                //"email"=>array("label"=>"Email","required"=>true),
                "age" => array("label" => "Age", "params" => ["18_25" => "18-25 Years", "25_35" => "25-35 Years", "35_45" => "34-45 Years", "45_55" => "45-55 Years", "55_65" => "55-65 Years", "over_65" => "Over 65 years"]),
                "gender" => array("label" => "Gender", "params" => ["male" => "Male", "female" => "Female", "other" => "Other"]),
                "race" => array("label" => "Race", "params" => [
                    "American Indian or Alaskan Native", "Asian / Pacific Islander", "Black or African American",
                    "Hispanic American", "White / Caucasian", "Multiple ethnicity"
                ]),
                "marital_status" => array("label" => "Marital Status", "params" => [
                    "not_applicable" => "Not Applicable", "married" => "Married",
                    "widowed" => "Widowed", "divorced" => "Divorced", "separated" => "Separated", "never_married" => "Never Married"
                ]),
                "education" => [
                    "label" => "Education", "params" => ["Less than high school degree", "High school degree or equivalent (e.g., GED)
                ", "Some college but no degree", "Associate degree", "Bachelor degree", "Graduate degree"]
                ],
                "employment_status" => [
                    'label' => 'Emplotment Status', 'params' => [
                        "employed" => "Employed",
                        "self_employed" => "Self Employed",
                        "student" => "Student",
                        "retired" => "Retired",
                        "unemployed" => "Unemployed"
                    ]
                ],

                //"employer_name"=>array("label"=>"Employer/Business Name"),
                "profession" => array("label" => "Profession"),
                "employment_position" => array("label" => "Position/Title"),
                "net_monthly_icome" => array("label" => "Monthly Icome"),
                "agent_id" => array("label" => "Account Exec", 'required' => true, 'model' => array(
                    'Acl_user', 'id',
                    ['first_name', 'last_name'], ["conditions" => ["role_id=? AND account_id=? AND deleted=0", Role::alias_id('agent'), Acl_user::account_id()], "prepend" => ["0" => "--Assigned Agent--"]]
                )),
                //"external_agent_name"=>array("label"=>"External Agent"),
                "lead_source_id" => array("label" => "Lead Source", 'required' => true, 'model' => array('Lead_source', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                "date_of_birth" => array("label" => "Date of Birth", "type" => "date"),
                "unit_id" => array(
                    "label" => "Unit", "readonly" => 1, 'required' => true,
                    'model' => array(
                        'Unit', 'id', 'title',
                        ['conditions' => ['account_id=? AND (status="reserved"||status="sold")', Acl_user::account_id()]]
                    )
                ),
                "budget" => array("label" => "Budget"),
                "payment_method_id" => array(
                    "label" => "Preferred Payment Method", 'required' => true,
                    'model' => array('Payment_method', 'id', 'title')
                ),
                "sale_price" => array("label" => "Sale Price", "required" => true),
                "tax_rate_id" => array(
                    "label" => "Tax Rate",
                    "model" => array(
                        "Tax_rate", "id", array("title"),
                        ["prepend" => ["" => '-Not Applicable-'], 'conditions' => ['account_id=?', Acl_user::account_id()]]
                    )
                ),
                "deposit" => array("label" => "Deposit", "required" => true),

                "identification_type" => array("label" => "Idenification Type", "params" => ["kenya_national_id" => "Kenya National ID", "passport" => "Passport"]),
                "identification_number" => array("label" => "Identification Number", "required" => true),


                "personal_identification_number" => array("label" => "PIN", "required" => true),
                "sale_offer_date" => array("label" => "Sale Offer Date", "type" => "date", "required" => true),
                "sale_offer_due_date" => array("label" => "Sale Offer Due Date", "required" => true, "type" => "date"),

                "enquiry_id" => array("label" => "Enquiry", "type" => "hidden", "required" => true),



            ),
            "grid_fields" => array(
                "enquiry_id" => array("label" => "Lead", 'required' => true, 'model' => array('Enquiry', 'id', 'name', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                "agent_id" => array("label" => "Agent", 'required' => true, 'model' => array('Agent', 'id', ["first_name", "last_name"], ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                "customer_type_id" => array(
                    "label" => "Buyer Type", 'required' => true,
                    'model' => array('Customer_type', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])
                ),

                "project_id" => array("label" => "Project", 'required' => true, 'model' => array('Project', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                //"court_id" => array("label" => "Court", 'required' => true, 'model' => array('Court', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                //"apartment_id" => array("label" => "Apartment", 'required' => true, 'model' => array('Apartment', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                //"block_id" => array("label" => "Block", 'required' => true, 'model' => array('Block', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                "unit_group_id" => array("label" => "Service Item", 'required' => true, 'model' => array('Unit_group', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                //"unit_id" => array("label" => "Unit", 'required' => true, 'model' => array('Unit', 'id', 'title', ['conditions' => ['account_id=? AND status="available"', Acl_user::account_id()]])),

                "sale_price" => array("label" => "Sale Price", "required" => true),
                "deposit" => array("label" => "Deposit", "required" => true),
                "tax_rate_id" => array(
                    "label" => "Tax Rate",
                    "model" => array(
                        "Tax_rate", "id", array("title"),
                        ["prepend" => ["" => '-Not Applicable-'], 'conditions' => ['account_id=?', Acl_user::account_id()]]
                    )
                ),
                "sale_offer_date" => array("label" => "Sale Offer Date", "type" => "date", "required" => true),
                "sale_offer_due_date" => array("label" => "Sale Offer Due Date", "required" => true, "type" => "date"),
            ),

            "filters" => true,
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),
            'form_actions' => static::form_actions(['save']),
            'grid_actions' => [
                'view' => [
                    'label' => 'View',
                    'text' => 'View',
                    'href' => Url::batch_panel('Sale_offer/payment_plans/{@id}')
                ]
            ],
            "form" => static::form_attrs(),
            "form_attrs" => ["window_location" => Url::grid_panel("Sale_offer")]


        );
    }

    public static function config_auto_sale($vars = [])
    {
        $config_data = static::config($vars);

        $config_data['fields']['sale_date'] = array("label" => "Actual Sale Date", "type" => "date", "required" => true);

        $config_data['fields']['is_verified'] = array("label" => "Is Sale Verified", "params" => yes_no(), "required" => true);
        $config_data['fields']['date_verified'] = array("label" => "Date Verified", "type" => "date", "required" => true);

        $config_data['fields']['is_directors_signed'] = array("label" => "Have Directors Signed", "params" => yes_no(), "required" => true);
        $config_data['fields']['date_signed_by_directors'] = array("label" => "Date Signed By Directors", "type" => "date", "required" => true);

        $config_data['fields']['is_client_signed'] = array("label" => "Has Client Signed", "params" => yes_no(), "required" => true);
        $config_data['fields']['date_signed_by_client'] = array("label" => "Date Signed By Client", "type" => "date", "required" => true);

        $config_data['fields']['is_auto_sale'] = array("label" => "Is Auto Sale", "value" => "1", "type" => "hidden", "required" => true);
        $config_data['form'] = static::form_attrs(["window_location" => Url::grid_panel("Sale")]);
        return $config_data;
    }

    public static function  ajaxfy_update_parent_units()
    {

        $updated_count = 0;
        $sale_offers = Sale_offer::all();
        foreach ($sale_offers as $sale_offer) {
            $unit = Unit::find($sale_offer->unit_id);

            if ($unit) {
                $updated_count++;
                $sale_offer->block_id = $unit->block_id;
                $sale_offer->project_id = $unit->project_id;
                $sale_offer->unit_group_id = $unit->unit_group_id;
                $sale_offer->court_id = $unit->court_id;
                $sale_offer->floor_id = $unit->floor_id;
                $sale_offer->apartment_id = $unit->apartment_id;
            } else {
                $updated_count++;
                $sale_offer->is_unit_invalid = 1;
            }

            $sale_offer->save();
        }
        json_render(['info' => 'success', 'message' => $updated_count]);
    }


    public static function ajaxfy_update_statuses()
    {
        $updates_log = [];
        foreach (Sale_offer::all() as $sale_offer) {
            //Reviewed
            //$sale_offer->is_reviewed=1;
            //$sale_offer->date_reviewed=$sale_offer->sale_offer_date;

            //Verified
            $sale_offer->is_verified = 1;
            $sale_offer->date_verified = $sale_offer->sale_offer_date;

            //Deposit Paid
            $sale_offer->is_deposit_paid = 1;
            $sale_offer->date_deposit_paid = $sale_offer->sale_offer_date;

            //Signed by Client
            $sale_offer->is_signed_by_client = 1;
            $sale_offer->date_signed_by_client = $sale_offer->sale_offer_date;

            //Signed by directors
            $sale_offer->is_signed_by_directors = 1;
            $sale_offer->date_signed_by_directors = $sale_offer->sale_offer_date;

            //Client Emailed
            $sale_offer->is_client_emailed = 1;
            $sale_offer->date_client_emailed = $sale_offer->sale_offer_date;
            $sale_offer->save();
            $updates_log[$sale_offer->id] = $sale_offer->id;
        }
        json_render($updates_log);
    }

    public static function ajaxfy_generate_contract_payments()
    {
        foreach (Sale::all() as $sale) {
            $sale_offer = Sale_offer::find($contract->sale_offer_id);
            foreach ($sale_offer->payments as $payment) {
                //Sale_payment::generate();
            }
        }
    }



    public static function ajaxfy_generate_contract()
    {
        $updates_log = [];
        foreach (Sale_offer::all(['conditions' => ['account_id=? AND is_sale_synched=0', Acl_user::account_id()]]) as $sale_offer) {

            $entity_data = [];
            foreach (Sale::columns() as $column) {
                if ($column == "id") {
                    continue;
                }

                if (isset($sale_offer->{$column})) {
                    $entity_data[$column] = $sale_offer->{$column};
                }
            }
            //$entity_data['is_reviewed']=1;
            //$entity_data['date_reviewed']=$sale_offer->sale_offer_date;

            $entity_data['is_verified'] = 1;
            $entity_data['date_verified'] = $sale_offer->sale_offer_date;

            $entity_data['is_client_emailed'] = 1;
            $entity_data['date_client_emailed'] = $sale_offer->sale_offer_date;

            $entity_data['is_signed_by_client'] = 1;
            $entity_data['date_signed_by_client'] = $sale_offer->sale_offer_date;

            $entity_data['is_signed_by_directors'] = 1;
            $entity_data['date_signed_by_directors'] = $sale_offer->sale_offer_date;

            $entity_data['is_legal_reviewed'] = 1;
            $entity_data['date_legal_reviewed'] = $sale_offer->sale_offer_date;

            $entity_data['is_stamp_duty_paid'] = 1;
            $entity_data['date_stamp_duty_paid'] = $sale_offer->sale_offer_date;

            $entity_data['is_legal_fees_paid'] = 1;
            $entity_data['date_legal_fees_paid'] = $sale_offer->sale_offer_date;

            $entity_data['is_legal_notified'] = 1;
            $entity_data['date_legal_notified'] = $sale_offer->sale_offer_date;

            $entity_data['is_legal_emailed'] = 1;
            $entity_data['date_legal_emailed'] = $sale_offer->sale_offer_date;

            $entity_data['is_deposit_paid'] = 1;
            $entity_data['date_deposit_paid'] = $sale_offer->sale_offer_date;

            $entity_data['sale_offer_id'] = $sale_offer->id;

            $sale = Sale::create($entity_data);
            $updates_log[$sale->id] = $sale->id;

            $sale_offer->sale_id = $sale->id;
            $sale_offer->is_sale_synched = 1;
            $sale_offer->save();
        }
        json_render($updates_log);
    }



    public static function ajaxfy_generate_sale_interest()
    {

        $updates_log = [];
        foreach (Sale_offer::all(['conditions' => ['account_id=? AND is_sale_interest_synched=0', Acl_user::account_id()]]) as $sale_offer) {
            $entity_data = [];
            foreach (Sale_interest::columns() as $column) {
                if ($column == "id") {
                    continue;
                }
                if (isset($sale_offer->{$column})) {
                    $entity_data[$column] = $sale_offer->{$column};
                }
            }
            $entity_data['account_id'] = Acl_user::account_id();
            $entity_data['is_verified'] = 1;
            $entity_data['sale_offer_id'] = $sale_offer->id;
            $entity_data['date_verified'] = $sale_offer->sale_offer_date;




            //$entity_data['is_reviewed']=1;
            $sale_interest = Sale_interest::create($entity_data);
            $updates_log[$sale_interest->id] = $sale_interest->id;
            $sale_offer->sale_interest_id = $sale_interest->id;
            $sale_offer->is_sale_interest_synched = 1;
            $sale_offer->save();
        }
        json_render($updates_log);
    }

    public static function ajaxfy_mark_units_as_sold()
    {
        $updates_log = [];
        foreach (Sale_offer::all() as $sale_offer) {
            $unit = Unit::find($sale_offer->unit_id);
            $unit->status = "sold";
            $unit->save();
            $updates_log[$unit->id] = $unit->id;
        }
        json_render($updates_log);
    }

    public static function ajaxfy_update_enquiry_details()
    {
        $updates_log = [];
        $with_no_enquiries = [];
        foreach (Sale_offer::all() as $sale_offer) {
            $enquiry = Enquiry::find_by_id_and_account_id($sale_offer->enquiry_id, Acl_user::account_id());
            if ($enquiry) {
                foreach (["salesify_campaign_id", "lead_interest_level_id", "current_ownership_status", "planned_transaction_month", "buying_reason"] as $field) {
                    if (isset($enquiry->{$field}) && in_array($field, Sale_offer::columns())) {
                        $sale_offer->{$field} = $enquiry->{$field};
                        $updates_log[$sale_offer->id] = $sale_offer->id;
                    }
                }
                $sale_offer->save();
            } else {
                //Create Enquiry
                $with_no_enquiries[$sale_offer->id] = $sale_offer->id;
            }
        }
        json_render(["count_no_enquiries" => count($with_no_enquiries), "updated" => $updates_log, "no_enquiries" => $with_no_enquiries]);
    }

    public static function ajaxfy_add_missing_enquiries()
    {
        //var_dump(Sale_offer::count(['conditions'=>['enquiry_id IS NULL']]));
        foreach (Sale_offer::all(['limit' => 20, 'order' => 'id DESC', 'conditions' => ['enquiry_id IS NULL']]) as $sale_offer) {
            //Create Enquiry
            foreach (['phone', 'name', 'email', 'customer_type_id', 'project_id', 'lead_source_id', 'agent_id'] as $field) {
                $enquiry_data[$field] = $sale_offer->{$field};
            }
            $enquiry_data['is_qualified'] = 1;
            $enquiry_data['qualify_status'] = "qualified";
            $enquiry_data['date_qualified'] = $sale_offer->sale_offer_date;
            $enquiry_data['enquiry_date'] = $sale_offer->sale_offer_date;
            $enquiry_data['is_direct_assignment'] = 1;
            $enquiry_data['account_id'] = Acl_user::account_id();
            $enquiry_data['audit_tag'] = "archived_sales_" . date("Y-m-d");

            if ($enquiry = Enquiry::find_by_phone_or_email_and_account_id(Str::to_254($enquiry_data['phone']), $enquiry_data['email'], Acl_user::account_id())) {
                var_dump("Found");
            } else {
                $enquiry = Enquiry::create($enquiry_data);
            }


            if ($enquiry) {
                $post_data = [
                    'audit_tag' => "archived_sales_" . date("Y-m-d"),
                    'account_id' => Acl_user::account_id(),
                    'agent_id' => $sale_offer->agent_id,
                    'enquiry_id' => $enquiry->id,
                    'date_assigned' => $sale_offer->sale_offer_date,
                    "is_active" => 1
                ];
                $account_exec = Enquiry_account_executive::create($post_data);
            }

            $sale_offer->enquiry_id = $enquiry->id;
            $sale_offer->save();
        }
    }






    public static function count_pending_client_signature()
    {
        return static::count(['conditions' => ["account_id=? AND deleted=? AND is_verified=1 
        AND is_client_signed=0", Acl_user::account_id(), 0]]);
    }

    public static function count_signed_by_client()
    {
        return static::count(['conditions' => ["account_id=? AND
         deleted=? AND is_verified=1 AND is_client_signed=1", Acl_user::account_id(), 0]]);
    }

    public static function config_pending_client_signature($vars)
    {
        $config_data = static::config($vars);
        $config_data['grid_actions'] = [
            "pending_signature" => [
                "href" => Url::form_panel(static::model_name() . "/{@id}/c/pending_client_signature"),
                "label" => "Mark As Signed"
            ]
        ];
        $config_data["conditions"] = ["account_id=? AND deleted=? AND 
        is_verified=1 AND is_client_signed=0", Acl_user::account_id(), 0];
        return $config_data;
    }

    public static function config_signed_by_client($vars)
    {
        $config_data = static::config($vars);
        $config_data['grid_actions'] = [];
        $config_data["conditions"] = ["account_id=? AND deleted=? AND is_verified=1 AND is_client_signed=1", Acl_user::account_id(), 0];
        return $config_data;
    }


    public static function config_contract($vars)
    {
        $config_data = static::config($vars);
        $config_data['grid_fields'] = [
            'name', 'phone', 'apartment_id', 'block_id', 'unit_id', 'sale_price'
        ];
        $config_data['conditions'] = array("account_id=? AND deleted=? AND is_deposit_paid=1 AND is_signed_by_client=1", Acl_user::account_id(), 0);
        $config_data['grid_actions'] = [
            'view' => ['text' => 'Add Contract', 'href' => Url::base(Portlet::get_active() . '/main/form_panel/Sale/clone/Sale_offer/id/{@id}')]
        ];
        return $config_data;
    }

    public function get_payment_plan_deposit()
    {
        return Payment_plan::sum(['sum' => "amount", "conditions" => ["sale_offer_id=? 
        AND 
        payment_item_id=?", $this->id, Payment_item::alias_id("deposit")]]);
    }

    public function get_payment_plan_deposit_details()
    {
        return Payment_plan::find(["conditions" => ["sale_offer_id=? 
        AND 
        payment_item_id=?", $this->id, Payment_item::alias_id("deposit")]]);
    }

    public function get_payment_plan_installments()
    {
        return Payment_plan::all(["conditions" => ["sale_offer_id=? 
        AND 
        payment_item_id<>?", $this->id, Payment_item::alias_id("deposit")]]);
    }

    public function component_print(&$data = [])
    {
        $data['logo'] = Session::user()->account->logo;
        $data['company_title'] = Session::user()->account->title;

        $template = Transaction_template::last(['conditions' => ['account_id=? AND template_type="letter_of_offer"', Session::user("account_id")]]);
        $print_template = ($template) ? $template->content : "";

        return $print_template;
    }
}