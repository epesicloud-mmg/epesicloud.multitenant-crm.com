<?php
class Sale_pipeline extends pPort_model
{

    static $table = 'sale_pipelines';
    static $name = 'Sales Pipelines';
    static $connection = 'smart_real_estate';

    static $has_many = [
        'enquiries' => ['enquiries', 'class_name' => 'Enquiry', 'foreign_key' => 'project_id'],
        'sale_interests' => ['sale_interests', 'class_name' => 'Sale_interest', 'foreign_key' => 'project_id'],
        'sales' => ['sales', 'class_name' => 'Sale', 'foreign_key' => 'project_id'],
        'sale_payments' => ['sale_payments', 'class_name' => 'Sale_payment', 'foreign_key' => 'project_id', 'summary_metric' => 'SUM(amount)'],
        'sale_stages' => ['sale_stages', 'class_name' => 'Sale_stage', 'foreign_key' => 'sale_pipeline_id'],
    ];

    static $after_save = ["add_default_stages"];

    public function add_default_stages()
    {
        if (!Sale_stage::exists(['conditions' => ['sale_pipeline_id=?', $this->id]])) {
            foreach (Sale_stage_default::all() as $default_stage) {
                $sale_stage_data = [
                    'sale_pipeline_id' => $this->id,
                    'account_id' => Session::user("account_id"),
                    'is_won_stage' => $default_stage->is_won_stage,
                    'title' => $default_stage->title,
                    'alias' => $default_stage->alias,
                    'description' => $default_stage->description
                ];
                Sale_stage::create($sale_stage_data);
            }
        }
    }

    public static function grid_actions_config()
    {
        return [
            'edit_with_stages' => function ($result) {
                return [
                    'label' => 'Edit',
                    'href' => Url::batch_panel("Sale_pipeline/sale_stages/{@id}")
                ];
            },
        ];
    }

    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "title" => array("label" => "Pipeline Name", "required" => true),
                "description" => array("label" => "Description", "type" => "textarea", "required" => true),
                "offer" => array("label" => "Offer Details *"),
                "value_proposition" => array("label" => "Value Proposition", "type" => "textarea"),
            ),
            "colspan" => 6,
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),
            "grid_actions" => static::grid_actions(['edit_with_stages']),
            "form_actions" => static::form_actions(),
            "form" => static::form_attrs(),
        );
    }


    public static function fetch_kanban_list_data($list_title, $list_id = NULL)
    {
        if ($list_id) {
            $list_data = [
                'id' => "" . $list_id . "",
                'title' => $list_title
            ];
        } else {
            $list_data = [
                'id' => "" . mt_rand() . "",
                'title' => $list_title
            ];
        }

        $limitVal = mt_rand(50, 50);

        $search_sql = "";
        if (isset($_GET['keyword'])  && $_GET['keyword'] != "") {
            $search_sql .= " AND (" . Enquiry::t("name") . " LIKE '%" . $_GET['keyword'] . "%'" . " OR " . Company::t("name") . " LIKE '%" . $_GET['keyword'] . "%') ";
        }

        if (isset($_GET['agent_id'])  && $_GET['agent_id'] != "") {
            $search_sql .= " AND " . Enquiry::t("agent_id") . " = " . $_GET['agent_id'] . " ";
        }


        if (isset($_GET['lead_interest_level_id']) && $_GET['lead_interest_level_id'] != "") {
            $search_sql .= " AND " . Enquiry::t("lead_interest_level_id") . " = " . $_GET['lead_interest_level_id'] . " ";
        }



        //die("select  " . Enquiry::t("*") . " from " . Enquiry::t() . " INNER JOIN " . Company::t() . " ON " . Enquiry::t("company_id") . "=" . Company::t("id") . " WHERE sale_stage_id IS NULL AND deleted=0 " . $keyword_sql);

        if ($list_id) {
            $sql = "select " . Enquiry::t("*") . " from " . Enquiry::t() . "  WHERE sale_stage_id=" . $list_id . " AND " . Enquiry::t('deleted') . "=0 " . $search_sql . "  ORDER BY RAND() limit 0," . $limitVal;
        } else {
            $sql = "select  " . Enquiry::t("*") . " from " . Enquiry::t() . "  WHERE sale_stage_id IS NULL AND " . Enquiry::t('deleted') . "=0 " . $search_sql;
        }



        $activities = Enquiry::find_by_sql($sql);


        $activities_list = [];
        $colors = ["hot" => "danger", "warm" => "success", "cool" => "warning", "cold" => "info"];

        foreach ($activities as $enquiry) {
            $lead_interest_level = Lead_interest_level::find($enquiry->lead_interest_level_id);
            if ($lead_interest_level) {
                $lead_interest_level_alias = $lead_interest_level->alias ?: "cool";
            } else {
                $lead_interest_level_alias = "cool";
            }

            $enquiry_name = $enquiry->name;
            $company = Company::find($enquiry->company_id);
            if ($company) {
                $enquiry_name = $company->name . " (" . $enquiry->name . ")";
            }

            $activities_list_data = [
                "id" => $enquiry->id,
                //"id" => $activity->id,
                "title" =>  $enquiry_name,
                "border" => "success",
                "enquiryDate" => date("Y-m", strtotime($enquiry->enquiry_date)),
                "comment" => 1,
                "call" => 1,
                "attachment" => 3,
                "notesCount" => $enquiry->notes_count,
                "documentsCount" => $enquiry->documents_count,
                "meetingsCount" => $enquiry->meetings_count,
                "callsCount" =>  $enquiry->calls_count,
                "activitiesCount" => $enquiry->lead_activities_count,
                "meeting" => 3,
                "badgeContent" => @substr($enquiry->agent->first_name, 0, 1) . "" . @substr($enquiry->agent->last_name, 0, 1),
                "badgeColor" => $colors[$lead_interest_level_alias]
            ];
            /**$activities_list_data["users"] = [
                Url::ui_asset() . "images/portrait/small/avatar-s-11.png"
            ];**/
            $activities_list[] = $activities_list_data;
        }
        $list_data["item"] = $activities_list;
        $list_data['title'] = $list_title . "-" . $list_id . " (" . count($activities_list) . ")";
        return $list_data;
    }




    public static function kanban_data($sale_pipeline_id = NULL)
    {
        if (isset($_GET['sale_pipeline_id'])) {
            $sale_pipeline_id = $_GET['sale_pipeline_id'];
        } elseif ($sale_pipeline_id == NULL) {
            $sale_pipeline = Sale_pipeline::last(['conditions' => ['account_id=?', Session::user('account_id')]]);
            $sale_pipeline_id = $sale_pipeline->id;
        }
        $sale_stages_list = [];
        if ($sale_pipeline_id) {
            $sale_stage_list_data = Sale_stage::all(['order' => 'id ASC', 'conditions' => ['deleted=0 AND sale_pipeline_id=?', $sale_pipeline_id], 'limit' => 10]);
        } else {
            $sale_stage_list_data = Sale_stage::all(['order' => 'id ASC', 'conditions' => ['deleted=0'], 'limit' => 10]);
        }

        //$sale_stages_list[] = static::fetch_kanban_list_data("Incoming");

        foreach ($sale_stage_list_data as $list) {
            $sale_stages_list[] = static::fetch_kanban_list_data($list->title, $list->id);
        }



        return $sale_stages_list;
    }

    public static function ajaxfy_update_stage()
    {
        $raw_post_data = php_request_data();
        $post_data['account_id'] = Session::user("account_id");
        $post_data['user_id'] = Session::user("id");
        $post_data['enquiry_id'] = arr("enquiry_id", $raw_post_data);
        $post_data['source_sale_stage_id'] =  arr("source_sale_stage_id", $raw_post_data);
        $post_data['target_sale_stage_id'] = arr("target_sale_stage_id", $raw_post_data);
        Sale_stage_update::create($post_data);
    }
}
