<?php
class Sms_template extends Title_description
{
    static $connection = 'smart_real_estate';
    static $table = 'sms_templates';
    static $title = "Sms Template";
    static $description = "(Manage Email Templates)";


    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "title" => array("label" => "Template Name", "required" => true),
                //"subject" => array("label" => "Subject", "required" => true),
                "body" => array("label" => " Body", "required" => true, "type" => "textarea"),
            ),
            "colspan" => 6,
            "grid_actions" => static::grid_actions()
        );
    }
}