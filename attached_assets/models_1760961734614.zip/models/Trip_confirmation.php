<?php
/**
 * 
 * @author Martin Muriithi <martin@pporting.org>
 *
 **/
class Trip_confirmation extends Trip_lead
{
    public static function config($vars=[])
    {
        $config_data=Trip_lead::config($vars);
        $config_data['form_actions']=static::form_actions();
       
        unset($config_data['fields']['attendance_date']);
        unset($config_data['fields']['attendance_status']);
        $config_data['conditions']=array("account_id=?",Acl_user::account_id());
        
        return $config_data;
    }

}