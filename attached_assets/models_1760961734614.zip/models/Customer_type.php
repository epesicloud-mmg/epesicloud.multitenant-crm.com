<?php

/**
 *
 * @author <Martin Muriithi> <martin@pporting.org>
 */
class Customer_type extends pPort_model
{

    static $table_name = "customer_types";
    static $primary_key = "id";
    static $connection = 'smart_real_estate';

    static $before_save = array('add_account_creator');

    static $title = 'Customer Type';
    static $description = 'Manage Customer types';
    static $has_many = [
        'enquiries' => ['enquiries', 'class_name' => 'Enquiry', 'foreign_key' => 'customer_type_id'],
        'sale_interests' => ['sale_interests', 'class_name' => 'Sale_interest', 'foreign_key' => 'customer_type_id'],
        'sales' => ['sales', 'class_name' => 'Sale', 'foreign_key' => 'customer_type_id'],
    ];


    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "title" => array("label" => "Title"),
                "description" => array("label" => "Description (Optional)", "type" => "textarea")
            ),
            "cols" => 1,
            "build_config" => true,
            "conditions" => ["account_id=?", Acl_user::account_id()]

        );
    }
}