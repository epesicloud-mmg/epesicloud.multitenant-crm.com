<?php

/**
 * Handles User to Groups Many-to-many Lead_activitys
 *
 * User_group Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Sale_payment extends pPort_model
{
    static $table = 'sale_payments';
    static $title = "Sale Payments";
    static $description = "(Record purchases made in your business)";
    static $connection = 'smart_real_estate';



    public static function config($vars = [])
    {
        $sale_id = isset($vars['sale_id']) ? $vars['sale_id'] : Session::get('collection_model');
        $conditions = Session::get('collection_model') ? ['sale_id=' . Session::get('collection_model')] : array("account_id=?", Acl_user::account_id());

        return array(
            "fields" => array(
                "payment_item_id" => array("label" => "Payment Item", "model" => array("Payment_item", "id", "title")),
                "amount" => array("label" => "Amount Received."),
                "transaction_date" => array("label" => "Payment Date", "type" => "date"),
                "payment_method_id" => array("label" => "Payment Method", "model" => array("Payment_method", "id", "title")),
                "sale_id" => ['value' => $sale_id, 'label' => 'Sale', "type" => "hidden"],

            ),
            "hidden_fields" => ["sale_id"],
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),

            "grid_actions" => static::grid_actions(),
            "form" => static::form_attrs(),
            "form_actions" => static::form_actions(),
        );
    }

    public static function config_collect($vars)
    {
        $sale = new Sale();
        $sale_id = NULL;
        if (isset($vars['sale_id'])) {
            $sale_id = arr('sale_id', $vars, NULL);
            $sale = Sale::find($sale_id);
        }

        return array(
            "fields" => array(

                "enquiry_id" => array("label" => "Customer", "model" => array("Enquiry", "id", "name", ["conditions" => ["id=?", $sale->enquiry_id]])),
                "payment_item_id" => array("label" => "Payment Item", "model" => array("Payment_item", "id", "title")),
                "payment_method_id" => array("label" => "Payment Method", "model" => array("Payment_method", "id", "title")),
                "amount" => array("label" => "Amount Received."),
                "transaction_date" => array("label" => "Payment Date", "type" => "date"),
                "sale_id" => array("label" => "SaleID", "type" => "hidden", "value" => $sale_id),
            ),
            "grid_fields" => array(

                "enquiry_id" => array("label" => "Customer", "model" => array("Enquiry", "id", "name")),
                "payment_item_id" => array("label" => "Payment Item", "model" => array("Payment_item", "id", "title")),
                "payment_method_id" => array("label" => "Payment Method", "model" => array("Payment_method", "id", "title")),
                "amount" => array("label" => "Amount Received."),
                "transaction_date" => array("label" => "Payment Date", "type" => "date"),
            ),
            "cols" => 2,
            "hidden_fields" => ["sale_id"],
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),

            "grid_actions" => static::grid_actions(),
            "form" => static::form_attrs(['window_location' => Url::grid_panel('Sale_payment')]),
            "form_actions" => static::form_actions(),
        );
    }

    public static function month_balances()
    {
        return 23450;
    }

    public static function month_total_paid()
    {
        return 12345670;
    }
}
