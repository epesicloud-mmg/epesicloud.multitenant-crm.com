<?php
/**
 *
 * @author <Martin Muriithi> <martin@pporting.org>
 */
class Lead_source_category extends Title_description
{

    static $table_name="lead_source_categories";
    static $primary_key="id";
    static $connection='smart_real_estate';
    static $title='Lead Source Category';
 

    
}

?>