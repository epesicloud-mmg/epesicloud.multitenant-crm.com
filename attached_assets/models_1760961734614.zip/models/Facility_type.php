<?php
class Facility_type extends Title_description
{
    static $connection='smart_real_estate';
    static $table='facility_types';
    static $title="Facility Type";
    
}