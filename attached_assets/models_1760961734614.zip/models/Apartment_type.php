<?php
class Apartment_type extends pPort_model
{
    static $connection='smart_real_estate';
    static $table='apartment_types';
    static $title="Apartment_type";
    static $description="(Manage Apartment_type)";
    static $before_save=array('add_account');
    public function add_account()
    {
        $this->account_id=Acl_user::account_id();
    }
    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "title"=>array("label"=>"Title *"),
                "description"=>array("label"=>"Description","type"=>"textarea"),
            ),
            "cols"=>2,
            "conditions"=>array("account_id=?",Acl_user::account_id()),
            "build_config"=>true,

        );
    }
}