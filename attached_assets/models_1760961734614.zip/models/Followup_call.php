<?php

/**
 * Handles User lead_activities
 *
 * User Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Followup_call extends pPort_model
{

    static $table = 'followup_calls';
    static $name = "Calls";
    static $title = 'Calls';
    static $description = 'Calls';
    static $connection = 'smart_real_estate';
    static $belongs_to = [
        'enquiry' => ["enquiry", "foreign_key" => "enquiry_id", "class_name" => "Enquiry"],
        'account_executive' => ["account_executive", "foreign_key" => "agent_id", "class_name" => "Agent"],
        'followup_type' => ["followup_type", "foreign_key" => "followup_type_id", "class_name" => "Followup_type"]
    ];

    //calls by month
    /**SELECT date_format(`followup_calls`.`followup_date`,'%Y-%m') AS year_month1,acl_users.first_name,acl_users.last_name,COUNT(*) FROM followup_calls INNER JOIN epesi_acl_master.acl_users ON followup_calls.agent_id=epesi_acl_master.acl_users.id GROUP BY date_format(`followup_calls`.`followup_date`,'%Y-%m'), agent_id ORDER BY date_format(`followup_calls`.`followup_date`,'%Y-%m') DESC **/
}
