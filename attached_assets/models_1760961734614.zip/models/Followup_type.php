<?php

/**
 * Handles User lead_activities
 *
 * User Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Followup_type extends pPort_model
{

    static $table = 'followup_types';
    static $title = 'Followup Type';
    static $description = '(Manage Followup Types)';
    static $before_save = array('add_account');
    static $connection = 'smart_real_estate';

    static $has_many = [
        'followups' => ['followups', 'class_name' => 'Followup', 'foreign_key' => 'followup_type_id']
    ];

    function add_account()
    {
        $this->account_id = Acl_user::account_id();
    }

    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "title" => array("label" => "Type Name"),
                "description" => array("label" => "Description", "type" => "textarea"),

            ),
            "cols" => 1,
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),

            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions(),
            "form" => static::form_attrs(),
        );
    }
}
