<?php

/**
 * Handles User lead_activities
 *
 * User Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Payment_item extends pPort_model
{

    static $table = 'payment_items';
    static $title = 'Payment Items';
    static $description = '(Manage Payment Types)';
    static $before_save = array('add_account');
    static $connection = 'smart_real_estate';

    function add_account()
    {
        $this->account_id = Acl_user::account_id();
    }

    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "title" => array("label" => "Type Name"),
                "description" => array("label" => "Description", "type" => "textarea"),

            ),
            "cols" => 1,
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),

            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions(),
            "form" => static::form_attrs(),
        );
    }
}
