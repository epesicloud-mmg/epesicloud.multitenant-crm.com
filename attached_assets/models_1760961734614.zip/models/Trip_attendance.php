<?php
/**
 * 
 * @author Martin Muriithi <martin@pporting.org>
 *
 **/
class Trip_attendance extends Trip_lead
{

    public static function global_grid_actions()
    {
        return [];
    }

    public static function config($vars=[])
    {
        $config_data=Trip_lead::config($vars);
        $config_data['form_actions']=static::form_actions();
        $config_data['grid_actions']=[];
        
        unset($config_data['fields']['confirmation_date']);
        unset($config_data['fields']['confirmation_status']);
        unset($config_data['fields']['confirmation_notes']);
        $config_data['conditions']=array("account_id=? AND attendance_status='present'",Acl_user::account_id());
        return $config_data;
    }

    public static function config_bookings_per_lead($vars=[])
    {
        static::$title="Visits per lead per project";
        $sql="SELECT lead_id,".static::t("project_id").",".Lead::t('name')." AS lead_name FROM ".static::t()." INNER JOIN ".Lead::t()." ON 
        ".static::t('lead_id')."=".Lead::t("id")." WHERE ".static::t('account_id')."=".Acl_user::account_id()." 
        GROUP BY lead_id,".static::t("project_id");
        
        return [
            'find_by_sql'=>$sql,
            'fields'=>[
                'lead_name'=>['label'=>'Lead Name'],
                'project_id'=>['label'=>'Project','value'=>function($result){
                    $project=Project::find($result->project_id);
                    if($project)
                    {
                        return $project->title;
                    }
                    
                }],
                'trip_visits'=>['label'=>'No.Visits','value'=>function($result){
                   return Trip_lead::count(['conditions'=>['project_id=? AND lead_id=?',$result->project_id,$result->lead_id]]);
                    
                }],
            ],
        "grid_actions"=>[]

        ];
    }

    public static function config_bookings_per_supervisor($vars=[])
    {
        static::$title="Bookings per supervisor per trip";
        $sql="SELECT ".static::t("supervisor_id").",trip_id,CONCAT(".Acl_user::t("first_name").",' ',".Acl_user::t("last_name").") AS
         supervisor_name
        FROM ".static::t()."
        INNER JOIN ".Supervisor::t()." ON 
        ".static::t('supervisor_id')."=".Supervisor::t("id")." 
        WHERE ".static::t('account_id')."=".Acl_user::account_id()." GROUP BY supervisor_id,trip_id";
       
       
        return [
            'find_by_sql'=>$sql,
            'fields'=>[
                'supervisor_name'=>['label'=>'Supervisor Name'],
                'trip_id'=>['label'=>'Trip','value'=>function($result){
                    $trip=Trip::find($result->trip_id);
                    if($trip)
                    {
                        return $trip->title."(".$trip->trip_date->format("Y-m-d").")";
                    }
                    
                }],
                'bookings'=>['label'=>'Bookings','value'=>function($result){
                   return Trip_lead::count(['conditions'=>['trip_id=? AND supervisor_id=?',$result->trip_id,$result->supervisor_id]]);                    
                }],
                'attended'=>['label'=>'Attended','value'=>function($result){
                    return Trip_lead::count(['conditions'=>['trip_id=? AND supervisor_id=? AND attendance_status="present"',$result->trip_id,$result->supervisor_id]]);                    
                 }],
                 'absent'=>['label'=>'Absent','value'=>function($result){
                    return Trip_lead::count(['conditions'=>['trip_id=? AND supervisor_id=? AND attendance_status="absent"',$result->trip_id,$result->supervisor_id]]);                    
                 }],
                /**'agents_count'=>['label'=>'Agents Count','value'=>function($result){
                    $agents_involved=Trip_lead::count(['group'=>'agent_id','conditions'=>['trip_id=? AND supervisor_id=?',$result->trip_id,$result->supervisor_id]]);                    
                    $total_agents=Agent::count(['conditions'=>['account_id=?',$result->supervisor_id]]);
                    return $agents_involved." of ".$total_agents;
                }]**/
            ],
        "grid_actions"=>[]

        ];
    }
   
    public static function config_bookings_per_agent($vars=[])
    {
        static::$title="Bookings per agent per trip";
        $sql="SELECT ".static::t("agent_id").",trip_id,CONCAT(".Acl_user::t("first_name").",' ',".Acl_user::t("last_name").") AS
         agent_name
        FROM ".static::t()."
        INNER JOIN ".Agent::t()." ON 
        ".static::t('agent_id')."=".Agent::t("id")." 
        WHERE ".static::t('account_id')."=".Acl_user::account_id()." GROUP BY ".static::t('agent_id').",trip_id";
       
        
        
        return [
            'find_by_sql'=>$sql,
            'fields'=>[
                'agent_name'=>['label'=>'Agent Name'],
                'trip_id'=>['label'=>'Trip','value'=>function($result){
                    $trip=Trip::find($result->trip_id);
                    if($trip)
                    {
                        return $trip->title."(".$trip->trip_date->format("Y-m-d").")";
                    }
                    
                }],
                'bookings'=>['label'=>'Bookings','value'=>function($result){
                   return Trip_lead::count(['conditions'=>['trip_id=? AND agent_id=?',$result->trip_id,$result->agent_id]]);                    
                }],
                'attended'=>['label'=>'Attended','value'=>function($result){
                    return Trip_lead::count(['conditions'=>['trip_id=? AND agent_id=? AND 
                    attendance_status="present"',$result->trip_id,$result->agent_id]]);                    
                 }],
                 'absent'=>['label'=>'Absent','value'=>function($result){
                    return Trip_lead::count(['conditions'=>['trip_id=? AND agent_id=? AND 
                    attendance_status="absent"',$result->trip_id,$result->agent_id]]);                    
                 }],
            ],
        "grid_actions"=>[]

        ];
    }

    

}