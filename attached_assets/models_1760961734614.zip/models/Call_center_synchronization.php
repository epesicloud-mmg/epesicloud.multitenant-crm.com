<?php

/**
 * 
 * @author Martin Muriithi <martin@pporting.org>
 *
 **/
class Call_center_synchronization extends Title_description
{
    static $connection = 'smart_real_estate';
    static $table = 'call_center_synchronizations';
    static $title = "Call Center Sync";
    static $description = "Call Center Sync";

    static $belongs_to = [
        "enquiry" => ["enquiry", "class_name" => "Enquiry", "foreign_key" => "enquiry_id"],
        "agent" => ["agent", "class_name" => "Agent", "foreign_key" => "agent_id"]
    ];

    public static function sync($account_id = NULL)
    {
        $account_id = $account_id ?: Session::user()->account_id;
        $_REQUEST['account_id'] = $account_id;
        $last_synchronized = Call_center_synchronization::last(['conditions' => ['account_id=?', $account_id]]);

        $from_id = 0;

        if ($last_synchronized) {
            $from_id = $last_synchronized->call_id;
        }
        $url = 'https://salesify.epesicloud.com/call/api_v1_/search';

        // Setup cURL
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_POST => TRUE,
            CURLOPT_RETURNTRANSFER => TRUE,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
            CURLOPT_POSTFIELDS => json_encode(['from_id'=>$from_id])
        ));

        // Send the request
        $response = curl_exec($ch);

        $response_data = [];
        if ($response === FALSE) {
        } else {
            $response_data = json_decode($response, TRUE);
        }


        foreach ($response_data as $call_item) {
            static::submit($call_item);
        }
    }

    public static function action_post($data=[])
    {
        $data=php_request_data();
        $enquiry=Enquiry::find_by_phone($data['client_phone']);
        $agent = Agent::find_by_email($data['agent_email']);
        $agent = Agent::find($data['agent_id']);
        $parsed_data=[
            'account_id' => arr('account_id',$data),
            'enquiry_id' => $enquiry ? $enquiry->id : NULL,
            'client_phone' => arr('client_phone',$data),
            'call_start_time' => arr('call_start_time',$data),
            'call_end_time' => arr('call_end_time',$data),
            'call_duration' => arr('call_duration',$data),
            'recording' => arr('recording',$data),
            'summary' => arr('summary',$data),
            'transcription' =>arr('entity_transcription_data',$data),
            'entity_data' =>arr('entity_extraction_data',$data),
            'external_call_type' => arr('external_call_type',$data),
            'call_agent_id' =>arr('agent_id',$data),
            'call_agent_name' => arr('agent_name',$data),
            'call_agent_phone' => arr('agent_phone',$data),
            'call_agent_email' => arr('agent_email',$data),
            'call_id' => arr('id',$data),            
            'agent_id' => $agent ? $agent->id : NULL
        ];
        
        $call_center_synchronization=Call_center_synchronization::find(['conditions' => ['call_id=?', $parsed_data['call_id']]]);
        

        if ($call_center_synchronization) {
            $call_center_synchronization->update_attributes($parsed_data);
        } else {
            $call_center_synchronization = Call_center_synchronization::create($parsed_data);
        }
        return ['info'=>'success','data'=>$call_center_synchronization->to_array()];
    }


    public  function try_sync($call_center_followup)
    {
        if (!$this->enquiry_id) {
            $enquiry_data = [
                'agent_id' => $call_center_followup->agent_id,
                'phone' => $call_center_followup->client_phone,
                "account_id" => $call_center_followup->account_id,
                "enquiry_date" => $call_center_followup->call_date
            ];
            //This will be too expensive and will lead to many empty records on enquiry
            //$enquiry = Enquiry::create($enquiry_data);
        } else {
            $enquiry = $call_center_followup->enquiry;
            $followup_data = [
                'enquiry_id' => $this->enquiry_id,
                'followup_type_id' => Lead_activity_type::alias_id_or_create("call_center"),
                'description' => "Call Center (" . $call_center_followup->call_agent_name . ")" . $call_center_followup->external_call_type . " for " . $enquiry->phone . " on " . $call_center_followup->call_time . ".",
                //'resource_link' => $call_center_followup->recording,
                'linked_entity' => 'Call_center_synchronization',
                'linked_entity_reference' => $call_center_followup->id,
                "account_id" => $call_center_followup->account_id,
                'agent_id' => $call_center_followup->agent_id,
                "followup_date" => $call_center_followup->call_date,
                "followup_time" => $call_center_followup->call_start,
                "meta_data" => json_encode($call_center_followup->to_array())
            ];

            if (Lead_activity::exists(['conditions' => ['linked_entity=? AND followup_time=? AND enquiry_id=?', 'Call_center_synchronization', date("Y-m-d H:i:s", strtotime($call_center_followup->call_time)), $enquiry->id]])) {
            } else {
                $lead_activity = Lead_activity::create($followup_data);
                $call_center_followup->lead_activity_id = $lead_activity->id;
                $call_center_followup->save();
            }
        }
    }
    public static function post_followups($enquiry)
    {
        $enquiry = is_object($enquiry) ? $enquiry : Enquiry::find($enquiry);
        $call_center_followups = Call_center_synchronization::all(['conditions' => ['account_id=? AND lead_activity_id IS NULL AND client_phone LIKE "%' . $enquiry->phone . '%"', $enquiry->account_id]]);

        foreach ($call_center_followups as $call_center_followup) {
            static::sync_followup($enquiry, $call_center_followup);
        }
    }


    public static function fields_config()
    {



        return array(
            //Inbound, Outbound, Missed
            "external_call_type" => array("label" => "CallType",  "required" => true),
            "enquiry_id" => ['label' => "Lead", "model" => ["Enquiry", 'id', 'name']],
            "client_phone" => array("label" => "ClientPhone"),
            "call_date" => array("label" => "CallDate", "value" => date("Y-m-d"), "required" => true, "format" => "date"),
            "call_time" => array("label" => "CallTime", "params" => hours_range(), "required" => true),
            "call_duration" => array("label" => "CallDuration",  "required" => true),
            "call_agent_email" => array("label" => "AgentMail",  "required" => true),
            "call_agent_phone" => array("label" => "AgentPhone",  "required" => true),
            "call_agent_name" => array("label" => "AgentName",  "required" => true),
            "recording" => array("label" => "Recording", "target" => "blank", "href" => function ($result) {
                return $result->recording;
            },  "required" => true),




        );
    }
}
