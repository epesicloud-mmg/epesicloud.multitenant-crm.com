<?php

class Lead_note extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'lead_notes';
    static $title = "Lead Notes";
    static $description = "(Lead Note)";
    static $before_create = ["add_agent_id"];
    static $after_create = ["add_lead_activity"];

    function add_agent_id()
    {
        if (!$this->agent_id) {
            $this->agent_id = Session::get("user_id");
        }
    }

    function add_lead_activity()
    {
        Lead_activity::create([
            'enquiry_id' => $this->enquiry_id,
            'followup_type_id' => Lead_activity_type::alias_id_or_create("followup_note"),
            'followup_type_id' => Lead_activity_type::alias_id_or_create("followup_note"),
            'description' => $this->description,
            "account_id" => $this->account_id,
            'linked_entity' => 'Lead_note',
            'linked_entity_reference' => $this->id,
            'followup_date' => date("Y-m-d"),
            'followup_time' => date("Y-m-d H:i:s"),
            'agent_id' => $this->agent_id,
            'location_meta_data' => $this->location_meta_data,
            "meta_data" => json_encode($this->to_array()),

        ]);
    }


    public static function config($vars = [])
    {
        $config_data = array(
            "fields" => array(
                //"title"=>array("label"=>"Title","required"=>true),                
                "description" => array("label" => "Add your note details...", "required" => true),
                "enquiry_id" => array("label" => "Select Lead", "model" => ["Enquiry", "id", "name", ["prepend" => ["" => "-Select Client-"], "conditions" => ["account_id=?", Acl_user::account_id()]]]),

            ),
        );
        if (isset($_REQUEST['enquiry_id'])) {
            $config_data['fields']['enquiry_id'] = ['label' => "Select Lead", "type" => "hidden", "value" => $_REQUEST['enquiry_id']];
        }
        return $config_data;
    }
}