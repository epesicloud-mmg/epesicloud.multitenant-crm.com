<?php

/**
 * Handles User lead_activities
 *
 * User Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Followup_scheduled_visit extends pPort_model
{

    static $table = 'followup_scheduled_visits';
    static $name = "Scheduled Visits";
    static $title = 'Scheduled Visits';
    static $description = 'Visits';
    static $connection = 'smart_real_estate';
    static $belongs_to = [
        'enquiry' => ["enquiry", "foreign_key" => "enquiry_id", "class_name" => "Enquiry"],
        'account_executive' => ["account_executive", "foreign_key" => "agent_id", "class_name" => "Agent"],
        'followup_type' => ["followup_type", "foreign_key" => "followup_type_id", "class_name" => "Followup_type"]
    ];
}
