<?php
class Enquiry extends pPort_model
{
    static $table = 'enquiries';
    static $title = "Leads";
    static $name = "Lead";
    static $enabled_for_time_range = true;
    static $description = "(Record customer enquiries)";
    static $connection = 'smart_real_estate';
    static $before_save = ["add_account_creator","process_auto_qualify", "add_is_qualified", "add_default_lead_stage", 'sync_qualify_status', "auto_add_contact_id", "auto_add_company_id", "auto_add_agent_id", "add_supervisor_id"];
    static $after_save = ['assign_account_executive', 'sync_to_marketing_list'];
    static $before_create = ["check_if_lead_exists", "add_enquiry_date"];
    static $after_create = ["send_admin_alert"];
    static $belongs_to = [
        'project' => ["project", "foreign_key" => "project_id", "class_name" => "Project", "drill_down" => ["Project", "Lead_source"], "visualize" => "Pie", "filter" => true],
        'lead_source' => ["lead_source", "foreign_key" => "lead_source_id", "class_name" => "Lead_source", "visualize" => "Pie"],
        'supervisor' => ["supervisor", "foreign_key" => "supervisor_id", "class_name" => "Supervisor", "drill_down" => ["Supervisor", "Agent"], "visualize" => "Pie"],
        'agent' => ["agent", "foreign_key" => "agent_id", "class_name" => "Agent", "visualize" => "Pie"],
        'customer_type' => ["customer_type", "foreign_key" => "customer_type_id", "class_name" => "Customer_type", "visualize" => "Column"],
        'account_executive' => ["account_executive", "foreign_key" => "agent_id", "class_name" => "Agent"],
        'lead_interest_level' => ["lead_interest_level", "foreign_key" => "lead_interest_level_id", "class_name" => "Lead_interest_level"],
        'industry' => ["industry", "foreign_key" => "industry_id", "class_name" => "Industry"],
        'originator_type' => ["originator_type", "foreign_key" => "originator_type_id", "class_name" => "Originator_type"],
        'sale_stage' => ["sale_stage", "foreign_key" => "sale_stage_id", "class_name" => "Sale_stage"],
        'company' => ["company", "foreign_key" => "company_id", "class_name" => "Company"],
        'qualification_status_type' => ["qualification_status_type", "foreign_key" => "qualification_status_type_id", "class_name" => "Qualification_status_type"],

    ];
    static $filter_date = "enquiry_date";
    static $has_many = [
        'enquiry_agents' => ["enquiry_agents", "foreign_key" => "enquiry_id", "class_name" => "Enquiry_account_executive"],
        'lead_contacts' => ["lead_contacts", "foreign_key" => "enquiry_id", "class_name" => "Lead_contact"],
        'call_center_synchronizations' => ["call_center_synchronizations", "foreign_key" => "enquiry_id", "class_name" => "Call_center_synchronization"]
    ];

    static $has_one = [
        "sale_interest" => ["sale_interest", "foreign_key" => "enquiry_id", "class_name" => "Sale_interest"],
        "sale_offer" => ["sale_offer", "foreign_key" => "enquiry_id", "class_name" => "Sale_offer"],
        "sale" => ["sale", "foreign_key" => "enquiry_id", "class_name" => "Sale"]
    ];
    //public $is_direct_assignment=0;

    static $validates_presence_of = array(
        array('name'),
        array('phone'),
        //array('email'),        
        array('project_id'),
    );

    public function fetch_calls()
    {
       
        return Call_center_call::all(['conditions'=>['enquiry_id=?',$this->id]]);
    }

    public function sync_to_marketing_list()
    {

        if ($this->project_id) {
            $project = Project::find($this->project_id);
            if ($project->audience_id) {
                $contact_data = [
                    'name' => $this->name,
                    'email' => $this->email,
                    'phone' => $this->phone,
                    'audience_id' => $project->audience_id,
                    'account_id' => $this->account_id,
                    'contact_date' => $this->enquiry_date,
                    'project_id' => $this->project_id,
                    'industry_id' => $this->industry_id
                ];
                Contact::create_account($contact_data);
            }
        }
    }


    public function get_company_contact_name()
    {
        return $this->company ? $this->company->name . " (" . $this->name . ")" : $this->name;
    }

    public function add_default_lead_stage()
    {
        //If no sales_stage_assign_default
        if (!$this->sale_stage_id) {
            if ($this->project_id) {
                $project = Project::find($this->project_id);
                if ($project->sale_pipeline_id) {
                    $sale_stage = Sale_stage::first(['conditions' => ['sale_pipeline_id=?', $project->sale_pipeline_id]]);
                    if ($sale_stage) {
                        $this->sale_stage_id = $sale_stage->id;
                    }
                } else {
                    $first_sale_pipeline = Sale_pipeline::first();
                    $stages = $first_sale_pipeline->sale_stages;
                    if (count($stages)) {
                        $this->sale_stage_id = $stages[0]->id;
                    }
                }
            }
        }
    }

    public function randomly_allocate_agent()
    {
        $users = Acl_user::all(['conditions' => ['account_id=? AND deleted=0 AND role_id=?', Session::account_id(), Role::alias_id("agent")]]);
        $random_user=$users[array_rand($users)];
        $this->agent_id=$random_user->id;
    }
    

    public function process_auto_qualify()
    {
        $auto_qualify_enabled=true;
        if($auto_qualify_enabled)
        {
            $this->qualification_status_type_id=Qualification_status_type::alias_id("qualified");
            if($this->agent_id==null)
            {
                $this->randomly_allocate_agent();
            }
        }
    }

    public function sync_qualify_status()
    {
        if (Qualification_status_type::alias($this->qualification_status_type_id) == "qualified") {
            $this->qualify_status = "qualified";
        } else if (Qualification_status_type::alias($this->qualification_status_type_id) == "declined") {
            $this->qualify_status = "not_qualified";
        }
    }



    public function send_admin_alert()
    {
        if ($this->agent_id == NULL) {
            $users = Acl_user::all(['conditions' => ['account_id=? AND deleted=0 AND role_id=?', Session::account_id(), Role::alias_id("admin")]]);
            foreach ($users as $user) {
                $phone = $user->phone;
                Sms::send("Hello, you have a new lead pending assignmnent. Kindly qualify the lead.", $phone);
            }
        }
    }


    public static function ajaxfy_update_lead_source_id()
    {
        $sql = "SELECT DISTINCT(lead_source) FROM `enquiries` WHERE `lead_source_id` IS NULL  AND lead_source<>'' AND account_id=" . Session::user("account_id");

        $raw_lead_sources = static::find_by_sql($sql);
        $not_tracable = [];
        $lead_sources[] = $raw_lead_sources[0];

        foreach ($lead_sources as $raw_lead_source) {
            $lead_source = Lead_source::find(['conditions' => ['account_id=? AND title LIKE "%' . $raw_lead_source->lead_source . '%"', 2]]);
            if (!$lead_source) {
                $lead_source = Lead_source::create([
                    'account_id' => Session::user("account_id"),
                    "title" => $raw_lead_source->lead_source,
                ]);
            }
            if ($lead_source) {
                $enquiries = Enquiry::all(["limit" => 500, "conditions" => ["lead_source=? AND lead_source_id IS NULL AND account_id=" . Session::user("account_id"), $raw_lead_source->lead_source]]);

                foreach ($enquiries as $enquiry) {
                    $enquiry->lead_source_id = $lead_source->id;
                    $enquiry->save();
                }
                $sync_results[$raw_lead_source->lead_source] = ["enquiries" => count($enquiries)];
            } else {
                $sync_results[$raw_lead_source->lead_source] = ["lead_source" => $raw_lead_source->lead_source, "tracable" => false];
            }
        }
        json_render($sync_results);
    }

    public function add_supervisor_id()
    {
        if ($this->agent_id) {
            $agent = Agent::find($this->agent_id);
            $this->supervisor_id = $agent->supervisor_id;
        }
    }



    public static function grid_actions_config()
    {
        return [
            'change_sale_stage' => function ($result) {
                return [
                    'label' => 'Update Stage',
                    'href' => Url::form_panel("Sale_stage_update/enquiry_id/{@id}")
                ];
            },
            'create_sale_interest' => function ($result) {
                return [
                    'label' => 'Create Sale Interest',
                    'href' => Url::form_panel("Sale_interest/clone/Enquiry/id/{@id}")
                ];
            },
            "activity_feed" => function ($result) {
                return [
                    "label" => 'Client Feed',
                    //'target' => '_blank',
                    'href' => Url::portlet("main/feed/{@id}"),
                    'excluded_configs' => []
                ];
            },
            "review_lead" => [
                "text" => "View",
                "href" => function ($result) {
                    if (Session::get('role_alias') == "agent") {

                        return Url::form_panel("Enquiry/" . $result->id . "/config/qualify");
                        if ($result->created_by != $result->agent_id) {
                            return "javascript:alert('You can only edit leads added by you. Contact your sale admin');";
                        } else {
                            return Url::form_panel("Enquiry/" . $result->id . "/config/qualify");
                        }
                    } else {
                        return Url::form_panel("Enquiry/" . $result->id . "/config/qualify");
                    }
                },
            ],

            "manage_contacts" => [
                "text" => function ($result) {
                    return "Manage Contacts (" . count($result->lead_contacts) . ")";
                },

                "href" => function ($result) {
                    return Url::batch_panel("Enquiry/lead_contacts/" . $result->id);
                }
            ],
            "create_home_owner" =>  function ($result) {
                if (!Sale::exists(['conditions' => ['enquiry_id=?', $result->id]])) {
                    return [
                        "label" => 'Create Home Owner',
                        'target' => '_blank',
                        'href' => Url::portlet("main/form_panel/Sale/clone/Enquiry/id/{@id}"),
                        'excluded_configs' => []
                    ];
                }

                return false;
                //https://salesify.epesicloud.com/hom/main/form_panel/Sale/clone/Enquiry/id/45669
            },

        ];
    }

    public function add_is_qualified()
    {
        if (Qualification_status_type::alias($this->qualification_status_type_id) == "qualified" || $this->is_qualified == 1) {
            $this->is_qualified = 1;
            $this->date_qualified = $this->date_qualified ?: date("Y-m-d");
        } else {
            $this->is_qualified = 0;
            $this->date_qualified = NULL;
        }
    }


    public function add_enquiry_date()
    {
        if (!$this->enquiry_date) {
            $this->enquiry_date = date("Y-m-d");
        }
    }


    public function auto_add_company_id()
    {
        if ($this->company_name && $this->company_id == NULL) {
            $company = Company::find_or_create([
                'name' => $this->company_name,
                'phone' => $this->phone,
                'email' => $this->email,
                "description" => $this->description
            ], ['name=?', $this->company_name]);
            $this->company_id = $company->id;
        }
    }

    public function auto_add_contact_id()
    {
        if ($this->name) {
            if ($this->phone) {
                $check = "phone=?";
                $check_val = $this->phone;
            } elseif ($this->email) {
                $check = "email=?";
                $check_val = $this->email;
            }
            if ($this->phone != NULL || $this->email != NULL) {
                $contact = Contact::find_or_create([
                    'name' => $this->name,
                    'account_id' => $this->account_id,
                    'phone' => $this->phone,
                    'email' => $this->email,
                    'company_id' => $this->company_id,
                    "description" => $this->description
                ], ['(' . $check . ')', $check_val]);
                $this->contact_id = $contact->id;
            }
        }
    }

    public function auto_add_agent_id()
    {
        if ($this->agent_id == NULL && $this->is_qualified) {
            //Select randomly from the pool of account_executives
            $agent_ids = [];
            foreach (Account_executive::all(['conditions' => ['account_id=? AND role_id=? AND deleted=0', $this->account_id, Role::alias_id('agent', $this->account_id)]]) as $account_exec) {
                $agent_ids[$account_exec->id] = $account_exec->id;
            }
            $random_key = array_rand($agent_ids);
            $this->agent_id = $random_key;
        }
    }




    public function assign_account_executive()
    {
        //Temporarily disabled

        if (!$this->is_qualified) {
            return;
        }
        if ($this->is_direct_assignment || $this->is_reassignment) {
            //No need to re-assign as the direct assignment already occurred : that is on Assign Account Executive Module
            return;
        }
        $account_exec = Enquiry_account_executive::last(['conditions' => ['enquiry_id=?', $this->id]]);
        $post_data = [
            'account_id' => $this->account_id,
            'agent_id' => $this->agent_id,
            'enquiry_id' => $this->id,
            'send_assignment_sms' => $this->send_assignment_sms,
            'date_assigned' => date('Y-m-d')
        ];
        if ($account_exec) {
            if ($account_exec->agent_id != $this->agent_id) {
                $post_data['is_reassignment'] = 1;
                $post_data['account_id'] = $this->account_id;
                $post_data['reassignment_from_id'] = $account_exec->id;
                $account_exec->is_active = 1;
                $account_exec->save();
                Enquiry_account_executive::create($post_data);
                return;
            }
        }
        Enquiry_account_executive::create($post_data);
    }





    public function check_if_lead_exists()
    {

        if ($this->csv_upload_token) {
            return NULL;
        }
        $post_data = [];
        foreach ([
            'name', 'email',
            'phone',
            'company_name',
            'postal_code',
            'lead_source_id', 'description', 'is_enquiry'
        ] as $field) {
            $post_data[$field] = $this->{$field};
        }
        if (is_email($this->email)) {
            $lead = Enquiry::find(['conditions' => ['account_id=? AND (email LIKE "%' . $this->email . '%")', Acl_user::account_id()]]);
            if ($lead) {
                //$lead->update_attributes($post_data);
                exit(json_encode(["info" => "error", "message" => "A lead already exists with those details including e-mail  (" . $this->email . ")."]));
            }
        }


        if ($this->phone != NULL && $this->phone != "" && $this->phone != strtolower(str_replace("/", "", str_replace(" ", "", "NA")))) {
            $last_9_digits_check = $this->phone;
            if (strlen($last_9_digits_check) > 8) {
                $last_9_digits_check = substr($last_9_digits_check, -9);
            }
            $lead = Enquiry::find(['conditions' => ['account_id=? AND (phone LIKE "%' . $last_9_digits_check . '%")', Acl_user::account_id()]]);
            if ($lead) {
                exit(json_encode(["info" => "error", "message" => "A lead already exists with those details including phone (" . $this->phone . ")."]));
            }
        }
    }







    public static function pending_followup_count($params = [])
    {
        $sql = static::dynamic_date_filter('enquiry_date', $params);
        $sql_addition = " AND followups.account_id=" . Acl_user::account_id();
        if (Session::get('role_alias') == "supervisor") {
            $sql_addition = " AND followups.supervisor_id=" . Session::get("user_id") . " AND followups.account_id=" . Acl_user::account_id();
        } elseif (Session::get('role_alias') == "agent") {
            $sql_addition = " AND followups.agent_id=" . Session::get("user_id") . " AND followups.account_id=" . Acl_user::account_id();
        }

        /**$sql="SELECT COUNT(*) AS pending_count
        FROM enquiries WHERE is_qualified=1 
        AND ".$sql." AND enquiries.account_id=".Session::user("account_id")." 
         AND enquiries.id NOT IN(SELECT enquiry_id FROM followups WHERE account_id=".Acl_user::account_id().") ";**/

        $sql = "SELECT COUNT(*) AS pending_count
        FROM enquiries WHERE is_qualified=1 
        AND " . $sql . " AND enquiries.account_id=" . Session::user("account_id") . " 
         AND (status='open' OR status='assigned_agent') ";
        $results = static::find_by_sql($sql);


        return $results[0]->pending_count;
    }

    public static function pending_followup_count_by_month()
    {
        $data = [];
        $results = static::find_by_sql("SELECT COUNT(*) AS pending_count,date_format(enquiries.enquiry_date,'%Y-%m') AS year_month_date
        FROM enquiries WHERE enquiries.account_id=" . Acl_user::account_id() . "
         AND enquiries.id NOT IN(SELECT enquiry_id FROM followups WHERE account_id=" . Acl_user::account_id() . ") AND
          is_qualified=1 GROUP BY date_format(enquiries.enquiry_date,'%Y-%m')");

        foreach ($results as $result) {
            $data[$result->year_month_date] = $result->pending_count;
        }
        return $data;
    }

    public static function count_reassignments()
    {
        return static::count(['conditions' => static::conditions_reassigned()]);
    }

    public static function query_reassignments_pending($count = 0)
    {
        $result_select = "enquiries.*";
        if ($count) {
            $result_select = " COUNT(*) AS results_count";
        }
        $sql = "SELECT " . $result_select . "
        FROM enquiries WHERE is_qualified=1 AND is_reassignment=1
        AND " . static::dynamic_date_filter("date_agent_assigned") . " AND enquiries.account_id=" . Session::user("account_id") . " 
         AND enquiries.id 
         NOT IN(SELECT enquiry_id FROM followups WHERE account_id=" . Acl_user::account_id() . " AND followup_date>=enquiries.date_agent_assigned)";
        return $sql;
    }

    public static function conditions_reassigned()
    {
        return ["is_qualified=1 AND is_reassignment=1"];
    }


    public static function count_reassignments_pending()
    {
        $results = static::find_by_sql(static::query_reassignments_pending(true));
        return $results[0]->results_count;
    }




    public static function config_reassigned_pending($vars = [])
    {
        $config_data = static::config($vars);
        $sql = static::query_reassignments_pending();
        $config_data["fields"]["date_agent_assigned"] = ["label" => "Date Re-assigned"];
        $config_data["fields"]["reassignment_from_id"] = array(
            "label" => "Re-assigned From",
            'model' => array(
                'Agent', 'id',
                ['first_name', 'last_name'], ["conditions" => ["role_id=? AND account_id=? AND deleted=0", Role::alias_id('agent'), Acl_user::account_id()]]
            )
        );
        $config_data["grid_fields"] = ["date_agent_assigned", "reassignment_from_id", "enquiry_date", "project_id", "lead_source_id", "agent_id", "name", "phone", "email", 'qualification_status_type_id'];

        $config_data["find_by_sql"] = $sql;
        return $config_data;
    }

    public static function config_reassigned($vars = [])
    {
        $config_data = static::config($vars);
        $config_data["fields"]["date_agent_assigned"] = ["label" => "Date Re-assigned"];
        $config_data["fields"]["reassignment_from_id"] = array(
            "label" => "Re-assigned From",
            'model' => array(
                'Agent', 'id',
                ['first_name', 'last_name'], ["conditions" => ["role_id=? AND account_id=? AND deleted=0", Role::alias_id('agent'), Acl_user::account_id()]]
            )
        );
        $config_data["grid_fields"] = ["date_agent_assigned", "reassignment_from_id", "enquiry_date", "project_id", "lead_source_id", "agent_id", "name", "phone", "email", 'qualification_status_type_id'];

        $config_data["conditions"] = static::conditions_reassigned();
        return $config_data;
    }

    public static function config_planned_site_visit($vars = [])
    {
        $sql = "SELECT enquiries.*
        FROM enquiries WHERE is_qualified=1 
        AND " . static::dynamic_date_filter("enquiry_date") . " 
        AND enquiries.account_id=" . Session::user("account_id") . " 
         AND enquiries.id NOT IN(SELECT enquiry_id FROM followups 
         WHERE account_id=" . Acl_user::account_id() . " AND followup_type_id<>" . Followup_type::alias_id("site_visit_scheduling") . ")";

        $config_data = static::config($vars);
        $config_data["find_by_sql"] = $sql;
        return $config_data;
    }

    public static function config_pending_followup($vars = [])
    {
        $sql = "SELECT enquiries.*
            FROM enquiries WHERE is_qualified=1 
            AND " . static::dynamic_date_filter("enquiry_date") . " AND enquiries.account_id=" . Session::user("account_id") . " 
             AND enquiries.id NOT IN(SELECT enquiry_id FROM followups WHERE account_id=" . Acl_user::account_id() . ")";

        $config_data = static::config($vars);
        $config_data["find_by_sql"] = $sql;
        return $config_data;
    }



    public static function config($vars = [])
    {

        $config_data = array(
            "fields" => static::fields([
                "enquiry_date", "company_id", "name", "email", "phone", "employee_range_id", "industry_id", "originator_type_id", "lead_source_id", "customer_type_id", "lead_interest_level_id",
                "project_id", "unit_group_id", "deal_amount", "agent_id", "qualification_status_type_id", 'sale_stage_id',  "country_id", "zone_id", "address", "postal_code", "closure_month_id", "description", "is_enquiry",
            ]),
            "order" => "enquiry_date DESC",
            "limit" => 600,
            "grid_fields" => ["company_id", "name", "phone", "email", "enquiry_date", "estimate_closure_date", "project_id", "lead_source_id", "agent_id", 'sale_stage_id', 'qualification_status_type_id'],
            "conditions" => array("account_id=? AND deleted=? ", Acl_user::account_id(), 0),
            "grid_actions" => static::grid_actions(),
            'form_actions' => static::form_actions(),
            "form" => static::form_attrs(),


        );

        if (Session::user()->role->alias == "agent") {
            if (isset($config_data['fields']['qualification_status_type_id'])) {
                unset($config_data['fields']['qualification_status_type_id']);
            }
        }
        return $config_data;
    }

    public static function next_account_executive($field = NULL)
    {
        //If already assigned no need to look for another
        if (static::$model_id) {
            $enquiry = Enquiry::find(static::$model_id);
            if ($enquiry->agent_id) {
                return $enquiry->agent_id;
            }
        }

        $last_exec = Account_executive::last(['conditions' => ['account_id=? AND deleted=0', Acl_user::account_id()]]);

        $last_enquiry = Enquiry::last(['conditions' => ['account_id=? 
                AND 
                agent_id IS NOT NULL', Acl_user::account_id()]]);

        if (is_object($last_enquiry)) {
            if ($last_enquiry->agent_id == $last_exec->id) {
                $first_exec = Account_executive::first(['conditions' => ['account_id=? AND deleted=0', Acl_user::account_id()]]);
                return $first_exec;
            }
            $account_exec = Account_executive::first(['conditions' => ['account_id=? AND deleted=0 AND id>?', Acl_user::account_id(), $last_enquiry->agent_id]]);
        } else {
            $account_exec = new Account_executive();
        }

        return $field ? $account_exec->{$field} : $account_exec;
    }

    public static function bulk_actions_config()
    {
        /**return [
            'approve'=>[
                'label'=>'Approve All',
                'handler'=>function($all_selected){
                    foreach($all_selected as $entity)
                    {
                        return 20;
                    }
                    return 20;
                }
            ],
            'qualify'=>[
                'label'=>'Qualify All',
                'handler'=>function($all_selected){
                    foreach($all_selected as $entity)
                    {

                    }
                }
            ],
        ];**/
    }


    public static function config_bulk_qualify($vars = [])
    {
        return static::config_qualify($vars);
    }




    public static function config_qualify($vars)
    {
        $account_exec = arr('agent_id', $vars, NULL);
        $config = static::config($vars);
        if (Session::get('role_alias') == "admin") {
            $config["form"] = static::form_attrs([
                'window_location' => Url::grid_panel("Enquiry/config/qualify")
            ]);
        }
        $config["grid_actions"] = [
            "qualify_lead" => [
                "text" => "Review & Qualify",
                "href" => Url::form_panel("Enquiry/{@id}/config/qualify"),
            ],
        ];




        //$config['fields']['planned_transaction_month']['required'] = true;
        //$config['fields']['buying_reason']['required'] = true;
        //$config['fields']['preferred_property_location']['required']=true;

        if (Session::get('role_alias') == "agent") {
            unset($config['fields']['agent_id']);
        }

        //$config['conditions']=array("account_id=? AND deleted=?  AND is_qualified=0",Acl_user::account_id(),0);
        $config['conditions'] = array("account_id=? AND deleted=? AND qualification_status_type_id=" . Qualification_status_type::alias_id("pending"), Acl_user::account_id(), 0);



        if (Session::get('role_alias') == "admin" && arr("config", $vars) == "bulk_qualify") {
            $config['bulk_actions'] = [
                'qualify_lead' => [
                    'label' => 'Qualify All Selected',
                    'handler' => ["Lead_qualification", "bulk_process_entries"]
                ],
                'decline_lead' => [
                    'label' => 'Decline All Selected',
                    'handler' => ["Lead_qualification", "bulk_process_entries"]
                ],
            ];
        }
        return $config;
    }



    public static function config_not_qualified($vars)
    {
        $config = static::config_qualified($vars);
        $config['conditions'] = array("account_id=? AND deleted=? AND qualification_status_type_id=" . Qualification_status_type::alias_id("declined"), Acl_user::account_id(), 0);
        return $config;
    }







    public static function config_sale_interest($vars)
    {
        static::$title = "Sale Interest Forms";
        return array(
            "fields" => static::fields(['enquiry_date', 'name', 'email', 'phone', 'company_id', 'industry_id', 'agent_id']),
            "conditions" => array("account_id=? AND deleted=? AND is_qualified=1", Acl_user::account_id(), 0),
            "order" => "id DESC",
            "limit" => 300,
            "filters" => true,
            "grid_actions" => [
                'view' => ['text' => 'Add Sale Interest Form', 'href' => Url::form_panel('Sale_interest/clone/Enquiry/id/{@id}')]
            ],

            'form_actions' => static::form_actions(),
            "form" => static::form_attrs(['window_location' => Url::grid_panel('Sale')]),
            "grid_fields" => ["enquiry_date", "name", "email", "phone", 'sale_interest_count', "agent_id"]

        );
    }





    public function get_lead_activities_count($lead_activity_type = NULL)
    {
        $lead_activity_type_id = Followup_type::alias_id($lead_activity_type);
        $lead_activity_type_sql = $lead_activity_type ? " AND followup_type_id=" . $lead_activity_type_id : "";

        $count_query = "SELECT COUNT(*) AS lead_activities_count 
                        FROM " . Followup::t() . " 
                        WHERE deleted=0 AND enquiry_id=" . $this->id . $lead_activity_type_sql;

        $query_results = Followup::find_by_sql($count_query);
        return $query_results[0]->lead_activities_count;
    }

    public function get_followups_per_month($year, $month)
    {
        $sql = 'SELECT * FROM ' . Followup::t() . ' WHERE followup_date LIKE "%' . $year . "-" . $month . '%" AND enquiry_id=' . $this->id;
        return Followup::find_by_sql($sql);
    }


    public function get_agents()
    {
        $account_executives = [];
        foreach (Enquiry_account_executive::all(["group" => "agent_id", "conditions" => ["enquiry_id=?", $this->id]]) as $enquiry_account_executive) {
            $account_executives[] = $enquiry_account_executive->account_executive;
        }
        return $account_executives;
    }

    public static function tracking_by_agent()
    {
        $tracking_data = static::tracking_by_lead_source();
        $tracking_data['summary_entity_condition'] = "role_id=" . Role::alias_id("agent") . " AND  account_id=" . Acl_user::account_id();
        $tracking_data['summary_entity'] = 'Agent';
        $tracking_data['summary_entity_display_fields'] = ['first_name', 'last_name'];
        $tracking_data['title'] = "Analysis By Agent";
        unset($tracking_data['entities']['Enquiry']['all']);
        unset($tracking_data['entities']['Enquiry']['qualified']['show_percentage']);
        return $tracking_data;
    }

    public static function tracking_by_agent_pending()
    {
        $tracking_data = static::tracking_by_lead_source();
        $tracking_data['summary_entity_condition'] = "role_id=" . Role::alias_id("agent") . " AND  account_id=" . Acl_user::account_id();
        $tracking_data['summary_entity'] = 'Agent';
        $tracking_data['summary_entity_display_fields'] = ['first_name', 'last_name'];
        $tracking_data['title'] = "Analysis By Agent";
        $tracking_data['entities'] = [
            'Enquiry' => [
                'all' => [
                    'label' => 'Leads'
                ],
                'qualified' => [
                    'label' => 'Qualified',
                    'show_percentage' => ['Enquiry_all', 'Enquiry_qualified'],
                    'condition' => 'is_qualified=1'
                ],
            ],
            'Followup' => [
                'site_visit_count' => [
                    'label' => 'Site Visits',
                    'show_percentage' => ['Enquiry_qualified', 'Followup_site_visit_count'],
                    'condition' => "followup_type_id=" . Lead_activity_type::alias_id("site_visit_checkout")
                ],
            ],
            'Sale_interest' => [
                'completed' => ['label' => 'Completed BIFs', 'condition' => 'is_verified=1'],
                'not_completed' => ['label' => 'Incomplete BIFs', 'condition' => 'is_verified=0'],
            ],
            'Sale_offer' => [
                'is_client_emailed' => [
                    'label' => 'LOF Sent',
                    'condition' => 'is_client_emailed=0',
                    'show_percentage' => ['Enquiry_qualified'],
                ],
                'signed_by_client_and_deposit' => [
                    'label' => 'LOF Sent',
                    'condition' => 'is_client_emailed=1 AND is_deposit_paid=1',
                    'show_percentage' => ['Enquiry_qualified'],
                ],
                'signed_by_client_and_deposit' => [
                    'label' => 'LOF Pending',
                    'condition' => 'is_client_emailed=1 AND is_signed_by_client=0',
                    'show_percentage' => ['Enquiry_qualified'],
                ],
            ],
            'Sale' => [
                'emailed_client' => [
                    'label' => 'AFL Sent',
                    'condition' => 'is_client_emailed=0',
                    'show_percentage' => ['Enquiry_qualified'],
                ],
                'signed_by_client' => [
                    'label' => 'AFL Signed & Costs Paid',
                    'condition' => 'is_signed_by_client=1',
                    'show_percentage' => ['Enquiry_qualified'],
                ]
            ]
        ];

        return $tracking_data;
    }

    public static function tracking_by_lead_source()
    {

        return $report_builder = [
            "return_fields" => true,
            'title' => 'Summary By Lead Source',
            'report_entity' => 'Enquiry',
            'report_entity_foreign_key' => 'enquiry_id',
            'report_date_field' => 'enquiry_date',
            'report_select_fields' => [
                'project_id' => [
                    'name' => 'project_id',
                    'display_value' => 'title',
                    'model' => 'Project'
                ],
                'salesify_campaign_id' => [
                    'name' => 'salesify_campaign_id',
                    'display_value' => 'title',
                    'model' => 'Salesify_campaign'
                ]
            ],
            "show_cummulatives" => true,
            'summary_entity' => 'Lead_source',
            "summary_entity_condition" => "account_id=" . Acl_user::account_id(),
            'entities' => [
                'Enquiry' => [
                    'all' => [
                        'label' => 'Leads'
                    ],
                    'qualified' => [
                        'label' => 'Qualified',
                        'show_percentage' => ['Enquiry_all', 'Enquiry_qualified'],
                        'condition' => 'is_qualified=1'
                    ],
                ],
                'Followup' => [
                    'site_visit_count' => [
                        'label' => 'Site Visits',
                        'show_percentage' => ['Enquiry_qualified', 'Followup_site_visit_count'],
                        'condition' => "followup_type_id=" . Lead_activity_type::alias_id("site_visit_checkout")
                    ],
                ],
                'Sale_interest' => [
                    'completed' => ['label' => 'Completed BIFs', 'condition' => 'is_verified=1'],
                    'not_completed' => ['label' => 'Incomplete BIFs', 'condition' => 'is_verified=0'],
                ],
                'Sale_offer' => [
                    'is_client_emailed' => [
                        'label' => 'LOF Sent',
                        'condition' => 'is_client_emailed=0',
                        'show_percentage' => ['Enquiry_qualified'],
                    ],
                    'signed_by_client_and_deposit' => [
                        'label' => 'LOF Signed & Deposit Paid',
                        'condition' => 'is_client_emailed=1 AND is_deposit_paid=1',
                        'show_percentage' => ['Enquiry_qualified'],
                    ],
                    'signed_by_client_and_deposit_pending' => [
                        'label' => 'LOF Pending',
                        'condition' => 'is_client_emailed=1 AND is_signed_by_client=0',
                        'show_percentage' => ['Enquiry_qualified'],
                    ],
                ],
                'Sale' => [
                    'emailed_client' => [
                        'label' => 'AFL Sent',
                        'condition' => 'is_client_emailed=0',
                        'show_percentage' => ['Enquiry_qualified'],
                    ],
                    'signed_by_client' => [
                        'label' => 'AFL Signed & Costs Paid',
                        'condition' => 'is_signed_by_client=1',
                        'show_percentage' => ['Enquiry_qualified'],
                    ],
                    /**'cash_buyers' => [
                        'label' => 'Cash Buyers',
                        'condition' => Sale::t('customer_type_id') . '=' . Customer_type::alias_id("cash_buyer"),
                    ],
                    'mortgage_buyers' => [
                        'label' => 'Mortgage Buyers',
                        'condition' => Sale::t('customer_type_id') . '=' . Customer_type::alias_id("mortgage_buyer"),

                    ],**/
                    'total_buyers' => [
                        'label' => 'Total Buyers',
                        'condition' => Sale::t() . '.deleted=0',
                        'show_percentage' => ['Enquiry_qualified'],
                        'percentage_label' => "Conversion rate"
                    ],

                ],
            ]
        ];
    }



    function get_sale_interest()
    {
        return Sale_interest::last(['conditions' => ['enquiry_id=?', $this->id]]);
    }

    function get_sale_offer()
    {
        return Sale_offer::last(['conditions' => ['enquiry_id=?', $this->id]]);
    }

    function get_sale()
    {
        return Sale::last(['conditions' => ['enquiry_id=?', $this->id]]);
    }



    public function get_calls_count()
    {
        return Followup::count(['conditions' => ['enquiry_id=? AND followup_type_id=?', $this->id, Followup_type::alias_id("call")]]);
    }

    public function get_emails_count()
    {
        return Followup::count(['conditions' => ['enquiry_id=? AND followup_type_id=?', $this->id, Followup_type::alias_id("email")]]);
    }

    public function get_sms_count()
    {
        return Followup::count(['conditions' => ['enquiry_id=? AND followup_type_id=?', $this->id, Followup_type::alias_id("sms")]]);
    }

    public function get_notes_count()
    {
        return Followup::count(['conditions' => ['enquiry_id=? AND followup_type_id=?', $this->id, Followup_type::alias_id("followup_note")]]);
    }

    public function get_documents_count()
    {
        return Lead_document::count(['conditions' => ['enquiry_id=?', $this->id]]);
    }

    public function get_meetings_count()
    {
        return Followup::count(['conditions' => ['enquiry_id=? AND followup_type_id=?', $this->id, Followup_type::alias_id("meeting_checkout")]]);
    }

    public function get_site_visits_count()
    {
        return Followup::count(['conditions' => ['enquiry_id=? AND followup_type_id=?', $this->id, Followup_type::alias_id("site_visit_checkout")]]);
    }

    public function get_current_interest_level()
    {
        $last_followup = Followup::last(['conditions' => ['enquiry_id=?', $this->id]]);
        if ($last_followup) {
            return Lead_interest_level::alias($last_followup->lead_interest_level_id) ?: "warm";
        }
        return "no_followup";
    }

    public function get_call_stage()
    {
        $count = Followup::count(['conditions' => ['enquiry_id=? AND followup_type_id=?', $this->id, Followup_type::alias_id("call")]]);
        return $count ? "On " . ordinalize($count) . " call" : "No Call";
    }

    public function get_last_lead_activity_date()
    {
        $last_followup = Followup::last(['conditions' => ['enquiry_id=?', $this->id]]);

        return $last_followup ? $last_followup->followup_date : NULL;
    }

    public function get_all_lead_activities_count()
    {
        return Followup::count(['conditions' => ['enquiry_id=?', $this->id]]);
    }

    public function get_average_response_time()
    {
        $last_followup = Followup::last(['conditions' => ['enquiry_id=?', $this->id]]);
        if ($last_followup) {
            return round(abs(the_difference($this->enquiry_date, $last_followup->followup_date)) / $this->lead_activities_count);
        }
        return "never_followed_up";
    }



    public function get_aging()
    {
        return the_difference($this->enquiry_date, date("Y-m-d"));
    }

    public function get_lead_activities()
    {
        $followups = Followup::all(['conditions' => ['enquiry_id=?', $this->id]]);
        $followups_string = "<h5>" . count($followups) . "-Lead Activities</h5>";
        if (count($followups) > 0) {
            $followups_string = "<ul>";
            foreach ($followups as $followup) {
                $followup_type = $followup->followup_type ? $followup->followup_type->title : "Uncategorized";
                $followups_string .= "<li>" . $followup_type . "(Followup Date : " . date("Y-m-d", strtotime($followup->followup_date)) . ", Note : " . $followup->description . ")</li>";
            }
            $followups_string .= "</ul>";
        }
        return $followups_string;
    }




    public static function fields_config()
    {
        //BANT [Budget, Authority[CEO],Need [],Timeline[2-Months]]
        $fields = array(
            "enquiry_date" => array("label" => "Opportunity/Enquiry Date", "type" => "date", "value" => date("Y-m-d"), "format" => "date"),
            "name" => array("label" => "Contact Name", "required" => true),
            "email" => array("label" => "Email"),
            "phone" => array("label" => "Phone", "placeholder" => "Phone (Type 'NA' if not available)"),
            "designation_type_id" => ["label" => "Designation Type",  "type" => "text", "model" => ["Designation_type", "id", "title"]],

            //"company_name" => array("label" => "Company"),
            "company_id" => ["label" => "Company", "enable_quick_entry" => true, "type" => "text", "model" => ["Company", "id", "name"]],



            "industry_id" => array(
                "label" => "Industry",'model' => array(
                    'Industry', 'id', 'title',
                    ['prepend' => ["" => "-Select Industry-"]]
                ),
            ),

            "employee_range_id" => array(
                "label" => "Company Size", 'required' => true, 'model' => array(
                    'Employee_range', 'id', 'title',
                    ['prepend' => ["" => "-Select Employee Count-"]]
                ),
            ),

            "originator_type_id" => array(
                "permitted_roles" => "admin",
                "label" => "Originator Type", 'model' => array(
                    'Originator_type', 'id', 'title',
                    ['prepend' => ["" => "-Select Originator Type-"]]
                ),
            ),

            "lead_source_id" => array(
                "label" => "Lead Source", 'required' => true, 'model' => array(
                    'Lead_source', 'id', 'title',
                    ['prepend' => ["" => "-Select Lead Source-"], 'conditions' => ['account_id=?', Acl_user::account_id()]]
                ),
            ),
            "customer_type_id" => array(
                "label" => "Buyer Type", 'required' => true,
                'model' => array(
                    'Customer_type', 'id', 'title',
                    [
                        'prepend' => ["" => "-Select Customer Type-"],
                        'conditions' => ['account_id=?', Acl_user::account_id()]
                    ]
                )
            ),
            "lead_interest_level_id" => array(
                "label" => "Interest Level (Optional)",
                'model' => array(
                    'Lead_interest_level', 'id',
                    ['title'], ["conditions" => ["account_id=?", Acl_user::account_id()]]
                )
            ),
            "project_id" => array("label" => "Project/Service Line", "required" => true, 'model' => array(
                'Project', 'id',
                ['title'], ['prepend' => ["" => "-Select Project-"], "conditions" => ["account_id=?", Acl_user::account_id()], "prepend" => ["0" => "--Project--"]]
            )),
            "unit_group_id" => array("label" => "Service Group",  'model' => array(
                'Activity', 'id', ['title'], ['prepend' => ["" => "-Select Activity-"], "conditions" => ["account_id=?", Acl_user::account_id()], "prepend" => ["0" => "--Activity--"]]
            )),
            "deal_amount" => array("label" => "Deal Amount", "required" => true),





            "qualification_status_type_id" => array(
                "permitted_roles" => "admin",
                "label" => "Qualify Status", 'required' => true, 'model' => array(
                    'Qualification_status_type', 'id', 'title', ['order' => 'id ASC']
                ),
            ),


            "sale_stage_id" => array(
                "label" => "Sale Stage",  'model' => array(
                    'Sale_stage', 'id', 'title', ['order' => 'id ASC']
                ),
            ),



            "country_id" => array(
                "label" => "Country", 'model' => array(
                    'Country', 'id', 'name',
                    ['prepend' => ["" => "-Select Country-"]]
                ),
            ),
            "zone_id" => array(
                "label" => "Zone",  'model' => array(
                    'Zone', 'id', 'title',
                    ['prepend' => ["" => "-Select Zone-"]]
                ),
            ),

            "address" => array("label" => "Billing Address"),
            "postal_code" => array("label" => "Postal Code"),

            "closure_month_id" => ["label" => "When to Buy?", "model" => ["Closure_month", "id", "title", ['order' => 'id ASC']]],

            "estimate_closure_date" => ["label" => "Estimate Closure Date?", "readonly" => true, "type" => "date", "required" => true],

            "description" => array("label" => "Additional Notes", "type" => "textarea"),

            "is_enquiry" => array("label" => "Is Enquiry", 'type' => 'hidden', 'value' => 1),
            'average_response_time' => array("label" => "Avg. Response Time (In Days)"),
            'aging' => array("label" => "Aging"),
            "supervisor_id" => array("label" => "Supervisor", 'required' => true, 'model' => array(
                'Supervisor', 'id',
                ['first_name', 'last_name'], ["prepend" => ["0" => "--Assigned Supervisor--"]]
            )),
            'calls_count' => array("label" => "Calls"),
            'sms_count' => array("label" => "Sms", "required" => true),
            'emails_count' => array("label" => "Emails"),
            'notes_count' => array("label" => "Notes"),
            'meetings_count' => array("label" => "Meetings"),
            'site_visits_count' => array("label" => "Site Visits"),
            'all_lead_activities_count' => array("label" => "Activities Count"),
            'last_lead_activity_date' => array("label" => "Last Followup Date"),
            'current_interest_level' => array("label" => "Current Interest Level"),
            'lead_activities' => array("label" => "Lead Activities"),
            "agent_id" => array(
                "label" => "Agent", "permitted_roles" => "admin", "prepend" => ["" => "-Select Agent-"], 'required' => true,
                'model' => array(
                    'Agent', 'id',
                    ['first_name', 'last_name'], ["prepend" => ["" => "-Select Agent-"], "conditions" => ["role_id=? AND account_id=? AND deleted=0", Role::alias_id('agent'), Acl_user::account_id()]]
                )
            ),


        );

        if (Session::user()->role->alias == "agent") {
            $fields['agent_id'] = ['label' => 'Agent', 'type' => 'hidden', 'value' => Session::user()->id];
        }

        return $fields;
    }

    public static function config_lead_journey($vars)
    {
        $config_data = static::config($vars);
        $config_data['grid_fields'] = static::fields([
            "enquiry_date", "name", "industry_id",  "estimate_closure_date", "project_id", "agent_id", "supervisor_id", 'average_response_time', 'aging', 'calls_count', 'sms_count', 'emails_count', 'notes_count', 'meetings_count', 'site_visits_count', 'all_lead_activities_count', 'last_lead_activity_date', 'current_interest_level', 'lead_activities'
        ]);
        $config_data['fields'] = static::fields([
            "enquiry_date", "name", "industry_id",  "estimate_closure_date", "project_id", "agent_id", "supervisor_id", 'average_response_time', 'aging', 'calls_count', 'sms_count', 'emails_count', 'notes_count', 'meetings_count', 'site_visits_count', 'all_lead_activities_count', 'last_lead_activity_date', 'current_interest_level', 'lead_activities'
        ]);
        return $config_data;
    }



    public static function action_search_by_phone()
    {
        $account_id=php_request_data('account_id');
        $phone=str_replace("254","",php_request_data('phone'));
        $enquiry=Enquiry::last(['conditions'=>['phone LIKE "%'.$phone.'%" AND account_id=?',$account_id]]);
        $enquiryData=$enquiry->to_array();
        if($enquiry->agent_id)
        {
            $agent=Agent::find($enquiry->agent_id);
            $enquiryData['agent']=$agent->to_array();
        }

        if($enquiry)
        {
            return ['data'=>$enquiryData,'info'=>'success'];
        }
        else
        {
            return ['data'=>[],'info'=>'success','message'=>'No Enquiry Found'];
        }
        
    }

    
}
