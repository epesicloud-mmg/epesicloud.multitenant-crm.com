<?php

/**
 *
 * @author <Martin Muriithi> <martin@pporting.org>
 */
class Lead_contact extends pPort_model
{

    static $table_name = "lead_contacts";
    static $primary_key = "id";
    static $connection = 'smart_real_estate';


    static $title = 'Lead Contacts';

    static $belongs_to = [
        "lead" => [
            "lead", "foreign_key" => "enquiry_id", "class_name" => "Lead"
        ],
        "document_folder" => [
            "document_folder", "foreign_key" => "document_folder_id", "class_name" => "Document_folder"
        ],
        "profession" => [
            "profession", "foreign_key" => "profession_id", "class_name" => "Profession"
        ]
    ];

    public static function fields_config()
    {
        return [
            "enquiry_id" => array("label" => "Lead", "model" => ["Enquiry", "id", "name"]),
            //"contact_type_id" => ["label" => "Contact Type", "required" => true, "model" => ["Contact_type", "id", "title"]],
            "relation" => array("label" => "Relation", "params" => [
                'spouse' => 'Spouse',
                'brother' => "Brother",
                "sister" => "Sister",
                'mother' => "Mother",
                "father" => "Father",
                'son' => "Son",
                "daughter" => "Daughter",
                "friend" => "Friend",
                "business_partner" => "Business Partner",
                "other" => "Other"
            ]),
            // "first_name" => ["label" => "First Name", "required" => true, "type" => "text"],
            // "last_name" => ["label" => "Last Name", "required" => true, "type" => "text"],

            "name" => ["label" => "Name", "required" => true, "type" => "text"],

            "email" => ["label" => "Email", "required" => true, "type" => "email"],
            "phone" => ["label" => "Phone", "required" => true, "type" => "phone"],

            "company" => ["label" => "Company",  "type" => "text"],

            "profession_id" => ["label" => "Profession",  "model" => ["Profession", "id", "title"]],
            "description" => array("label" => "Additional Notes", "type" => "textarea"),

        ];
    }


    public static function config($vars = [])
    {
        $config_data = array(
            "fields" => static::fields(["enquiry_id", "contact_type_id", "name", "email", "phone", "company", "profession_id", "description"]),
            "conditions" => array("account_id=?", Acl_user::account_id()),
            "form" => static::form_attrs(),
            "grid_actions" => static::grid_actions(['view']),
            "form_actions" => static::form_actions(['save'])

        );

        if (isset($_REQUEST['enquiry_id'])) {
            $config_data['fields']['enquiry_id'] = ['label' => "Select Lead", "type" => "hidden", "value" => $_REQUEST['enquiry_id']];
        }
        return $config_data;
    }
}