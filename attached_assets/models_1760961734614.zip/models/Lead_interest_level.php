<?php

/**
 * Handles User lead_activities
 *
 * User Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Lead_interest_level extends pPort_model
{

    static $table = 'lead_interest_levels';
    static $name = 'Lead Interest Levels';
    static $before_save = array('add_account');
    static $connection = 'smart_real_estate';

    static $has_many = [
        'enquiries' => ['enquiries', 'class_name' => 'Enquiry', 'foreign_key' => 'lead_interest_level_id']
    ];

    public function get_enquiries_count()
    {
        return Enquiry::count(['conditions' => ['lead_interest_level_id=?', $this->id]]);
    }

    public function get_deal_amounts()
    {
        return Enquiry::sum(['sum' => 'deal_amount', 'conditions' => ['lead_interest_level_id=?', $this->id]]);
    }


    public static function fields_config()
    {
        return array(
            "title" => array("label" => "Type Name"),
            "description" => array("label" => "Description", "type" => "textarea"),
            "enquiries_count" => array("label" => "Opportunities Count", "href" => function ($result) {
                return Url::report_panel("Enquiry", ['interest_level_id' => $result->id]);
            }, "type" => "text"),
            "deal_amounts" => array("label" => "Deal Amounts", "href" => function ($result) {
                return Url::report_panel("Enquiry", ['interest_level_id' => $result->id]);
            }, "format" => "currency", "type" => "text"),
        );
    }


    public static function config($vars = [])
    {
        return array(
            "fields" => static::fields(['title', 'description']),
            "grid_fields" => static::fields(['description'], false),
            "cols" => 1,
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),
            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions()
        );
    }
}