<?php
class Agent_journey extends Followup
{
    static $title="Agents Locations";
    static $name="Agents Locations";
}