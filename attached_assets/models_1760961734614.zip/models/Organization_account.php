<?php
class Organization_account extends Acl_account
{
    static $has_many = [
        'enquiries' => [
            'enquiries',
            'class_name' => 'Enquiry',
            'foreign_key' => 'agent_id'
        ],
        'sale_interests' => [
            'sale_interests',
            'class_name' => 'Sale_interest',
            'foreign_key' => 'agent_id',
            "title" => "Sale Interests"
        ],
        'sale_offers' => [
            'sale_offers',
            'class_name' => 'Sale_offer',
            'foreign_key' => 'agent_id',
            "title" => "Sale Offers"
        ],
        'sales' => [
            'sales',
            'class_name' => 'Sale',
            'foreign_key' => 'agent_id',
            "title" => "Sales"
        ],
        'followups' => [
            'sales',
            'class_name' => 'Followup',
            'foreign_key' => 'agent_id',
            "title" => "Sales"
        ],
        'mail_boxes' => [
            'mail_boxes',
            'class_name' => 'Mail_box',
            'foreign_key' => 'user_id',
            "title" => "Mail Boxes"
        ]
    ];
}