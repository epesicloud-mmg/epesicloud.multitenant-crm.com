<?php
class Permission  extends pPort_Model
{

    static $connection = "smart_real_estate";
    static $table = "permissions";

    public static function fields_config()
    {
        return
            [
                "title" => ["label" => "Title", "required" => true],
                "alias" => ["label" => "Alias", "required" => true],
                "description" => ["label" => "Description", "required" => true],
            ];
    }

    public static function config($vars = [])
    {
        return [
            "fields" => static::fields(),
            "order" => "alias DESC"
        ];
    }

    public static function ajaxfy_to_sync_defaults()
    {
        foreach (Cloud_module_role::all(['conditions' => ['cloud_module_id=13 AND account_id=1 AND deleted=0']]) as $cloud_module_role) {
            $permission_list = [];
            $role = (Role::find_by_account_id_and_alias(138, $cloud_module_role->alias));
            $cloud_module_role->permission_ids = $role->permission_ids;
            $cloud_module_role->save();
        }
    }
}