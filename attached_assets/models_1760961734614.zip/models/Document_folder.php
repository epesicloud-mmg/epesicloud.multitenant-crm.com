<?php
class Document_folder extends pPort_model
{
    static $connection = 'epesi_intranet';
    static $table = 'document_folders';


    static $title = "Document Folder";
    static $description = "Document Folder";


    public static function fields_config()
    {
        return array(
            "title" => array("label" => "Title", "required" => true),
            "description" => array("label" => "Description", "required" => true),
        );
    }

    public static function config($vars = [])
    {
        return array(
            "fields" => static::fields(),
            "order" => "id ASC",
            "form_actions" => static::form_actions(),
            "grid_actions" => static::grid_actions(),
        );
    }

    public function get_documents_count()
    {
        return Lead_document::count(['conditions' => ['document_folder_id=?', $this->id]]);
    }
}