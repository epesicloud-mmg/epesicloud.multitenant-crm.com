<?php
class Sale_stage extends pPort_model
{

    static $table = 'sale_stages';
    static $name = 'Sales stage';

    static $connection = 'smart_real_estate';
    static $belongs_to = [
        'sale_pipeline' => ['sale_pipeline', 'class_name' => 'Sale_pipeline', 'foreign_key' => 'sale_pipeline_id']
    ];
    static $has_many = [
        'enquiries' => ['enquiries', 'class_name' => 'Enquiry', 'foreign_key' => 'sale_stage_id']
    ];

    public function get_sale_pipeline_title()
    {
        return $this->sale_pipeline ? $this->sale_pipeline->title : NULL;
    }

    public function get_enquiries_count()
    {
        return Enquiry::count(['conditions' => ['sale_stage_id=?', $this->id]]);
    }

    public function get_deal_amounts()
    {
        return Enquiry::sum(['sum' => 'deal_amount', 'conditions' => ['sale_stage_id=?', $this->id]]);
    }

    public static function fetch_won_stage()
    {
        if (Sale_stage::exists(['conditions' => ['is_won_stage=?', 1]])) {
            return Sale_stage::last(['conditions' => ['is_won_stage=?', 1]]);
        } else {
            Sale_stage::last();
        }
    }

    public static function fetch_won_stage_id()
    {
        $conversion_stage = static::fetch_won_stage();
        return $conversion_stage ? $conversion_stage->id : NULL;
    }

    public static function fields_config()
    {
        return array(
            "sale_pipeline_id" => array("label" => "Sale Pipeline", "model" => ["Sale_pipeline", "id", "title"]),
            "title" => array("label" => "Stage Name"),
            "description" => array("label" => "Description", "type" => "textarea"),
            "enquiries_count" => array("label" => "Opportunities Count", "href" => function ($result) {
                return Url::report_panel("Enquiry", ['sale_stage_id' => $result->id]);
            }, "type" => "text"),
            "deal_amounts" => array("label" => "Deal Amounts",  "href" => function ($result) {
                return Url::report_panel("Enquiry", ['sale_stage_id' => $result->id]);
            }, "format" => "currency", "type" => "text"),
            "is_won_stage" => array("label" => "Is Conversion Stage", "params" => [0 => "No", 1 => "Yes"]),
        );
    }

    public static function config($vars = [])
    {
        return array(
            "fields" => static::fields(["sale_pipeline_id", "title", "description", "is_conversion_stage"]),
            "grid_fields" => static::fields(["sale_pipeline_id", "title", "description", "enquiries_count", "deal_amounts"]),
            "cols" => 1,
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),

            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions(),
            "form" => static::form_attrs(),
        );
    }


    public static function fetch_leads()
    {
        $limitVal = mt_rand(1, 5);
        return Lead::find_by_sql("select * from " . Lead::t() . " WHERE deleted=0  ORDER BY RAND() limit 0," . $limitVal);
    }
}
