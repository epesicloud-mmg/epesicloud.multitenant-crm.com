<?php

class Salesify_campaign extends Title_description
{
    static $connection='smart_real_estate';
    static $table='salesify_campaigns';
    static $title="Campaign";
    static $description="(setup campaigns)";
}