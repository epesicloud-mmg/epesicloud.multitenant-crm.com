<?php
class Batch_enquiry_agent extends pPort_model
{
    static $table = 'batch_enquiry_agents';
    static $before_create = ["add_title", "validate_from_and_to"];
    static $after_create = ["reassign_leads", "send_sms"];
    static $connection = 'smart_real_estate';

    function add_title()
    {


        $from_agent = Agent::find($this->from_agent_id);
        $to_agent = Agent::find($this->to_agent_id);
        $this->title = $from_agent->first_name . " " . $from_agent->last_name . " to " . $to_agent->first_name . " " . $to_agent->last_name;
    }

    function validate_from_and_to()
    {
        if ($this->to_agent_id == $this->from_agent_id) {
            json_render(['info' => 'error', "message" => "Cannot re-assign leads to the same agent"]);
        }
        $to_agent = Agent::find($this->to_agent_id);
        $from_agent = Agent::find($this->from_agent_id);
        if ($to_agent->account_id != Acl_user::account_id() || $from_agent->account_id != Acl_user::account_id()) {
            if ($this->to_agent_id == $this->from_agent_id) {
                json_render(['info' => 'error', "message" => "An invalid function error occurred."]);
            }
        }
    }

    function send_sms()
    {
        $message = "New Leads have been assigned to you.";
        $agent = Agent::find($this->to_agent_id);
        $phone = $agent->phone;
        $send = Sms::send($message, $phone);
    }

    function reassign_leads()
    {



        $enquiries = Enquiry::all([
            "limit" => $this->number_of_leads,
            "conditions" => ["agent_id=? AND account_id=? AND enquiry_date BETWEEN '" . date("Y-m-d", strtotime($this->start_date)) . "' AND '" . date("Y-m-d", strtotime($this->end_date)) . "'", $this->from_agent_id, Acl_user::account_id()]
        ]);



        $reassigned_leads_count = 0;
        foreach ($enquiries as $enquiry) {
            $assignment_created = Enquiry_account_executive::create(
                [
                    "enquiry_id" => $enquiry->id,
                    "agent_id" => $this->to_agent_id,
                    "date_assigned" => date("Y-m-d"),
                    "is_active" => 1,
                    "description" => "Batch Re-assignment",
                    "is_reassignment" => 1,
                    "reassignment_from_id" => $this->from_agent_id,
                    "account_id" => $this->account_id,
                    "batch_enquiry_agent_id" => $this->id,
                ]
            );



            if ($assignment_created) {
                $reassigned_leads_count += 1;
            }
        }
        $this->actual_reassigned_leads = $reassigned_leads_count;
        $this->save();
    }

    public static function config($vars = [])
    {
        $reassignment_from_id = arr('from_id', $vars, NULL);
        $is_reassignment = $reassignment_from_id ? 1 : 0;


        $config_data = array(
            "fields" => array(
                "from_agent_id" => array(
                    "label" => "From Account Executive", "required" => true,
                    "model" => ["Agent", 'id', ['first_name', 'last_name', 'phone'], [
                        'prepend' => ["" => "-Select Account Exec-"],
                        'conditions' => ["role_id=? AND account_id=?", Role::alias_id('agent'), Acl_user::account_id()]
                    ]]
                ),
                "to_agent_id" => array("label" => "To Account Executive", "required" => true, "model" => ["Agent", 'id', ['first_name', 'last_name', 'phone'], ['prepend' => ["" => "-Select Account Exec-"], 'conditions' => ["role_id=? AND account_id=?", Role::alias_id('agent'), Acl_user::account_id()]]]),
                // "actual_reassigned_leads"=>array("label"=>"Actual Re-assigned Leads"),
                "number_of_leads" => array("label" => "Number of Leads", "required" => true, "min" => 1),
                "start_date" => array("label" => "Start Date", "required" => true, "value" => the_past("1", "year"), "type" => "date"),
                "end_date" => array("label" => "End Date", "required" => true, "value" => date("Y-m-d"), "type" => "date"),
                //"is_roll_back"=>array("label"=>"Rollback","params"=>["0"=>"No","1"=>"Yes"]),
                "description" => array("label" => "Reason for Re-Assignment", "required" => true, "min" => 1),
            ),

        );

        if (Session::user()->role->alias == "supervisor") {
            $config_data['from_agent_id'] = array(
                "label" => "From Account Executive", "required" => true,
                "model" => ["Agent", 'id', ['first_name', 'last_name', 'phone'], [
                    'prepend' => ["" => "-Select Account Exec-"],
                    'conditions' => ["role_id=? AND account_id=?  AND supervisor_id=?", Role::alias_id('agent'), Acl_user::account_id(), Session::user("id")]
                ]]
            );

            $config_data['to_agent_id'] = array(
                "label" => "To Account Executive",
                "required" => true, "model" => [
                    "Agent", 'id', ['first_name', 'last_name', 'phone'],
                    [
                        'prepend' => ["" => "-Select Account Exec-"],
                        'conditions' => ["role_id=? AND account_id=? AND supervisor_id=?", Role::alias_id('agent'), Acl_user::account_id(), Session::user("id")]
                    ]
                ]
            );
        }
        return $config_data;
    }
}