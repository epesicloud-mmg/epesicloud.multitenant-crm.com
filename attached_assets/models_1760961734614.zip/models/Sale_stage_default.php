<?php
class Sale_stage_default extends pPort_model
{
    static $table = 'sale_stage_defaults';
    static $name = 'Sales stage Defaults';
    static $connection = 'smart_real_estate';

    public static function fields_config()
    {
        return array(
            "alias" => array("label" => "Alias"),
            "title" => array("label" => "Stage Name"),
            "description" => array("label" => "Description", "type" => "textarea"),
            "is_won_stage" => array("label" => "Is Conversion Stage", "params" => [0 => "No", 1 => "Yes"]),
        );
    }

    public static function config($vars = [])
    {
        return array(
            "fields" => static::fields(["sale_pipeline_id", "title", "description", "is_conversion_stage"]),
            "grid_fields" => static::fields(["sale_pipeline_id", "title", "description", "enquiries_count", "deal_amounts"]),
            "cols" => 1,
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),

            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions(),
            "form" => static::form_attrs(),
        );
    }
}