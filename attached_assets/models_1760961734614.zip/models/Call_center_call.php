<?php
class Call_center_call extends pPort_model
{
    static $connection = "epesi_call_center";
    static $table = 'calls';
    static $title = "Calls";
}