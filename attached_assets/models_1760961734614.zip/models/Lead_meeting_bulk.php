<?php
/**
 *
 * @author <Martin Muriithi> <martin@pporting.org>
 */
class Lead_meeting_bulk extends pPort_model
{

    static $table_name="lead_meeting_bulks";
    static $primary_key="id";
    static $connection='smart_real_estate';
    static $before_create=["add_token","parse_visit_date","add_enquiry_id","add_agent_id"];
    static $csv_upload_token=NULL;
    static $after_create=[
        'create_visit'
    ];

    public  function add_token()
    {
        $this->csv_upload_token=static::$csv_upload_token;
    }
   
    public function parse_visit_date()
    {
        $parsed_date=$this->visit_date;
                $explode_date=explode("/",$this->visit_date);
                if(isset($explode_date[2]))
                {
                    $parsed_date=$explode_date[2].'-'.$explode_date[1].'-'.$explode_date[0];
                                
                }
                $this->visit_date=$parsed_date;
    }


    public function add_agent_id()
    {
        $agent=Agent::find_by_email_and_account_id($this->agent_email,Acl_user::account_id());
        if(!$this->agent_id)
        {
            $this->agent_id=$agent->id;
            $this->supervisor_id=$agent->supervisor_id;
        }
    }

    public function add_enquiry_id()
    {
        if($this->client_email && $this->client_email!="")
        {
            $lead=Lead::find_by_email_and_account_id($this->client_email,Acl_user::account_id());
            if($lead)
            {
                $this->enquiry_id=$lead->id;
                $this->agent_id=$lead->agent_id;
            }
        }
        

        if(!$this->enquiry_id)
        {
            if($this->client_phone && $this->client_phone!="")
            {
                $lead=Lead::find_by_phone_and_account_id($this->client_phone,Acl_user::account_id());
                if($lead)
                {
                    $this->enquiry_id=$lead->id;
                    $this->agent_id=$lead->agent_id;
                }
            }
        }

    }


    public function create_visit()
    {
        if($this->agent_id && $this->enquiry_id)
        {
            $meeting_data=[];            

            $meeting_data=[
                'account_id'=>$this->account_id,
                'agent_id'=>$this->agent_id,
                'enquiry_id'=>$this->enquiry_id,
                'meeting_date'=>$this->visit_date,
                'meeting_type_id'=>Meeting_type::alias_id("site_visit"),
                "action"=>"checkout",
                'description'=>$this->description
            ];
            $meeting_data['is_bulk_upload']=1;
            $meeting_data['bulk_entity_id']=$this->id;
            $meeting_data['csv_upload_token']=$this->csv_upload_token;
            var_dump($meeting_data);
            /**$meeting=Lead_meeting::create($meeting_data);
            if($meeting)
            {
                $this->is_synchronize_successful=1;
            }
            $this->agent_id=$agent_id;
            $this->is_synchronize_attempted=1;
            $this->enquiry_id=$enquiry_existing->id;
            $this->save();                
            return true;**/
        }
        
    }

    public static function config($vars=[])
    {
        $config_data=array(
            "limit"=>200,
            "conditions"=>["account_id=? AND deleted=0",Acl_user::account_id()],
            "fields"=>array(
                "visit_date"=>array("required"=>true,"label"=>"visit Date"),
                "client_name"=>array("required"=>true,"label"=>"Client Name"), 
                "client_email"=>array("required"=>true,"label"=>"Client Email"),    
                "client_phone"=>array("required"=>true,"label"=>"Client Phone"),   
                "agent_email"=>array("required"=>true,"label"=>"Agent Email"),    
            ),
            "grid_actions"=>[]
        );
        return $config_data;
    }

}