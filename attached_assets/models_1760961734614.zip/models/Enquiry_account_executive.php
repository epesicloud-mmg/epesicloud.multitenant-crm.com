<?php
class Enquiry_account_executive extends pPort_model
{
    static $table = 'enquiries_account_executives';
    static $title = "Account Executive";
    static $description = "(Assign Account Executive)";
    static $connection = 'smart_real_estate';
    static $before_save = ["add_account_creator", "add_is_direct_assignment", "deactivate_previous_assignment", "update_enquiry_account_executive", "send_sms"];
    //static $after_create=["update_enquiry_account_executive"];

    static $belongs_to = [
        //'customer'=>["customer","foreign_key"=>"customer_id","class_name"=>"Acc_client"],
        'enquiry' => ["enquiry", "foreign_key" => "enquiry_id", "class_name" => "Enquiry"],
        'account_executive' => ["account_executive", "foreign_key" => "agent_id", "class_name" => "Agent"],
        'agent' => ["agent", "foreign_key" => "agent_id", "class_name" => "Agent"]
    ];

    public static function ajaxfy_update_reassignments()
    {
    }

    public function add_is_direct_assignment()
    {
        $this->is_direct_assignment = $this->is_reassignment ? 0 : 1;
    }

    public function update_enquiry_account_executive()
    {
        $enquiry = Enquiry::find($this->enquiry_id);
        $enquiry->agent_id = $this->agent_id;
        $enquiry->is_direct_assignment = $this->is_direct_assignment;
        $enquiry->status = "assigned_agent";
        $enquiry->date_agent_assigned = $this->date_assigned;
        $enquiry->is_reassignment = $this->is_reassignment;
        $enquiry->reassignment_from_id = $this->reassignment_from_id;
        $enquiry->batch_enquiry_agent_id = $this->batch_enquiry_agent_id;
        $enquiry->save();
    }


    public function deactivate_previous_assignment()
    {

        $last_assignment = Enquiry_account_executive::last(['conditions' => ['enquiry_id=?', $this->enquiry_id]]);
        if ($last_assignment  && $last_assignment->agent_id != $this->agent_id) {
            $last_assignment->is_active = 0;
        }
    }

    public function send_sms()
    {
        if (isset($_REQUEST['bulk_action']) && $_REQUEST['bulk_action'] == "qualify_lead") {
            return;
        }

        $account_executive = Account_executive::find($this->agent_id);
        $enquiry = Enquiry::find($this->enquiry_id);
        $last_assignment = Enquiry_account_executive::last(['conditions' => ['enquiry_id=?', $this->enquiry_id]]);
        if ($last_assignment && $last_assignment->agent_id == $this->agent_id) {
            //Don't resend SMS
            //exit(json_encode(['info'=>'error','message'=>'The enquiry for '.$enquiry->name.' is already assigned to '.$account_executive->first_name." ".$account_executive->last_name]));
        } else {
            //Don't send SMS when the lead was bulk re-assigned. 
            //Bulk Re-assign sends its own SMS
            if ($this->batch_enquiry_agent_id) {
                return;
            }
            $this->is_active = 1;
            //Send SMS  
            if ($enquiry->qualify_status == "qualified") {
                $lead_source_obj = Lead_source::find($enquiry->lead_source_id);
                $lead_source = isset($lead_source_obj->title) ? $lead_source_obj->title : "";
                $message = "New Lead : Company (" . $enquiry->company_name . "),Name (" . $enquiry->name . "), Phone (" . $enquiry->phone . "), Email (" . $enquiry->email . "), Lead Source (" . $lead_source . ")";
                $phone = ($enquiry->is_test) ? "254729934932" : $account_executive->phone;
                $send = Sms::send($message, $phone);
            }
        }
    }

    public static function config_reassigned($vars = [])
    {
        $config_data = static::config($vars);
        $config_data['conditions'] = array("account_id=? AND deleted=? AND is_active=1 AND is_reassignment=1", Acl_user::account_id(), 0);
        return $config_data;
    }

    public static function config_reassigned_pending($vars = [])
    {
        $config_data = static::config($vars);
        $config_data['find_by_sql'] = "SELECT * FROM " . static::t() . " WHERE " . static::t("enquiry_id") . " NOT IN";
        return $config_data;
    }

    public static function config($vars = [])
    {
        $reassignment_from_id = arr('from_id', $vars, NULL);
        $is_reassignment = $reassignment_from_id ? 1 : 0;

        return array(
            "fields" => array(
                "enquiry_id" => array("label" => "Lead", "required" => true, "model" => ["Enquiry", 'id', ['name', 'company_name'], ['prepend' => ["" => "-Select Lead-"], 'conditions' => ['account_id=?', Acl_user::account_id()]]]),
                "agent_id" => array("label" => "Account Executive", "required" => true, "model" => ["Acl_user", 'id', ['first_name', 'last_name', 'phone'], ['prepend' => ["" => "-Select Account Exec-"], 'conditions' => ["role_id=? AND account_id=?", Role::alias_id('agent'), Acl_user::account_id()]]]),
                "date_assigned" => array("label" => "Date Assigned", "format" => "date", "required" => true, 'type' => 'date', 'value' => date('Y-m-d')),
                "is_active" => ["label" => "Is Active", "required" => true, "params" => ["1" => "Yes", "0" => "No"]],
                "description" => array("label" => "Additional Notes", "type" => "textarea"),
                "is_reassignment" => ["label" => "Is Re-Assignment", "type" => "hidden", "value" => $is_reassignment],
                "reassignment_from_id" => ["label" => "Re-Assignment From", "type" => "hidden", "value" => $reassignment_from_id],
            ),
            "limit" => 300,
            "order" => "id DESC",
            "grid_fields" => ["enquiry_id", "agent_id", "date_assigned"],
            "conditions" => array("account_id=? AND deleted=? AND is_active=1", Acl_user::account_id(), 0),
            "grid_actions" => static::grid_actions(),
            'form_actions' => static::form_actions(),
            "form" => static::form_attrs(),

        );
    }


    public static function ajaxfy_reassign()
    {
        $date_not_today = "date_format(enquiry_date,'%Y-%m-%d')<>curdate()";
        $sql = "SELECT enquiries.*
            FROM enquiries LEFT JOIN followups ON followups.enquiry_id=enquiries.id
            WHERE followups.enquiry_id IS NULL AND " . $date_not_today . " AND enquiry_date>'" . the_past(1, 'month') . "' AND enquiries.account_id=" . Acl_user::account_id();

        $all_pending = static::find_by_sql($sql);

        foreach ($all_pending as $pending_enquiry) {
            //Check last reassignment date
            $last_assignment = Enquiry_account_executive::last(['conditions' => ['enquiry_id=?', $enquiry->id]]);
            $reassign = true;
            if (the_diff($last_assignment->created_at, date("Y-m-d")) < 3 && $last_assignment->is_reassignment) {
                $reassign = false;
            }
            if ($reassign) {
                $current_account_exec_id = $pending->agent_id;
                $all_execs = Account_Executive::all(['conditions' => ['account_id=? AND id<>' . $pending_enquiry->agent_id, Acl_user::account_id()]]);
                $random_exec = array_rand($all_execs);
                Enquiry_account_executive::create([
                    'account_id' => $pending_enquiry->account_id,
                    'agent_id' => $random_exec->id,
                    'date_assigned' => date("Y-m-d"),
                    "is_active" => 1,
                    "description" => "System Auto Re-Assign",
                    "is_reassignment" => 1,
                    "reassignment_from_id" => $current_account_exec_id




                ]);
            }
        }
    }
}
