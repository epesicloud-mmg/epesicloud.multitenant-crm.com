<?php
class Trip_booking  extends Trip_lead
{
    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "trip_id"=>array("label"=>"Trip *","readonly"=>true,"model"=>["Trip","id",["title","trip_date"],["order"=>"id DESC","conditions"=>["account_id=?",Acl_user::account_id()]]]),
                "lead_id"=>array("label"=>"Lead *","required"=>true,"model"=>["Lead","id",["name"],["prepend"=>[""=>"-Select Lead-"],"conditions"=>["account_id=?",Acl_user::account_id()]]]),
                "booking_status"=>array("label"=>"Booking Status *","params"=>["booked"=>"Booked","cancelled"=>"Cancelled"]),
            )
        );
    }
}