<?php

class Sale_stage_update extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'sale_stage_updates';
    static $title = "Sale Stage Updates";
    static $description = "(Sale Stage Updates)";

    static $after_create = ["change_lead_sale_stage"];

    static $before_create = ["update_title"];


    function update_title()
    {
        $enquiry = Enquiry::find($this->enquiry_id);
        $source_sale_stage_id = $this->source_sale_stage_id ? $this->source_sale_stage_id : $enquiry->sale_stage_id;
        $source_sale_stage = Sale_stage::find($source_sale_stage_id);
        $target_sale_stage = Sale_stage::find($this->target_sale_stage_id);
        $source_stage_title = $source_sale_stage ? $source_sale_stage->title : "Discovery";
        $this->title = @$source_sale_stage->title . " to " . $target_sale_stage->title;
    }

    function change_lead_sale_stage()
    {
        $enquiry = Enquiry::find($this->enquiry_id);
        $enquiry->sale_stage_id = $this->target_sale_stage_id;
        $enquiry->save();
    }


    public static function fields_config()
    {
        return array(
            "enquiry_id" => array("label" => "Select Lead", "model" => ["Enquiry", "id", "name"]),
            "source_sale_stage_id" => array("label" => "Source Sale Stage", "readonly" => true, "model" => ["Sale_stage", "id", "title"]),
            "target_sale_stage_id" => array("label" => "Target Sale Stage", "model" => ["Sale_stage", "id", "title"]),
            "description" => array("label" => "Additional Note"),
            "created_at" => array("label" => "Activity Time"),

        );
    }


    public static function config($vars = [])
    {
        $config_data = array(
            "fields" => static::fields(["enquiry_id", "target_sale_stage_id", "description"]),
            "grid_fields" => static::fields(),
        );
        return $config_data;
    }
}