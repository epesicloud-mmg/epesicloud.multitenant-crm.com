<?php

/**
 * 
 * @author Martin Muriithi <martin@pporting.org>
 *
 **/
class Trip_cancellation extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'trip_cancellations';
    static $title = "Trip Cancellation";
    static $belongs_to = [
        "trip" => ["trip", "foreign_key" => "trip_id", "class_name" => "Trip"],
    ];

    static $before_create = ["update_trip_status_type"];
    static $after_create = ["sms_agents"];


    public function update_trip_status_type()
    {
        $trip = Trip::find($this->trip_id);
        $trip->trip_status_type_id = Trip_status_type::alias_id("cancelled");
        $trip->deleted = 1;
        $trip->save();
        $this->project_id = $trip->project_id;
    }


    public function sms_agents()
    {
        //Sms all agents about the new trip
        $project = Project::find($this->project_id);
        $message = "TRIP CANCELLED, the trip  (Project : " . $project->title . ", Trip Date : " . date("Y-m-d", strtotime($this->trip_date)) . ", Trip Time : " . $this->start_time . "-" . $this->end_time . "), has been cancelled.";
        foreach (Agent::all(["conditions" => ["account_id=? AND deleted=0 AND role_id=" . Role::alias_id("agent"), Acl_user::account_id()]]) as $agent) {

            $agent_phone = $agent->phone;

            Sms::send($message, $agent_phone);
        }
    }

    public static function fields_config()
    {
        return array(
            "trip_id" => array("label" => "Trip *", "readonly" => true, "model" => ["Trip", "id", ["title", "trip_date"], ["conditions" => ["account_id=?", Acl_user::account_id()]]]),
            "project_id" => array("label" => "Project *", "readonly" => true, "model" => ["Project", "id", ["title"], ["conditions" => ["account_id=?", Acl_user::account_id()]]]),
            "description" => ["label" => "Cancellation Reason", "required" => true, "type" => "textarea"],
            "created_at" => ["label" => "Cancellation Date", "required" => true, "type" => "date"]
        );
    }

    public static function config($vars = [])
    {
        return array(
            "fields" => static::fields(['trip_id', 'cancellation_reason']),
            "grid_fields" => static::fields(),
            "grid_actions" => [],
            "form_actions" => static::form_actions(['save']),
            "form" => static::form_attrs()
        );
    }
}
