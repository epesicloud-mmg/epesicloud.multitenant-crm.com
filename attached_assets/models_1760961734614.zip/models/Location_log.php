<?php
/**
 *
 * @author <Martin Muriithi> <martin@pporting.org>
 */
class Location_log extends pPort_model
{

    static $table_name="location_logs";
    static $primary_key="id";
    static $connection='smart_real_estate';
    static $belongs_to=[
        'agent_id'=>[
            'agent',
            'class_name'=>"Agent",
            'foreign_key'=>'agent_id'
        ]
    ];

    //Check the previous location
    function check_previous_location()
    {
        $last_agent=static::last(['conditions'=>['agent_id=?',$this->agent_id]]);
        if($last_agent)
        {
            $sim = similar_text($this->longitude, $last_agent->longitude, $percent);
            if($percent>50)
            {
                exit(json_encode(['info'=>'success','message'=>'Success']));
            }
        }
    }
   

}