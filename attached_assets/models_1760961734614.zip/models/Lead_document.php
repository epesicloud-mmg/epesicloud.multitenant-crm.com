<?php
class Lead_document extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'lead_documents';

    static $title = "Lead Documents";

    static $description = "Lead Document Records";

    static $after_create = ["add_to_feed"];

    static $belongs_to = [
        "lead" => [
            "lead", "foreign_key" => "enquiry_id", "class_name" => "Lead"
        ],
        "enquiry" => [
            "enquiry", "foreign_key" => "enquiry_id", "class_name" => "Enquiry"
        ],
        "document_folder" => [
            "document_folder", "foreign_key" => "document_folder_id", "class_name" => "Document_folder"
        ]
    ];



    public function add_to_feed()
    {
        Lead_activity::create([
            "enquiry_id" => $this->enquiry_id,
            'account_id' => $this->account_id,
            "linked_entity" => "Lead_document",
            "linked_entity_reference" => $this->id,
            //"title" => $this->title,
            //"description" => "",
            'followup_time' => date("Y-m-d H:i:s"),
            'followup_date' => date("Y-m-d"),
            //"link" => Url::form_panel("Lead_document?feed=1"),
            //"meta_data" => json_encode($this->to_array()),
            //'location_meta_data' => $this->location_meta_data
        ]);
    }

    public static function fields_config()
    {

        return array(
            "document_folder_id" => array("label" => "Document Folder ", "model" => ["Document_folder", "id", ["title"]]),
            "enquiry_id" => array("label" => "Lead ", "model" => ["Enquiry", "id", ["name"]]),
            "attachment" => array("label" => "Attachment", "type" => "file", "required" => true),
            "title" => array("label" => "Document Label", "required" => true),


        );
    }

    public static function config($vars = [])
    {
        if (php_request_data("enquiry_id")) {
            $fields = static::fields(['document_folder_id', "enquiry_id",  'title', 'attachment']);
        } else {
            $fields = static::fields(['document_folder_id', "enquiry_id", 'title', 'attachment']);
        }


        return array(
            "colspan" => "6",
            "fields" => $fields,
            "order" => "id DESC",
            "form_actions" => static::form_actions(['save']),
            "grid_actions" => static::grid_actions([]),
        );
    }
}