<?php

/**
 * 
 * @author Martin Muriithi <martin@pporting.org>
 *
 **/
class Trip extends Title_description
{
    static $connection = 'smart_real_estate';
    static $table = 'trips';
    static $title = "Trip";
    static $description = "(Manage Trips)";

    static $has_many = [
        "trip_bookings" => [
            "trip_bookings", "foreign_key" => "trip_id", "class_name" => "Trip_booking",
        ],
        "trip_leads" => [
            "trip_leads", "foreign_key" => "trip_id", "class_name" => "Trip_lead",
        ],
        "trip_confirmations" => [
            "trip_confirmations", "foreign_key" => "trip_id", "class_name" => "Trip_confirmation"
        ],
        "trip_attendances" => [
            "trip_attendances", "foreign_key" => "trip_id", "class_name" => "Trip_attendance"
        ]
    ];

    static $after_create = [
        "sms_agents"
    ];



    public function sms_agents()
    {
        //Sms all agents about the new trip
        $project = Project::find($this->project_id);
        $message = "Hello, a new trip has been added (Project : " . $project->title . ", Trip Date : " . date("Y-m-d", strtotime($this->trip_date)) . ", Trip Time : " . $this->start_time . "-" . $this->end_time . "), kindly login to the App and start registering your clients.";
        foreach (Agent::all(["conditions" => ["account_id=? AND deleted=0 AND role_id=" . Role::alias_id("agent"), Acl_user::account_id()]]) as $agent) {

            $agent_phone = $agent->phone;

            Sms::send($message, $agent_phone);
        }
    }

    public static function fields()
    {
        return array(
            "project_id" => array("label" => "Project ID *", "model" => ["Project", "id", "title", ["conditions" => ["account_id=?", Acl_user::account_id()]]]),
            "title" => array("label" => "Title *"),
            "trip_date" => array("label" => "Trip Date *", "required" => true, "type" => "date"),
            "start_time" => array("required" => true, "label" => "Trip Start Time", "params" => hours_range()),
            "end_time" => array("required" => true, "label" => "Trip End Time", "params" => hours_range()),
            "description" => array("label" => " Description", "type" => "textarea"),
        );
    }


    public static function grid_actions_config()
    {
        return [
            'edit' => [
                'label' => 'Edit',
                'href' => Url::batch_panel("Trip/trip_leads/{@id}")
            ],
            'view_report' => [
                'label' => 'Printable Report',
                'href' => function ($result) {
                    return Url::grid_panel("Trip_lead", ['trip_id' => $result->id]);
                }
            ],
            'cancel_trip' => [
                'label' => 'Cancel Trip',
                'href' => Url::form_panel("Trip_cancellation?trip_id={@id}")
            ],
        ];
    }

    public static function fields_config()
    {
        return array(
            "project_id" => array("label" => "Project ID *", "model" => ["Project", "id", "title", ["conditions" => ["account_id=?", Acl_user::account_id()]]]),
            "trip_status_type_id" => array("label" => "Trip Status *", "model" => ["Trip_status_type", "id", "title"]),
            "title" => array("label" => "Title *"),
            "trip_date" => array("label" => "Trip Date *", "type" => "date"),
            "start_time" => array("required" => true, "label" => "Trip Start Time", "params" => hours_range()),
            "end_time" => array("required" => true, "label" => "Trip End Time", "params" => hours_range()),
            "description" => array("label" => " Description", "type" => "textarea"),

        );
    }

    public static function config($vars = [])
    {

        $config_data = array(
            "fields" => static::fields(),
            "grid_fields" => ["project_id", "title", "trip_date", "all_registered", "sure", "not_sure", "not_going", "unreachable", "did_not_pickup"],
            "conditions" => array("account_id=?", Acl_user::account_id()),
            "form" => static::form_attrs(),
            "grid_actions" => static::grid_actions(['edit', 'view_report']),
            "form_actions" => static::form_actions(['save']),
        );


        if (isset($vars['screen']) && $vars['screen'] == "grid") {
            $config_data["fields"]["all_registered"] = array("label" => "All Registered", "disabled" => true, "value" => function ($result) {
                return Trip_lead::count(['conditions' => ['trip_id=?', $result->id]]);
            });
            foreach (["sure", "not_sure", "not_going", "unreachable", "did_not_pickup"] as $confirmation_status) {
                $config_data["fields"][$confirmation_status] = array(
                    "label" => ucwords(str_replace("_", " ", $confirmation_status)),
                    "disabled" => true,
                    "value" => function ($result) use ($confirmation_status) {
                        return Trip_lead::count(['conditions' => ['confirmation_status=? AND trip_id=?', $confirmation_status, $result->id]]);
                    }
                );
            }
        }
        return $config_data;
    }

    public static function config_attendance($vars = [])
    {
        $config_data = static::config($vars);
        $config_data['grid_actions'] = [
            "mark_attendance" => ["label" => "Mark Attendance", "href" => Url::batch_panel("Trip/trip_attendances/{@id}/batch_add/0")],
        ];
        return $config_data;
    }

    public static function config_confirmation($vars = [])
    {
        $config_data = static::config($vars);

        $config_data['grid_actions'] = [
            "make_confirmation" => ["label" => "Mark Confirmation", "href" => Url::batch_panel("Trip/trip_confirmations/{@id}/batch_add/0")],
        ];
        return $config_data;
    }
}
