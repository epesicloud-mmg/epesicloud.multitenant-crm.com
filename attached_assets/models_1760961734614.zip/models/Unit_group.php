<?php
class Unit_group extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'unit_groups';
    static $name = "Unit Group";

    static $belongs_to = array(
        'project' => array("project", "class_name" => "Project", "foreign_key" => "project_id"),
    );

    static $has_many = array(
        'unit_group_items' => array("unit_group_items", "class_name" => "Unit_group_item", "foreign_key" => "unit_group_id"),
    );


    public static function label_list()
    {
        return ['A1' => '59', 'A2' => '56', 'A3' => '52', 'T2' => '51', 'T3' => '50'];
    }

    public static function fields_config()
    {
        return array(
            "photo_1" => array(
                "label" => "Photo 1",
                "title" => " ",
                "type" => "ajax_file",
                "style" => "height:150px;width:150px",
                "target" => APP_PATH . 'storage/uploads',
                'base_relative' => 'app/storage/uploads',
                "max_size" => 500000,
                "entity" => "Unit_group",
                "parent" => "Unit_group",
                "formats" => "jpeg,png,jpg",
            ),
            "photo_2" => array(
                "label" => "Photo 2",
                "title" => " ",
                "type" => "ajax_file",
                "style" => "height:150px;width:150px",
                "target" => APP_PATH . 'storage/uploads',
                'base_relative' => 'app/storage/uploads',
                "max_size" => 500000,
                "entity" => "Unit_group",
                "parent" => "Unit_group",
                "formats" => "jpeg,png,jpg",
            ),
            "photo_3" => array(
                "label" => "Photo 3",
                "title" => " ",
                "type" => "ajax_file",
                "style" => "height:150px;width:150px",
                "target" => APP_PATH . 'storage/uploads',
                'base_relative' => 'app/storage/uploads',
                "max_size" => 500000,
                "entity" => "Unit_group",
                "parent" => "Unit_group",
                "formats" => "jpeg,png,jpg",
            ),
            "photo_4" => array(
                "label" => "Photo 4",
                "title" => " ",
                "type" => "ajax_file",
                "style" => "height:150px;width:150px",
                "target" => APP_PATH . 'storage/uploads',
                'base_relative' => 'app/storage/uploads',
                "max_size" => 500000,
                "entity" => "Unit_group",
                "parent" => "Unit_group",
                "formats" => "jpeg,png,jpg",
            ),
            "photo_5" => array(
                "label" => "Photo 5",
                "title" => " ",
                "type" => "ajax_file",
                "style" => "height:150px;width:150px",
                "target" => APP_PATH . 'storage/uploads',
                'base_relative' => 'app/storage/uploads',
                "max_size" => 500000,
                "entity" => "Unit_group",
                "parent" => "Unit_group",
                "formats" => "jpeg,png,jpg",
            ),
            "photo_6" => array(
                "label" => "Photo 6",
                "title" => " ",
                "type" => "ajax_file",
                "style" => "height:150px;width:150px",
                "target" => APP_PATH . 'storage/uploads',
                'base_relative' => 'app/storage/uploads',
                "max_size" => 500000,
                "entity" => "Unit_group",
                "parent" => "Unit_group",
                "formats" => "jpeg,png,jpg",
            ),
            "photo_7" => array(
                "label" => "Photo 7",
                "title" => " ",
                "type" => "ajax_file",
                "style" => "height:150px;width:150px",
                "target" => APP_PATH . 'storage/uploads',
                'base_relative' => 'app/storage/uploads',
                "max_size" => 500000,
                "entity" => "Unit_group",
                "parent" => "Unit_group",
                "formats" => "jpeg,png,jpg",
            ),
            "photo_8" => array(
                "label" => "Photo 8",
                "title" => " ",
                "type" => "ajax_file",
                "style" => "height:150px;width:150px",
                "target" => APP_PATH . 'storage/uploads',
                'base_relative' => 'app/storage/uploads',
                "max_size" => 500000,
                "entity" => "Unit_group",
                "parent" => "Unit_group",
                "formats" => "jpeg,png,jpg",
            ),
            "project_id" => array(
                "label" => "Project*", "required" => true,
                "model" => array("Project", "id", array("title"), ['conditions' => ['account_id=?', Acl_user::account_id()]])
            ),
            "title" => array("label" => "Item/Grouping Name", "required" => true),
            "description" => array("label" => "Description", "type" => "textarea"),
            "purpose" => array(
                "label" => "Purpose ",
                "params" => [
                    "" => "--Purpose --",
                    "sale" => "For Sale",
                    "rent" => "For Rent"
                ]
            ),


            "unit_category_id" => array(
                "label" => "Unit Category *",
                "model" => array("Unit_category", "id", array("title"), [
                    'conditions' => ['account_id=?', Acl_user::account_id()]
                ])
            ),

            "unit_type_id" => array(
                "label" => "Unit Type *",
                "model" => array("Unit_type", "id", array("title"), [
                    'conditions' => ['account_id=?', Acl_user::account_id()]
                ])
            ),

            "unit_group_code" => array("label" => "Unit Group Code "),
            "area_size" => array("label" => "Area Size  "),
            "measurement_type" => array(
                "label" => " Measurement Type ",
                "params" => [
                    "" => "--Select Measurement Type--",
                    "square_feet" => "Square Feet",
                    "hectares" => "Hectares",
                    "acres" => "Acres",
                    "meters" => "meters"
                ]
            ),
            "parking_space" => array(
                "label" => "Parking Space ",
                "params" => [
                    "" => "--Select Parking Space--",
                    "community_parking_only" => "Community Parking Only",
                ]
            ),
            "unit_price" => array("label" => "Units Price * ", "min" => 0, "required" => true),
            "tax_rate_id" => array(
                "label" => "Tax Rate",
                "model" => array(
                    "Tax_rate", "id", array("title"),
                    ["prepend" => ["" => '-Not Applicable-'], 'conditions' => ['account_id=?', Acl_user::account_id()]]
                )
            ),
            "legal_fee_amount" => array("label" => "Legal Fee * ", "required" => true),
            "office_disbursement_amount" => array("label" => "Office Disbursement * ", "required" => true),
            "late_payment_penalty_fee" => array("label" => "Late Payment Penalty * ", "required" => true),

            "kitchens_count" => array("label" => "Kitchen Count", "min" => 0, "value" => 0, "type" => "number"),
            "bedrooms_count" => array("label" => "Bedrooms Count", "min" => 0, "value" => 0, "type" => "number"),
            "balconies_count" => array("label" => "Balconies Count", "min" => 0, "value" => 0, "type" => "number"),
            "bathrooms_count" => array("label" => "Bathroom Count", "min" => 0, "value" => 0, "type" => "number"),

            "parking_count" => array("label" => "Parking Count", "min" => 0, "value" => 0, "type" => "number"),

            "garages_count" => array("label" => "Garages Count", "min" => 0, "value" => 0, "type" => "number"),
            "year_built" => array("label" => "Year Built", "type" => "number"),

            "start_date" => array("label" => "Start Date", "type" => "date"),
            "end_date" => array("label" => "End Date", "type" => "date"),




        );
    }


    public static function config($vars = [])
    {

        return array(
            "fields" => static::fields(['start_date', 'end_date'], false),
            "grid_fields" => array("project_id", "title", "purpose", "unit_category_id", "unit_type_id"),
            "conditions" => array("account_id=?", Session::user("account_id")),

            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions(),
            "form" => static::form_attrs()
        );
    }
}