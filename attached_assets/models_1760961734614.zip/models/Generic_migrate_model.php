<?php
class Generic_migrate_model extends pPort_model
{

    static $connection = 'smart_real_estate';
    static $table = 'lead_meetings';
    static $title = 'Lead Meeitn';
}