<?php
class User_location_journey extends Location_log
{
    static $title="Journey";
    static $name="Journey";
}