<?php

class Lead_meeting_cancellation extends pPort_model
{
    static $connection='smart_real_estate';
    static $table='lead_meeting_cancellations';
    static $title="Meeting cancellation";
    
    

    public static function config($vars=[])
    {
        return array(
            "conditions"=>["account_id=? AND deleted=0",Acl_user::account_id()],            
            "fields"=>array(
                "cancellation_date"=>array("label"=>"Cancellation Date",
                "required"=>true),
                "meeting_cancellation_reason_id"=>array(
                    "label"=>"Cancellation Reason",
                    "model"=>["Meeting_cancellation_reason","id","title"],
                    "required"=>true
                ),   
                "description"=>array("label"=>"Additional Notes",
                "required"=>true),   
            ),
        );
    }
}