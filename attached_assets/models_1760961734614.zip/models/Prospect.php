<?php
class Prospect extends pPort_model
{
    static $connection='smart_real_estate';
    static $table='prospects';
    static $title="Prospects";

}