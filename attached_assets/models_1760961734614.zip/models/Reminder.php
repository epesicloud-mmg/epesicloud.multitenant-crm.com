<?php

class Reminder extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'reminders';
    static $enabled_for_time_range = true;
    static $title = "Reminder";
    static $description = "(Reminder)";
    static $before_create = ["update_reminder_title", "add_reminder_creator"];
    static $after_create = ["add_to_calendar", "add_followup"];


    public function add_followup()
    {
        //Add to followup
        $reminder_data = [
            'followup_date' => date('Y-m-d'),
            'agent_id' => $this->user_id,
            'created_by' => $this->agent_id,
            'account_id' => $this->account_id,
            'followup_type_id' => Followup_type::alias_id_or_create("reminder"),
            'reminder_type_id' => $this->reminder_type_id,
            'enquiry_id' => $this->enquiry_id,
            'reminder_date' => $this->reminder_date,
            'reminder_time' => $this->reminder_time,
            'description' => $this->description,
            'linked_entity' => 'Reminder',
            'linked_entity_reference' => $this->id,
            'location_meta_data' => $this->location_meta_data,
            "meta_data" => json_encode($this->to_array()),
        ];

        Followup::create($reminder_data);
    }

    public function add_reminder_creator()
    {
        if (!$this->user_id) {
            if ($this->agent_id) {
                $this->user_id = $this->agent_id;
            } else {
                $this->user_id = Session::user("id");
            }
        } else {
            $this->agent_id = $this->user_id;
        }
    }

    public function update_reminder_title()
    {
        $reminder_type = Reminder_type::find($this->reminder_type_id);
        $reminder_for = "";
        if ($this->enquiry_id) {
            $enquiry = Enquiry::find($this->enquiry_id);
            $reminder_for = " for " . $enquiry->name;
        }
        if ($reminder_type) {
            $this->title = $reminder_type->title . " reminder " . $reminder_for;
        }
    }

    public function add_to_calendar()
    {
        $reminder_type = Reminder_type::find($this->reminder_type_id);
        $user_id = $this->user_id ? $this->user_id : $this->agent_id;

        Calendar_item::create(
            [
                'calendar_item_type_id' => Calendar_item_type::alias_id_or_create($reminder_type->alias),
                'linked_entity' => 'Reminder',
                'linked_entity_id' => $this->id,
                'account_id' => $this->account_id,
                'title' => $this->title,
                'start_date' => $this->reminder_date,
                'start_time' => $this->reminder_time,
                'created_by' => $user_id

            ]
        );
    }




    public static function fields_config()
    {
        $description = "";
        if (isset($_REQUEST['enquiry_id'])) {
            $enquiry = Enquiry::find($_REQUEST['enquiry_id']);

            $reminder_type_title = "Reminder ";
            if (isset($_REQUEST['reminder_type_id'])) {
                $reminder_type = Reminder_type::find($_REQUEST['reminder_type_id']);
                $reminder_type_title = $reminder_type->title;
            }
            $description = $reminder_type_title . " " . $enquiry->company_contact_name;
        }
        return array(
            "reminder_type_id" => array("label" => "Reminder For", "model" => ["Reminder_type", "id", "title", ["conditions" => ["account_id=?", Acl_user::account_id()]]], "required" => true),
            "enquiry_id" => array("label" => "Related To", "model" => ["Enquiry", "id", "name", ["prepend" => ["" => "-Select Client-"], "conditions" => ["account_id=?", Acl_user::account_id()]]]),
            //"title"=>array("label"=>"Title","required"=>true),                
            "reminder_date" => array("required" => true, "label" => "Reminder Date", "type" => "date"),
            "reminder_time" => array("required" => true, "label" => "Reminder Time", "params" => hours_range()),
            "description" => array("label" => "Additional Note", "value" => $description, "required" => true),

        );
    }




    public static function config($vars = [])
    {
        $config_data = array(
            "conditions" => ["account_id=? AND deleted=0", Acl_user::account_id()],
            "fields" => static::fields(),
            "form_actions" => static::form_actions(["save"])
        );

        if (isset($_REQUEST['enquiry_id'])) {
            $config_data["fields"]["enquiry_id"] = ["label" => "Enquiry", "value" => $_REQUEST['enquiry_id'], "type" => "hidden"];
        }
        return $config_data;
    }
}