<?php 
class Lead extends Enquiry
{

}