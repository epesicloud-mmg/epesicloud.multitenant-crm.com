<?php

/**
 * 
 * @author Martin Muriithi <martin@pporting.org>
 *
 **/
class Trip_lead extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'trip_leads';
    static $title = "Trip Booking";
    static $before_save = ["update_lead_details"];
    static $after_save = ["update_site_visit"];
    static $before_create = ["check_lead_existence"];
    static $belongs_to = [
        "lead" => ["lead", "foreign_key" => "lead_id", "class_name" => "Enquiry"],
        "trip" => ["trip", "foreign_key" => "trip_id", "class_name" => "Trip"],
    ];

    public function check_lead_existence()
    {
        $trip_lead_exists = Trip_lead::exists(['conditions' => ['trip_id=? AND 
            lead_id=?', $this->trip_id, $this->lead_id]]);
        if ($trip_lead_exists) {
            json_render(["info" => "error", "message" => "The lead is aleady added for the trip"]);
        }
    }


    public function update_lead_details()
    {
        $lead = Lead::find($this->lead_id);
        $this->lead_phone = $lead->phone;
        $this->lead_email = $lead->email;
        $this->lead_name = $lead->name;
    }


    public static function global_grid_actions()
    {
        return [
            'client_feed' => [
                "text" => 'Client Feed',
                'target' => '_blank',
                'href' => Url::component_panel("Enquiry/timeline/{@lead_id}"),
                //Exclude in these configs
                'excluded_configs' => []
            ]
        ];
    }

    public function update_site_visit()
    {
        if ($this->booking_status == "cancelled") {
            $lead_activity_type_id = Lead_activity_type::alias_id("site_visit_cancellation");
            $action = "cancellation";
        } else {
            if ($this->attendance_status == "present") {
                $lead_activity_type_id = Lead_activity_type::alias_id("site_visit_checkout");
                $action = "checkout";
            } else {
                $lead_activity_type_id = Lead_activity_type::alias_id("site_visit_scheduling");
                $action = "scheduling";
            }
        }
        //Site Visit Meeting Type
        $meeting_type_id = Meeting_type::alias_id("site_visit");
        $agent = Agent::find($this->agent_id);
        $trip = Trip::find($this->trip_id);
        if (!Lead_meeting::exists(['conditions' => ['trip_lead_id=?', $this->id]])) {
            $meeting_data = [
                'trip_lead_id' => $this->id,
                'trip_id' => $this->trip_id,
                'meeting_type_id' => $meeting_type_id,
                'enquiry_id' => $this->lead_id,
                'account_id' => $this->account_id,
                'agent_id' => $this->agent_id,
                'description' => $trip->description,
                'meeting_date' => $trip->trip_date,
                'start_time' => $trip->start_time,
                'end_time' => $trip->end_time,
                'supervisor_id' => $agent->supervisor_id,
                'action' => $action
            ];
            Lead_meeting::create($meeting_data);
        } else {
            $meeting = Lead_meeting::find_by_trip_lead_id($this->id);
            $meeting_data = [
                'trip_lead_id' => $this->id,
                'trip_id' => $this->trip_id,
                'meeting_type_id' => $meeting_type_id,
                'meeting_id' => $meeting->id,
                'enquiry_id' => $this->lead_id,
                'account_id' => $this->account_id,
                'agent_id' => $this->agent_id,
                'description' => $trip->description,
                'meeting_date' => $trip->trip_date,
                'supervisor_id' => $agent->supervisor_id,
                'action' => $action
            ];
            Lead_meeting_update::create($meeting_data);
        }
    }

    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                //"supervisor_id"=>array("label"=>"Supervisor *","model"=>["Supervisor","id",["first_name","last_name"],["conditions"=>["account_id=? AND role_id=".Acl_role::alias_id("supervisor"),Acl_user::account_id()]]]),
                "trip_id" => array("label" => "Trip *", "readonly" => true, "model" => ["Trip", "id", ["title", "trip_date"], ["conditions" => ["account_id=?", Acl_user::account_id()]]]),
                "trip_date" => array("label" => "Trip Date *", "format" => "date", "type" => "date", "readonly" => true, "value" => function ($result) {
                    $trip = Trip::find($result->trip_id);
                    if ($trip) {
                        return date("Y-m-d", strtotime($trip->trip_date));
                    }
                    return NULL;
                }),
                "agent_id" => array("label" => "Agent *", "model" => ["Agent", "id", ["first_name", "last_name"], ["conditions" => ["account_id=? AND role_id=" . Acl_role::alias_id("agent"), Acl_user::account_id()]]]),

                "lead_name" => array("label" => "Lead *", "style" => "width:100px;", "readonly" => true, "value" => function ($result) {
                    $lead = Lead::find($result->lead_id);
                    return $lead->name;
                }),
                "lead_phone" => array("label" => "Lead Phone", "style" => "width:200px;", "readonly" => true),
                "lead_email" => array("label" => "Lead Email", "readonly" => true),

                "confirmation_status" => array("label" => "Confirmation Status", "readonly" => true, "params" => [
                    "not_sure" => "Not Sure",
                    "sure" => "Sure",
                    "not_going" => "Not Going",
                    "did_not_pickup" => "Did Not Pickup",
                    "unreachable" => "Unreachable"
                ]),
                "confirmation_date" => array("label" => "Confirmation Date", "type" => "date", "default" => date("Y-m-d")),
                "confirmation_notes" => array("label" => "Confirmation Notes", "type" => "textarea"),


                "booking_date" => array("label" => "Booking Date", "readonly" => true, "type" => "date"),
                "booking_status" => array("label" => "Booking Status", "readonly" => true),

                "attendance_status" => array("label" => "Attendance Status *", "readonly" => true, "params" => ["present" => "Present", "absent" => "Absent", "late" => "Late"]),
                //"attendance_date"=>array("label"=>"Attendance Date","readonly"=>true,"type"=>"date","value"=>date("Y-m-d")),
            ),
            "conditions" => array("account_id=? AND booking_status<>'cancelled'", Acl_user::account_id()),
            "grid_actions" => [],
            "form_actions" => [],
            "form" => static::form_attrs()
        );
    }






    public static function ajaxfy_book()
    {


        $params = $_REQUEST;
        unset($params['url']);
        $trip_id = arr("trip_id", $params, NULL);
        $lead_id = arr("lead_id", $params, NULL);
        $lead = Enquiry::find($lead_id);
        $params['lead_phone'] = $lead->phone;
        $params['lead_email'] = $lead->email;
        if (isset($params['id']) && $params['id'] > 0) {
            $trip_lead = Trip_lead::find($params['id']);
        } else {
            $trip_lead_exists = Trip_lead::exists(['conditions' => ['account_id=? AND trip_id=? AND 
            lead_id=? AND deleted=0', $params['account_id'], $trip_id, $lead_id]]);
            if ($trip_lead_exists) {
                $trip_lead = Trip_lead::last(['conditions' => ['account_id=? AND trip_id=? AND 
                lead_id=?', $params['account_id'], $trip_id, $lead_id]]);
                /**if(isset($params['booking_status']) && $params['booking_status']=="cancelled")
                {
                    $params['deleted']=1;
                }**/



                $trip_lead->update_attributes($params);
            } else {
                $params['booking_date'] = date("Y-m-d");
                $trip_lead = Trip_lead::create($params);
            }
        }
        return ['info' => 'success', 'message' => 'Successfully updated'];
    }
}
