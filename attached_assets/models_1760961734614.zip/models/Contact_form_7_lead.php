<?php
class Contact_form_7_lead extends pPort_model
{
    static $connection='smart_real_estate';
    static $table='contact_form_7_leads';
    static $title="Contact Form 7 Leads";

    static $before_create="add_full_name";
    static $after_create=["sync_to_enquiries"];

    function add_full_name()
    {
        $this->name=$this->name?$this->name:$this->first_name." ".$this->last_name;
    }

    function sync_to_enquiries()
    {
        $account_id=$this->account_id;
        if($account_id && Acl_account::exists(['conditions'=>['id=?',$account_id]]))
        {			
            $lead_sources_ids=[
                "Twitter"=>Lead_source::alias_id('Website Twitter',$account_id),
                "Facebook"=>Lead_source::alias_id('Website Facebook',$account_id),
                "LinkedIn"=>Lead_source::alias_id('Website LinkedIn',$account_id),
                "Website"=>Lead_source::alias_id('Website',$account_id),
                "Website Chat"=>Lead_source::alias_id('Website Chat',$account_id),
                "Referral"=>Lead_source::alias_id('Website Referral',$account_id),
            ];

            $property_arr=[
                    'account_id'=>$this->account_id,
                    'phone'=>$this->phone,
                    'email'=> $this->email,
                    'name'=>$this->first_name." ".$this->last_name,
                    'project'=> $this->project,
                    "enquiry_date"=>date("Y-m-d"),
                    'country'=>$this->country,
                    'city'=>$this->city,
                    'description'=>$this->description,
                    'lead_source_id'=>arr(trim($this->lead_source),$lead_sources_ids,$this->lead_source),
                    'project_id'=>Project::alias_id($this->project,$account_id)
            ];
			
            $enquiry=Enquiry::create($property_arr);
            $sms_message="New Website Lead (".$this->lead_source."), Lead Name (".$property_arr["name"]."), Lead Phone (".$property_arr["phone"].")";
            echo json_encode(['info'=>'success','message'=>$sms_message]);
        }
    }
}