<?php
class Kpi_user extends Title_description
{
    static $connection='smart_real_estate';
    static $table='kpi_users';
    static $title="KPI User";
    static $description="(KPI User)";
    

    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "first_name"=>array("label"=>"First Name","required"=>true),
                "last_name"=>array("label"=>"Last Name","required"=>true),
                "email"=>array("label"=>"Email","required"=>true),
                "phone"=>array("label"=>"Phone","required"=>true)
            ),
            "grid_actions"=>static::grid_actions()
        );
    }

    public function get_name()
    {
        return $this->first_name." ".$this->last_name;
    }
    
}