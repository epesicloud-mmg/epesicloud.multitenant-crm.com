<?php

/**
 *
 * @author <Martin Muriithi> <martin@pporting.org>
 */
class Commision extends pPort_model
{

    static $table_name = "commisions";
    static $primary_key = "id";
    static $connection = 'smart_real_estate';

    static $enabled_for_time_range = true;

    static $title = 'Commisions';
    static $description = 'Manage Commisions';
    static $has_many = [
        "commision_items" => ["commision_items", "foreign_key" => "commision_id", "class_name" => "Commision_item"]
    ];
    static $belongs_to = [
        "user" => ["user", "foreign_key" => "user_id", "class_name" => "User"]
    ];

    static $before_save=["add_user_details"];


    public function add_user_details()
    {
        $user=User::find($this->user_id);
        if($user)
        {
            $this->payee_first_name=$user->first_name;
            $this->payee_last_name=$user->last_name;
            $this->payee_phone=$user->phone;
            $this->agent_id=$user->role->alias=="agent"?$user->id:NULL;
            $this->supervisor_id=$user->role->alias=="agent"?$user->supervisor_id:NULL;


        }
    }

    

    public static function grid_actions_config()
    {
        return [
            "edit" => ["label" => "Edit", "href" => Url::batch_panel("Commision/commision_items/{@id}")],
            "preview" => ["label" => "Preview", "target" => "blank", "href" => Url::component("Commision/invoice/{@id}")],
            'share_commision' => ["type" => "popup",  "label" => "Share Commision", "href" => function ($result) {
                return Url::form_panel("Commision_share?commision_id=".$result->id);
            }],
            'cancel' => ["type" => "popup",  "label" => "Cancel", "href" => function ($result) {
                return Url::status_type_change("Commision", $result->id, "cancelled");
            }],
            'verify' => function ($result) {
                return [
                    "label" => "Verify",
                    "type" => "popup",
                    "href" => function () use ($result) {
                        return Url::status_type_change("Commision", $result->id, "verified");
                    }
                ];
            },
            'approve' => function ($result) {
                return [
                    "label" => "Approve",
                    "type" => "popup",
                    "href" => function () use ($result) {
                        return Url::status_type_change("Commision", $result->id, "approved");
                    }
                ];
            },
            'decline' => function ($result) {
                return [
                    "label" => "Decline",
                    "type" => "popup",
                    "href" => function () use ($result) {
                        return Url::status_type_change("Commision", $result->id, "declined");
                    }
                ];
            },
        ];
    }

    public static function fields_config()
    {
        $user=Session::user();
        if($user->role->alias!="admin")
        {
            $modelUsers=["User","id",['first_name','last_name'],['conditions'=>['id=?',$user->id]]];
        }
        else
        {
            $modelUsers=["User","id",['first_name','last_name']];
        }
        
          return array(
            "user_id"=>["label"=>"Commission Request By","required"=>true,"model"=>$modelUsers],
            "bill_to" => array("label" => "Bill To", "required" => true, "value" => Session::user()->account->title),
            "commision_date" => array("label" => "Commision Date","readonly"=>true,"value"=>date("Y-m-d"), "type" => "date", "required" => true),
            "commission_items"=>["label"=>"Commission Items","value"=>function($result){
                $containers = [];
                if ($result->id) {
                    foreach ($result->commision_items as $commision_item) {
                        $project_title=$commision_item->unit->project?$commision_item->unit->project->title:"";
                        $containers[] = "<li>".$project_title.' '. $commision_item->unit->title .'-'.$commision_item->title.' '.number_format($commision_item->amount,2). "</li>";
                    }
                    return "<ul style='padding-left:20px;'>" . implode("", $containers) . "</ul>";
                }
            }],
            "commision_status_type_id" => array("label" => "Commision Status Type", "model" => array("Commision_status_type", "id", array("title"))),
            "description" => array("label" => "Description", "type" => "textarea"),
            
          );
    }


    public static function config($vars = [])
    {   
        if(Session::user()->role->alias=="accountant")
        {
            $grid_actions=['approve','decline','preview'];
        }
        else
        {
            $grid_actions=['edit','preview','cancel'];

        }     
        return array(
            "fields" => static::fields(['commission_items','commision_status_type_id'],false),
            "grid_fields" => static::fields(),
            "cols" => 2,
            "build_config" => true,
            "conditions" => ["account_id=?", Acl_user::account_id()],
            'grid_actions'=>static::grid_actions($grid_actions)
        );
    }
}