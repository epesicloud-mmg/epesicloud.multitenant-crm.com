<?php
class Amenity extends Title_description
{
    static $connection='smart_real_estate';
    static $table='amenities';
    static $title="Amenity";
    static $belongs_to=[
        'amenity_type'=>[
            'amenity_type','class_name'=>'Amenity_type','foreign_key'=>'amenity_type_id'
        ]
    ];

     public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "amenity_type_id"=>array("label"=>"Amenity Type","model"=>array('Amenity_type','id','title',['conditions'=>['account_id=?',Acl_user::account_id()]])), 
                "title"=>array("label"=>"Name"),
                "description" => array("label" => "Description", "type" => "textarea"),
                
             ),
            "cols"=>1,
            "conditions"=>array("account_id=? AND deleted=?",Acl_user::account_id(),0),
            
            "grid_actions"=>static::grid_actions(),
            "form_actions"=>static::form_actions(),
            "form"=>static::form_attrs(),
        );
    }
}