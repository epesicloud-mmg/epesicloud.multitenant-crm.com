<?php
class Third_party_agent  extends Agent
{
    public static function config($vars = [])
    {
        $config_data = array(
            "enable_add" => true,
            "fields" => static::fields(),
            "order" => "id ASC",
            "form_actions" => static::form_actions(),
            "grid_actions" => static::grid_actions(['edit'])
        );
        $config_data['fields']['role_id'] = ['label' => "Role", "value" => Role::alias_id("third_party_agent"), "type" => "hidden"];
    }
}