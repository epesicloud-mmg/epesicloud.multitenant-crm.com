<?php
/**
 *
 * @author <Martin Muriithi> <martin@pporting.org>
 */
class Enquiry_fix extends pPort_model
{

    static $table_name="enquiry_fixes";
    static $primary_key="id";
    static $connection='smart_real_estate';


    public static function ajaxfy_fix_enquiry_dates()
    {
        error_reporting(1);
        ini_set("display_errors","On");
        foreach(Enquiry_fix::all(['conditions'=>['fixed=?',0]]) as $enquiry_fix)
        {
            $enquiries=Enquiry::all(['conditions'=>['email=?',$enquiry_fix->email]]);
            if(!empty($enquiries))
            {
                foreach($enquiries as $enquiry)
                {
                    $explode_date=explode("/",$enquiry_fix->enquiry_date);
                    
                    if(isset($explode_date[2]))
                    {
                        $enquiry->enquiry_date=$explode_date[2].'-'.$explode_date[0].'-'.$explode_date[1];
                        $result=$enquiry->save();  
                        echo $enquiry->enquiry_date;
                        if($result)
                        {
                            $enquiry_fix->fixed=1;
                            
                        }              
                    }
                
                }
            }
            else
            {
                //Enquiry::create();
            }
            

            $enquiry_fix->checked=1;
            $enquiry_fix->save();
        }
    }


}