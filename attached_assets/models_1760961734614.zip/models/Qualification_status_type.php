<?php

class Qualification_status_type extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'qualification_status_types';
    static $title = "Qualification Status Type";



    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "title" => array("label" => "Title", "required" => true),
                "alias" => array("label" => "Alias", "required" => true),
                "description" => array("label" => "Description", "required" => true),
            ),
        );
    }
}