<?php

class Whatsapp_message extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'whatsapp_messages';
    static $title = "Log Whatsapp Message";
    static $description = "(Whatsapp Message)";
    static $before_create = ["add_agent_id","add_message_date"];
    static $after_create = ["add_lead_activity", "update_enquiry_statuses"];

    function add_message_date()
    {
        $this->whatsapp_message_date=$this->whatsapp_message_date??date("Y-m-d H:i:s");
    }

    function update_enquiry_statuses()
    {
        $lead = Enquiry::find($this->enquiry_id);
        if ($this->lead_interest_level_id) {
            $lead->lead_interest_level_id = $this->lead_interest_level_id;
        }

        if ($this->sale_stage_id) {
            $lead->sale_stage_id = $this->sale_stage_id;
        }
    }

    function add_agent_id()
    {
        if (!$this->agent_id) {
            $user = Session::user();
            $this->agent_id = $user->id;
            $this->supervisor_id = $user->supervisor_id;
        }
    }

    function add_lead_activity()
    {
        Lead_activity::create([
            'enquiry_id' => $this->enquiry_id,
            'followup_type_id' => Lead_activity_type::alias_id_or_create("whatsapp"),
            'description' => $this->content,
            'linked_entity' => 'Whatsapp_message',
            'linked_entity_reference' => $this->id,
            "account_id" => $this->account_id,
            'agent_id' => $this->agent_id,
            'followup_date' => date("Y-m-d",strtotime($this->whatsapp_message_date)),
            'followup_time' => $this->whatsapp_message_date
        ]);
    }

    public static function fields_config()
    {
        return array(
            "enquiry_id" => ['label' => "Select Lead", "type" => "hidden", "value" => $_REQUEST['enquiry_id']],
            "phone" => array("label" => "Phone", "required" => true),
            "content" => array("label" => "Message Notes", "type" => "textarea", "required" => true),
            "lead_interest_level_id" => ['label' => "Interest Level",  "model" => ["Lead_interest_level", "id", "title"]],
            "sale_stage_id" => ['label' => "Sale Stage",  "model" => ["Sale_stage", "id", "title"]],
            "whatsapp_message_date" => array("label" => "WhatsApp Date", "value" => date("Y-m-d"), "required" => true, "format" => "date"),

        );
    }

    public static function config($vars = [])
    {
        $config_data = array(
            "fields" => static::fields(['enquiry_id', 'content', "lead_interest_level_id", "sale_stage_id"]),
            "grid_fields" => static::fields(),
            "form_actions" => static::form_actions(["save"])
        );
        return $config_data;
    }
}