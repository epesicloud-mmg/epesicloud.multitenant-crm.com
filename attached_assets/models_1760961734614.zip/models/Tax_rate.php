<?php
class Tax_rate extends Title_description
{
    static $connection='smart_real_estate';
    static $table='tax_rates';
    static $title="Tax Rate";
    static $description="(Manage Tax Rates)";
    

    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "title"=>array("label"=>"Title *","required"=>true),
                "rate"=>array("label"=>"Rate *","required"=>true),
                "description"=>array("label"=>" Description","type"=>"textarea"),
            ),
            "conditions"=>array("account_id=?",Acl_user::account_id()),
            "grid_actions"=>static::grid_actions()
        );
    }
    
}