<?php

/**
 * Handles User to Groups Many-to-many Lead_activitys
 *
 * User_group Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Apartment extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'apartments';
    static $title = "Apartments";
    static $description = "(Manage Apartments)";
    static $before_save = array('add_account');
    static $belongs_to = [
        // 'owner'=>['owner','class_name'=>'Owner','foreign_key'=>'owner_id']
    ];

    static $has_many = [

        'enquiries' => ['enquiries', 'class_name' => 'Enquiry', 'foreign_key' => 'project_id'],
        'sale_interests' => ['sale_interests', 'class_name' => 'Sale_interest', 'foreign_key' => 'project_id'],
        'sales' => ['sales', 'class_name' => 'Sale', 'foreign_key' => 'project_id'],
        'sale_payments' => ['sale_payments', 'class_name' => 'Sale_payment', 'foreign_key' => 'project_id', 'summary_metric' => 'SUM(amount)'],
        'units' => ['units', 'class_name' => 'Unit', 'foreign_key' => 'court_id'],

    ];





    public static function config($vars = [])
    {

        return array(
            "fields" => array(
                "photo_1" => array(
                    "label" => "Photo (1)",
                    "title" => " ",
                    "type" => "ajax_file",
                    "style" => "width:150px;height:150px;",
                    "target" => APP_PATH . 'storage/uploads/',
                    'base_relative' => 'app/storage/uploads/',
                    "max_size" => 500000,
                    "entity" => "Gallery",
                    "formats" => "jpeg,png,jpg",
                ),
                "photo_2" => array(
                    "label" => "Photo (2)",
                    "title" => " ",
                    "type" => "ajax_file",
                    "style" => "width:150px;height:150px;",
                    "target" => APP_PATH . 'storage/uploads/',
                    'base_relative' => 'app/storage/uploads/',
                    "max_size" => 500000,
                    "entity" => "Gallery",
                    "formats" => "jpeg,png,jpg",
                ),
                "photo_3" => array(
                    "label" => "Photo (3)",
                    "title" => " ",
                    "type" => "ajax_file",
                    "style" => "width:150px;height:150px;",
                    "target" => APP_PATH . 'storage/uploads/',
                    'base_relative' => 'app/storage/uploads/',
                    "max_size" => 500000,
                    "entity" => "Gallery",
                    "formats" => "jpeg,png,jpg",
                ),
                "photo_4" => array(
                    "label" => "Photo (4)",
                    "title" => " ",
                    "type" => "ajax_file",
                    "style" => "width:150px;height:150px;",
                    "target" => APP_PATH . 'storage/uploads/',
                    'base_relative' => 'app/storage/uploads/',
                    "max_size" => 500000,
                    "entity" => "Gallery",
                    "formats" => "jpeg,png,jpg",
                ),
                "project_id" => array("label" => "Project * ", "required" => true, "model" => array(
                    'Project', 'id',
                    array('title'), array('conditions' => array('account_id=?', Acl_user::account_id()))
                )),
                "court_id" => array("label" => "Court * ", "required" => true, "model" => array('Court', 'id', array('title'), array('conditions' => array('account_id=?', Acl_user::account_id())))),
                /**"block_id"=>array("label"=>"Block * ","required"=>true,"model"=>array('Block','id',array('title'),
                array('conditions'=>array('account_id=?',Acl_user::account_id())))),**/

                "apartment_type_id" => array("label" => "Type *", "model" => array('Apartment_type', 'id', 'title', ['init' => ['' => '--Select Property Type--']]), "required" => true),
                "apartment_category_id" => array("label" => "Category *", "model" => array('Apartment_category', 'id', 'title', ['init' => ['' => '--Select Property Category--']]), "required" => true),
                "title" => array("label" => "Apartment Name *", "required" => true),
                "apartment_code" => array("label" => "Apartment Code *"),
                //"owner_id"=>array("label"=>"Owner * ","required"=>true,"model"=>array('Owner','id',array('first_name','middle_name','last_name'),array('conditions'=>array('account_id=? AND role_id=?',Acl_user::account_id(),Role::alias_id('owner'))))),
                "description" => array("label" => "Apartment Description *", "class" => "form-control", "type" => "textarea", "style" => "height:200px;"),
                "lowest_offer" => ["label" => "Lowest Offer"],
                "highest_offer" => ["label" => "Highest Offer"],

            ),
            "grid_fields" => ["photo_1", "project_id", "court_id", "title", "apartment_code", "apartment_category_id", "apartment_type_id"],
            "api_fields" => ["photo_1", "photo_2", "project_id", "court_id", "block_id", "title", "description", "apartment_code", "apartment_category_id", "apartment_type_id", "lowest_offer", "highest_offer"],

            "conditions" => array("account_id=?", Acl_user::account_id()),

        );
    }
}
