<?php

class Agent_meeting extends Lead_meeting
{
    public static function config($vars=[])
    {
        $config_data=array(
            "limit"=>200,
            "conditions"=>["account_id=? AND deleted=0",Acl_user::account_id()],
            "fields"=>array(
                "meeting_type_id"=>array("label"=>"Meeting For","model"=>["Meeting_type","id","title",["conditions"=>["account_id=?",Acl_user::account_id()]]],"required"=>true),
                "enquiry_id"=>array("label"=>"Lead","required"=>true,"model"=>["Enquiry","id",
                "name",["prepend"=>[""=>"-Select Lead-"],
                "conditions"=>["account_id=? AND agent_id=".Session::user("id"),Acl_user::account_id()]]]),
                "meeting_date"=>array("required"=>true,"label"=>"Meeting Date","type"=>"date"),
                "start_time"=>array("required"=>true,"label"=>"Start Time","params"=>hours_range()),
                "end_time"=>array("required"=>true,"label"=>"End Time","params"=>hours_range()),
                "meeting_location"=>array("required"=>true,"label"=>"Meeting Location"),
                "description"=>array("label"=>"Additional Note","required"=>true),
                "agent_id"=>array("label"=>"Agent","type"=>"hidden","value"=>Session::user("id"),"required"=>true),
                "action"=>array("label"=>"Action","type"=>"hidden","value"=>"scheduling","required"=>true),               
            ),
            "grid_actions"=>[]
        );
        return $config_data;
    }

}