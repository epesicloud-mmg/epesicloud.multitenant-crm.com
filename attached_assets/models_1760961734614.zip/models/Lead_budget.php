<?php

/**
 * Handles User lead_activities
 *
 * User Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Lead_budget extends pPort_model
{

    static $table = 'lead_budgets';
    static $name = 'Lead Budgets';
    static $before_save = array('add_account');
    static $connection = 'smart_real_estate';



    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "title" => array("label" => "Type Name"),
                "description" => array("label" => "Description", "type" => "textarea"),

            ),
            "cols" => 1,
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),

            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions(),
            "form" => static::form_attrs(),
        );
    }
}
