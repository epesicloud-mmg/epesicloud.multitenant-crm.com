<?php
class Sale extends pPort_model
{
    static $table = 'sales';
    static $title = "Lease/Sale Agreements";
    static $description = "(Contract Module)";
    static $connection = 'smart_real_estate';

    static $has_many = [
        'sale_payments' => ['sale_payments', 'class_name' => 'Sale_payment', 'foreign_key' => 'sale_id', 'show' => 'grid'],
        'sale_documents' => ['sale_documents', 'class_name' => 'Sale_document', 'foreign_key' => 'sale_id', 'show' => 'grid'],


    ];

    static $belongs_to = [
        'unit' => ['unit', 'class_name' => 'Unit', 'foreign_key' => 'unit_id', 'show' => 'grid'],
        'court' => ['court', 'class_name' => 'Court', 'foreign_key' => 'court_id', 'show' => 'grid'],
        'block' => ['block', 'class_name' => 'Block', 'foreign_key' => 'block_id', 'show' => 'grid'],
        'project' => ['project', 'class_name' => 'Project', 'foreign_key' => 'project_id', 'show' => 'grid'],
        'apartment' => ['apartment', 'class_name' => 'Apartment', 'foreign_key' => 'apartment_id', 'show' => 'grid'],
        'customer_type' => ['customer_type', 'class_name' => 'Customer_type', 'foreign_key' => 'apartment_id', 'show' => 'grid'],
        'tax_rate' => ['tax_rate', 'class_name' => 'Tax_rate', 'foreign_key' => 'tax_rate_id', 'show' => 'grid']

    ];

    static $before_save = ["add_tax_rate_id", "add_is_deleted_if_cancelled"];
    static $after_save = ["propagate_status"];
    static $filter_date = "sale_date";

    /**static $entity_status_logs=[
        'Enquiry'=>[
            'entity'=>'Enquiry',
            'status'=>"interest_form_added",
            "entity_reference_key"=>'id' 
        ]
            
    ];**/

    public function add_tax_rate_id()
    {
        if (!$this->tax_rate_id) {
            $unit = Unit::find($this->unit_id);
            if ($unit && $unit->unit_group) {
                $unit_group = $unit->unit_group;
                $this->tax_rate_id = $unit_group->tax_rate_id;
            }
        }
    }

    public function propagate_status()
    {
        if ($this->is_cancelled) {
            if ($this->sale_offer_id) {
                $sale_offer = Sale_offer::find($this->sale_interest_id);
                $sale_offer->is_cancelled = 1;
                $sale_offer->save();
            }
        }
    }


    public static function workflow_config()
    {
        return [
            'verified' => [
                "permissions" => ["review_letter_of_offers"],
                "condition" => "is_verified=0",
                "pending_label" => "Pending Verify"

            ],
            'legal_emailed' => [
                "permissions" => ["prepare_sale_contracts"],
                "condition" => "is_verified=1",
                "do_label" => "Notify Legal for Review",
                "pending_label" => "Pending LegalMail",
                "after_verify" => function ($workflow, $stage, $entity_data) {
                    $users = $workflow::workflow_stage_permitted_users('prepare_sale_contracts');

                    foreach ($users as $user) {
                        $sms_message = "A new sale contract creation is pending your action.";
                        die($sms_message);
                        Sms::send($sms_message, $user->phone);
                    }
                }
            ],
            'legal_reviewed' => [
                "permissions" => ["prepare_sale_contracts"],
                "condition" => "is_legal_emailed=1",
                "pending_label" => "Pending LegalReview",
            ],
            'legal_fees_paid' => [
                "condition" => "is_verified=1 AND is_legal_reviewed=0",
                "pending_label" => "Pending LegalFee",
            ],
            'stamp_duty_paid' => [
                "condition" => "is_verified=1  AND is_legal_reviewed=0",
                "pending_label" => "Pending LegalStampDuty",
            ],
            'signed_by_directors' => [
                "permissions" => ["append_director_signature_to_letter_of_offers"],
                "condition" => "is_verified=1",
                "after_verify" => function ($workflow, $stage, $entity_data) {
                    $users = $workflow::workflow_stage_permitted_users($stage);
                    vd($users);
                    foreach ($users as $user) {
                        $sms_message = "A new Letter of offer has been queued pending your signature.";
                        Sms::send($sms_message, $user->phone);
                    }
                },
                "after_reject" => function ($workflow, $stage, $entity_data) {
                    $users = $workflow::workflow_stage_permitted_users($stage);
                    vd($users);
                    foreach ($users as $user) {
                        $sms_message = "The letter of offer submitted for review has been rejected.";
                        Sms::send($sms_message, $user->phone);
                    }
                },
                "pending_label" => "Pending DirectorSign",
            ],
            'client_emailed' => [
                "condition" => "is_verified=1 AND is_signed_by_directors=1",
                "do_label" => "Email Client",
                "pending_label" => "Pending ClientEmail",
            ],
            'signed_by_client' => [
                "condition" => "is_verified=1 AND is_client_emailed=1 AND is_signed_by_directors=1",
                "pending_label" => "Pending ClientSign",
                "show_approved_menu" => true,
                'approved_label' => 'Signed By Client',
            ],

            'cancelled' => [
                'editor_roles' => ['admin'],
                'cancel_roles' => ['admin'],
                'pending_label' => 'Cancel Sale',
                //"after_approved"=>['update_unit_reservation'],
                "show_pending_menu" => false,
                "show_approved_menu" => true
            ],

        ];
    }


    public static function global_grid_actions()
    {
        return Sale_interest::global_grid_actions();
    }

    public static function fields_config()
    {

        return array(
            "name" => array("label" => "Client Name"),
            "email" => array("label" => "Client Email"),
            "phone" => array("label" => "Client Phone"),
            "company_name" => array("label" => "Company"),
            "customer_type_id" => array("label" => "Buyer Type", 'required' => true, 'model' => array('Customer_type', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),


            "interest_form_upload" => ['label' => 'Interest Form Upload', 'type' => 'file'],
            "nationality" => array("label" => "Nationality", "required" => true),
            "postal_address" => array("label" => "Postal Address", "required" => true),
            "postal_code" => array("label" => "Postal Code", "required" => true),
            "residential_address" => array("label" => "Residential Address"),
            "current_ownership_status" => array("label" => "Residential Category", "params" => ["owned" => "Owned", "rental" => "Rental"]),
            //"phone"=>array("label"=>"Phone","required"=>true),
            //"email"=>array("label"=>"Email","required"=>true),
            "age" => array("label" => "Age", "params" => ["18_25" => "18-25 Years", "25_35" => "25-35 Years", "35_45" => "34-45 Years", "45_55" => "45-55 Years", "55_65" => "55-65 Years", "over_65" => "Over 65 years"]),
            "gender" => array("label" => "Gender", "params" => ["male" => "Male", "female" => "Female", "other" => "Other"]),
            "race" => array("label" => "Race", "params" => [
                "American Indian or Alaskan Native", "Asian / Pacific Islander", "Black or African American",
                "Hispanic American", "White / Caucasian", "Multiple ethnicity"
            ]),
            "marital_status" => array("label" => "Marital Status", "params" => [
                "not_applicable" => "Not Applicable", "married" => "Married",
                "widowed" => "Widowed", "divorced" => "Divorced", "separated" => "Separated", "never_married" => "Never Married"
            ]),
            "education" => [
                "label" => "Education", "params" => ["Less than high school degree", "High school degree or equivalent (e.g., GED)
            ", "Some college but no degree", "Associate degree", "Bachelor degree", "Graduate degree"]
            ],
            "employment_status" => [
                'label' => 'Emplotment Status', 'params' => [
                    "employed" => "Employed",
                    "self_employed" => "Self Employed",
                    "student" => "Student",
                    "retired" => "Retired",
                    "unemployed" => "Unemployed"
                ]
            ],
            "employer_name" => array("label" => "Employer/Business Name"),
            "profession" => array("label" => "Profession"),
            "employment_position" => array("label" => "Position/Title"),
            "net_monthly_icome" => array("label" => "Monthly Icome"),
            "agent_id" => array("label" => "Account Exec", 'required' => true, 'model' => array(
                'Acl_user', 'id',
                ['first_name', 'last_name'], ["conditions" => ["role_id=? AND account_id=? AND deleted=0", Role::alias_id('agent'), Acl_user::account_id()], "prepend" => ["0" => "--Assigned Agent--"]]
            )),
            "lead_source_id" => array("label" => "Lead Source", 'required' => true, 'model' => array('Lead_source', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
            "date_of_birth" => array("label" => "Date of Birth", "type" => "date"),
            "unit_id" => array("label" => "Unit", 'required' => true, 'model' => array('Unit', 'id', 'title', ['conditions' => ['account_id=? AND status="available"', Acl_user::account_id()]])),
            "budget" => array("label" => "Budget"),
            "payment_method_id" => array(
                "label" => "Preferred Payment Method", 'required' => true,
                'model' => array('Payment_method', 'id', 'title')
            ),
            "sale_amount" => array("label" => "Sale Price", "required" => true),
            "deposit" => array("label" => "Deposit", "required" => true),
            "tax_rate_id" => array(
                "label" => "Tax Rate *",
                "model" => array(
                    "Tax_rate", "id", array("title"),
                    ["prepend" => ["" => '-Not Applicable-'], 'conditions' => ['account_id=?', Acl_user::account_id()]]
                )
            ),
            "identification_type" => array("label" => "Idenification Type", "params" => ["id_no" => "Id No", "passport" => "Passport"]),
            "identification_number" => array("label" => "Identification Number", "required" => true),
            "personal_identification_number" => array("label" => "PIN", "required" => true),
            "sale_offer_date" => array("label" => "Sale Offer Date", "type" => "date", "required" => true),
            "sale_offer_due_date" => array("label" => "Sale Offer Due Date", "required" => true, "type" => "date"),
            "sale_date" => array("label" => "Sale Date", "type" => "date", "required" => true),


            "enquiry_id" => array("label" => "Enquiry", "type" => "hidden", "required" => true),


        );
    }

    public static function config($vars = [])
    {


        return array(
            "fields" => static::fields(),
            "grid_fields" => array(
                "sale_date" => array("label" => "Sale Date", "type" => "date", "required" => true),
                "enquiry_id" => array("label" => "Lead", 'required' => true, 'model' => array('Enquiry', 'id', 'name', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                "customer_type_id" => array(
                    "label" => "Buyer Type", 'required' => true,
                    'model' => array('Customer_type', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])
                ),

                "project_id" => array("label" => "Project", 'required' => true, 'model' => array('Project', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                //"court_id" => array("label" => "Court", 'required' => true, 'model' => array('Court', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                //"apartment_id" => array("label" => "Apartment", 'required' => true, 'model' => array('Apartment', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                //"block_id" => array("label" => "Block", 'required' => true, 'model' => array('Block', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                "unit_group_id" => array("label" => "Sevice Item", 'required' => true, 'model' => array('Unit_group', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                //"unit_id" => array("label" => "Unit", 'required' => true, 'model' => array('Unit', 'id', 'title', ['conditions' => ['account_id=? AND status="available"', Acl_user::account_id()]])),
                "sale_amount" => array("label" => "Sale Price", "required" => true),
                "tax_rate_id" => array(
                    "label" => "Tax Rate",
                    "model" => array(
                        "Tax_rate", "id", array("title"),
                        ["prepend" => ["" => '-Not Applicable-'], 'conditions' => ['account_id=?', Acl_user::account_id()]]
                    )
                ),
                "deposit" => array("label" => "Deposit", "required" => true),

            ),
            "filters" => true,
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),
            'form_actions' => static::form_actions(['save']),
            'grid_actions' => [
                'view' => [
                    'label' => 'View',
                    'text' => 'View',
                    'href' => Url::batch_panel('Sale_offer/payment_plans/{@id}')
                ]
            ],
            "form" => static::form_attrs(),
            "form_attrs" => ["window_location" => Url::grid_panel("Sale_offer")]


        );
    }

    public static function config_payment($vars = [])
    {
        $config_data = static::config($vars);
        $config_data['conditions'] = array("account_id=? AND deleted=? AND is_stamp_duty_paid=1", Acl_user::account_id(), 0);
    }

    public static function config_title_request($vars = [])
    {
        return array(
            "fields" => static::fields(),
            'grid_actions' => [
                'initiate_title_request' => [
                    'label' => 'Initiate Title Request',
                    'href' => Url::form_panel("Title_request/clone/Sale/id/{@id}")
                ]
            ],
            "form" => static::form_attrs(),
        );
    }

    public static function lead_activities_count()
    {
        return Lead_activity::count();
    }

    public static function meetings_count()
    {
        return Lead_meeting::count(['conditions' => ['is_checked_out=1 AND account_id=?',  Acl_user::account_id()]]);
    }

    public static function calls_count()
    {
        return Followup::count(['conditions' => ['followup_type_id=? AND account_id=?',Followup_type::alias_id('call'),Acl_user::account_id()]]);
    }

    public static function whatsapp_count()
    {
        return Followup::count(['conditions' => ['followup_type_id=? AND account_id=?',Followup_type::alias_id('whatsapp'),Acl_user::account_id()]]);
    }

    public static function sms_count()
    {
        return Followup::count(['conditions' => ['followup_type_id=? AND account_id=?',Followup_type::alias_id('sms'),Acl_user::account_id()]]);
    }

    public static function lead_count()
    {
        $leads_count=Enquiry::count(['conditions'=>['account_id=?',Acl_user::account_id()]]);
        return $leads_count;
    }

    

    public static function lead_value()
    {
        $deal_value=Enquiry::sum(['sum'=>'deal_amount','conditions'=>['account_id=? AND qualify_status="pending"',
        Session::user("account_id")]]);
        return $deal_value;
    }

    public static function average_lead_value()
    {
        return static::lead_value()/static::lead_count();
    }



    public static function opportunity_count()
    {
        $leads_count=Enquiry::count(['conditions'=>['account_id=?',Acl_user::account_id()]]);
        return $leads_count;
    }

    public static function opportunity_value()
    {
        $deal_value=Enquiry::sum(['sum'=>'deal_amount','conditions'=>['account_id=? AND qualify_status="pending"',
        Session::user("account_id")]]);
        return $deal_value;
    }

    public static function average_opportunity_value()
    {
        return static::opportunity_value()/static::opportunity_count();
    }


    public static function sale_value()
    {
        $sale_interest=Sale::sum(['sum'=>'sale_amount','conditions'=>['account_id=? AND deleted=0 AND is_verified=1',Acl_user::account_id()]]);
        return $sale_interest;
    }

    public static function sale_count()
    {
        $sale_interest=Sale::count(['conditions'=>['account_id=? AND deleted=0 AND is_verified=1',Acl_user::account_id()]]);
        return $sale_interest;
    }

    public static function average_sale_value()
    {
        return ceil(static::sale_value()/static::sale_count());
    }

    public static function average_time_to_close()
    {
        // Assuming Leads and Sales models and timestamp columns
        $leadToSaleDurations = array();
        $startDate = date('Y-m-d H:i:s', strtotime('-6 months'));
        $endDate = date('Y-m-d H:i:s');
        $leads = Enquiry::all(array('conditions' => array('created_at BETWEEN ? AND ?', $startDate, $endDate)));

        foreach ($leads as $lead) {
            // Find the corresponding sale for each lead
            $sale = Sale::find_by_enquiry_id($lead->id);

            if ($sale && $lead->created_at && $sale->created_at) {
                // Calculate the duration in seconds
                $duration = strtotime($sale->created_at) - strtotime($lead->created_at);
                $leadToSaleDurations[] = $duration;
            }
        }

        // Calculate the average duration
        $averageDuration = count($leadToSaleDurations) > 0
            ? array_sum($leadToSaleDurations) / count($leadToSaleDurations)
            : 0;

        // Convert average duration to a human-readable format if needed
        return gmdate("H:i:s", $averageDuration);

    }


    

    public static function velocity()
    {
        $sixMonthsAgo = date('Y-m-d H:i:s', strtotime('-6 months'));
        $salesData = static::find('all', array('conditions' => array('created_at >= ?', $sixMonthsAgo)));
        $totalSalesAmount = 0;
        foreach ($salesData as $sale) {
            $totalSalesAmount += $sale->amount; // Assuming 'amount' is the column representing the sales amount
        }
        $salesVelocity = $totalSalesAmount / 6; // Assuming you want to calculate the velocity per month
        return $salesVelocity;
    }

   

    public static function dropoff_rate()
    {
        return mt_rand(1,20);
    }

    public static function win_rate()
    {
        return mt_rand(1,20);
    }

    public static function conversion_rate($i=6)
    {
        $startDate = date('Y-m-d H:i:s', strtotime('-'.$i.' months')); // Adjust the time frame as needed
        $endDate = date('Y-m-d H:i:s');
        $leadsCount = Lead::count(array('conditions' => array('created_at BETWEEN ? AND ?', $startDate, $endDate)));
        $salesCount = Sale::count(array('conditions' => array('created_at BETWEEN ? AND ?', $startDate, $endDate)));
        $conversionRatio = ($leadsCount > 0) ? ($salesCount / $leadsCount) : 0;
        $conversionRatioPercentage = $conversionRatio * 100;
        return ceil($conversionRatioPercentage);
    }

    public static function month_conversion_rates($i="6")
    {
        // Assuming Leads and Sales models and 'created_at' columns are used for timestamps
        $monthlyConversionRatios = array();

        for ($i = 5; $i >= 0; $i--) {
            $startDate = date('Y-m-01 00:00:00', strtotime("-$i months"));
            $endDate = date('Y-m-t 23:59:59', strtotime("-$i months"));

            $leadsCount = Lead::count(array('conditions' => array('created_at BETWEEN ? AND ?', $startDate, $endDate)));
            $salesCount = Sale::count(array('conditions' => array('created_at BETWEEN ? AND ?', $startDate, $endDate)));

            $conversionRatio = ($leadsCount > 0) ? ($salesCount / $leadsCount) : 0;

            $yearMonth = date('Y-m', strtotime("-$i months"));
            $monthlyConversionRatios[$yearMonth] = ceil($conversionRatio);
        }

        // Now $monthlyConversionRatios contains the conversion ratios for each month in the past 6 months
        return($monthlyConversionRatios);

    }



    

    
}
