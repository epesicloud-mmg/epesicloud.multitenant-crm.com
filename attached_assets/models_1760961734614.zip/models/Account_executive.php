<?php
class Account_executive extends Agent
{
    static $name="Agent";
    static $title="Agent";
    static $has_many=[
        'enquiries'=>['enquiries','class_name'=>'Enquiry','foreign_key'=>'agent_id'],
        'calls'=>['calls','class_name'=>'Followup_call','foreign_key'=>'agent_id'],
        'sms'=>['sms','class_name'=>'Followup_sms','foreign_key'=>'agent_id'],
        'scheduled_visits'=>['scheduled_visits','class_name'=>'Followup_scheduled_visit','foreign_key'=>'agent_id'],
        'visits'=>['visits','class_name'=>'Followup_visit','foreign_key'=>'agent_id'],
        'reminders'=>['reminders','class_name'=>'Followup_reminder','foreign_key'=>'agent_id'],
        'sales'=>['sales','class_name'=>'Sale','foreign_key'=>'agent_id'],
    ];
}