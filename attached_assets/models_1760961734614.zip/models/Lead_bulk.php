<?php
class Lead_bulk extends pPort_model
{
    static $name = 'Bulk Enquiry';
    static $table = "lead_bulks";
    static $connection = 'smart_real_estate';
    static $before_save = ['clean_phone', 'add_meta_data'];
    static $before_csv_purge = ["delete_uploaded_data"];
    static $csv_upload_token = NULL;
    function clean_phone()
    {
        $this->phone = str_replace("p:+", "", $this->phone);
    }

    static $after_csv_upload = [
        'update_enquiries_per_account_executive'
    ];


    public static function delete_uploaded_data()
    {
        //Delete from enquiries

        if (static::$csv_upload_token) {
            Enquiry::delete_all(['conditions' => ['csv_upload_token=? AND account_id=? AND created_by=?', static::$csv_upload_token, Session::user("account_id"), Session::user("id")]]);
        }
    }

    public function add_meta_data()
    {
        $this->add_agent_id();
        $this->account_id = Session::user("account_id");
        $this->project_id = Project::alias_id($this->project);

        if ($this->customer_type) {
            $this->customer_type_id = Customer_type::alias_id_or_create($this->customer_type);
        }

        if ($this->lead_source) {
            $this->lead_source_id = Lead_source::alias_id_or_create($this->lead_source);
        }

        if ($this->lead_interest_level) {
            $this->lead_interest_level_id = Lead_interest_level::alias_id_or_create($this->lead_interest_level);
        }

        if ($this->industry) {
            $this->industry_id = Industry::alias_id_or_create($this->industry);
        }

        if ($this->company_name) {
            $this->company_id = Company::alias_id_or_create($this->company_name);
        }

        if ($this->originator_type) {
            $this->originator_type_id = Originator_type::alias_id_or_create($this->originator_type);
        }

        if ($this->designation_type) {
            $this->designation_type_id = Designation_type::alias_id_or_create($this->designation_type);
        }



        $this->csv_upload_token = static::$csv_upload_token;
    }

    public function add_agent_id()
    {

        if (Session::user()->role->alias == "agent") {
            $this->agent_id = Session::user("id");
        } else {
            //Find By Email
            $user = Acl_user::last(['conditions' => ['email LIKE "%' . $this->agent_email . '%" AND account_id=?', Session::user("account_id")]]);

            if ($user) {
                $this->agent_id = $user->id;
            }
        }
    }


    public function assign_bulk_leads_to_agent($agent)
    {
        if (is_object($agent)) {
            $agent_id = $agent->id;
        } else {
            $agent_id = $agent;
        }
        $bulk_enquiries = static::all(['conditions' => ['agent_id=? 
        AND synchronized_to_enquiry_attempted=0 AND csv_upload_token=?', $agent_id, static::$csv_upload_token]]);


        if (count($bulk_enquiries) > 0) {
            $this->bulk_enquiry_submit($bulk_enquiries);
        }
    }

    public function update_enquiries_per_account_executive()
    {

        if (Session::user()->role->alias == "agent") {
            $this->assign_bulk_leads_to_agent(Session::user());
        } else {
            $agent_grouped_uploads = static::all(
                [
                    'group' => 'agent_id',
                    'conditions' => ['csv_upload_token=? AND account_id=?', $this->csv_upload_token, Session::user("account_id")]
                ]
            );
            foreach ($agent_grouped_uploads as $agent_grouped_upload) {
                $this->assign_bulk_leads_to_agent($agent_grouped_upload->agent_id);
            }
        }
    }

    public static function ajaxfy_attempt_synchronize($id)
    {
        $bulk_enquiry = static::find($id);
        $bulk_enquiry->synchronize();
    }



    public function synchronize()
    {
        $agent_id = $this->agent_id;

        $parsed_date = $this->enquiry_date;
        $explode_date = explode("/", $this->enquiry_date);
        if (isset($explode_date[2])) {
            $parsed_date = $explode_date[2] . '-' . $explode_date[1] . '-' . $explode_date[0];
        }

        if ($this->first_name) {
            $name = $this->first_name . " " . $this->last_name;
        } else {
            $name = $this->contact_name ? $this->contact_name : $this->name;
        }


        //Prevent upload of duplicates

        $enquiry_data = [
            'name' => $name,
            'company_name' => $this->company_name,
            'description' => $this->description,
            'enquiry_date' => $parsed_date,
            'raw_date' => $this->enquiry_date,
            'phone' => $this->phone,
            'email' => $this->email,
            //'project'=>$this->project,
            'project_id' => $this->project_id,
        ];
        $enquiry_existing = NULL;
        if (is_email($this->email)) {
            $enquiry_existing = Enquiry::find(['conditions' => ['account_id=? AND 
                        email LIKE "%' . $this->email . '%"', Session::user("account_id")]]);
        }
        if (!$enquiry_existing) {
            if ($this->phone != "" && $this->phone != NULL) {
                $enquiry_existing = Enquiry::find(['conditions' => ['account_id=? AND 
                    phone LIKE "%' . $this->phone . '%"', Session::user("account_id")]]);
            }
        }
        if ($enquiry_existing) {
            //ENABLE THIS WITH PRECAUTION : DO NOT UPDATE AS A PRECAUTION, AGENTS CAN USE THIS TO GET OTHER AGENTS LEADS
            //$enquiry_existing->update_attributes($enquiry_data);
            return false;
        }

        //If No E-mail & Phone do not upload
        if ($this->phone == "" || $this->phone == NULL) {
            if ($this->email == "" || $this->email == NULL) {
                return false;
            }
        }

        $enquiry_data['agent_id'] = $agent_id;
        $enquiry_data['customer_type_id'] = $this->customer_type_id;
        $enquiry_data['originator_type_id'] = $this->originator_type_id;
        $enquiry_data['company_id'] = $this->company_id;
        $enquiry_data['industry_id'] = $this->industry_id;
        $enquiry_data['lead_interest_level_id'] = $this->lead_interest_level_id;
        $enquiry_data['lead_source_id'] = $this->lead_source_id;
        //$enquiry_data['lead_source']=$this->lead_source;
        //$enquiry_data['customer_type']=$this->customer_type;
        $enquiry_data['send_assignment_sms'] = 0;
        $enquiry_data['is_bulk_upload'] = 1;
        $enquiry_data['bulk_enquiry_id'] = $this->id;
        $enquiry_data['csv_upload_token'] = $this->csv_upload_token;



        /** if(!Enquiry::exists(['conditions'=>['phone LIKE "%'.$this->phone.'%" OR email LIKE "%'.$this->email.'%"']])){*/
        $enquiry = Enquiry::create($enquiry_data);
        if ($enquiry) {
            $this->synchronized_to_enquiry_successful = 1;
        }
        $this->agent_id = $agent_id;
        $this->synchronized_to_enquiry_attempted = 1;
        $this->enquiry_id = $enquiry->id;
        $this->save();
        /**}*/
        return true;
    }

    public function bulk_enquiry_submit($bulk_enquiries)
    {

        foreach ($bulk_enquiries as $bulk_enquiry) {

            $bulk_enquiry->synchronize();
        }
    }











    public static function config($vars = [])
    {
        return [
            'fields' => [
                'enquiry_date' => ['label' => 'Enquiry Date', 'type' => 'hidden'],
                'name' => ['label' => 'Enquiry Name', 'type' => 'hidden'],
                'company_name' => ['label' => 'Company', 'type' => 'hidden'],
                'phone' => ['label' => 'Phone', 'type' => 'hidden'],
                'email' => ['label' => 'Email', 'type' => 'hidden'],
                'lead_source' => ['label' => 'Lead Source', 'type' => 'hidden'],
                'description' => ['label' => 'Description', 'type' => 'hidden'],
                'customer_type' => ['label' => 'Customer Type', 'type' => 'hidden'],
                'project' => ['label' => 'Project', 'type' => 'hidden'],
                'account_executive' => ['label' => 'Account Executive', 'type' => 'hidden'],
                'first_name' => ['label' => 'First Name', 'type' => 'hidden'],
                'last_name' => ['label' => 'Last Name', 'type' => 'hidden'],
            ],
            'grid_actions' => [],
            'form_actions' => static::form_actions([]),
        ];
    }
}