<?php
/**
 * 
 * @author Martin Muriithi <martin@pporting.org>
 *
 **/
class Unit_category extends Title_description
{
    static $connection='smart_real_estate';
    static $table='unit_categories';
    static $title="Unit Category";
    static $description="(Manage Unit Category)";
    

    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "title"=>array("label"=>"Title *"),
                "description"=>array("label"=>" Description","type"=>"textarea","style"=>"height:20px;"),
            ),
            //"conditions"=>array("account_id=?",Acl_user::account_id()),
            "form"=>static::form_attrs(),
            "form_actions"=>static::form_actions(),
            "grid_actions"=>static::grid_actions()
           
        );
    }
    
}