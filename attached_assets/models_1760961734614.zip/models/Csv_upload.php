<?php
class Csv_upload extends pPort_model
{

    static $table = 'csv_uploads';
    static $name = 'CSV Upload';
    static $connection = 'smart_real_estate';

    static $before_save = ['push_action', 'add_agent_supervisor'];
    static $before_create = ["add_csv_upload_token"];
    static $after_create = [
        'upload_csv_file'
    ];

    public function add_agent_supervisor()
    {
        $session_user = Session::user();
        if ($session_user->role->alias == "agent") {
            $this->agent_id = $session_user->id;
            $this->supervisor_id = $session_user->supervisor_id;
        }
    }

    public function push_action()
    {
        $this->status = $this->action == "purge" ? "purged" : $this->action . "ed";
        if ($this->action <> "upload") {


            $action = "before_csv_" . $this->action;
            $entity = $this->entity;
            $entity::$csv_upload_token = $this->csv_upload_token;
            $entity::delete_all(['conditions' => ['csv_upload_token=?', $this->csv_upload_token]]);

            if (isset($entity::$$action)) {
                foreach ($entity::$$action as $entity_action) {
                    $entity::$entity_action();
                }
            }
        }
    }

    public function add_csv_upload_token()
    {
        $this->csv_upload_token = Session::user("id") . "_" . mt_rand();
    }

    public function upload_csv_file()
    {
        $entity = $this->entity;
        $entity::$csv_upload_token = $this->csv_upload_token;
        $entity::import_csv_data($this->csv_file);
    }

    public static function config($vars = [])
    {
        $entity = arr('entity', $vars, 'Lead_bulk');

        return array(
            "fields" => array(
                "entity" => ['label' => 'Data Entity', 'params' => ['Lead_bulk' => 'Leads', 'Lead_meeting_bulk' => 'Site Visits']],
                "title" => array("label" => "Unique Title", "readonly" => true, "value" => Session::user("first_name") . " " . date("Y-m-d") . " Lead Upload "),
                "csv_file" => array("label" => "File", "type" => "file", "required" => true),


                "description" => array("label" => "Additional Note for this upload", "required" => true),
                "action" => array("label" => "Action", "value" => "upload", "type" => "hidden", "readonly" => true),
                //"entity"=>array("label"=>"Entity","required"=>true,"type"=>"hidden","value"=>$entity),
                //"status"=>array("label"=>"Status","type"=>"hidden","readonly"=>true)
            ),
            "grid_fields" => array(
                "id" => ['label' => 'ID', "disabled" => true],
                "created_at" => ['label' => 'Date', "disabled" => true],
                "entity" => ['label' => 'Data Entity', 'params' => ['Lead_bulk' => 'Leads', 'Lead_meeting_bulk' => 'Site Visits']],
                "title" => array("label" => "Unique Title", "readonly" => true, "value" => Session::user("first_name") . " " . date("Y-m-d") . " Lead Upload "),
                "csv_file" => array("label" => "File", "type" => "file", "required" => true),
                "csv_upload_token" => ['label' => 'Token', "disabled" => true],

                "entries_count" => array("label" => "Entries Count", "value" => function ($result) {
                    $entity = $result->entity;
                    return $entity::count(['conditions' => ['csv_upload_token=?', $result->csv_upload_token]]);
                }, "required" => true),

                "description" => array("label" => "Additional Note for this upload", "required" => true),
                "action" => array("label" => "Action", "value" => "upload", "type" => "hidden", "readonly" => true),
                //"entity"=>array("label"=>"Entity","required"=>true,"type"=>"hidden","value"=>$entity),
                //"status"=>array("label"=>"Status","type"=>"hidden","readonly"=>true)
            ),
            "cols" => 2,
            "conditions" => array("account_id=? AND deleted=? AND status<>'purged'", Acl_user::account_id(), 0),
            "grid_actions" => [
                "purge" => ["label" => function ($result) {
                    // return $result->status=="purged"?"Re-import":"Purge";
                    return $result->status == "purged" ? "Purged" : "Purge";
                }, "href" => function ($result) {
                    // return $result->status=="purged"?Url::form_panel("Csv_upload/{@id}/config/reupload"):Url::form_panel("Csv_upload/{@id}/config/purge");
                    return $result->status == "purged" ? "javascript:alert('Data is purged');" : Url::form_panel("Csv_upload/" . $result->id . "/config/purge");
                }],
                //"reimport"=>["label"=>"Re-import","href"=>Url::form_panel("Csv_upload/{@id}/config/reimport")]
            ],
            "limit" => 3,
            "form_actions" => static::form_actions(),
            "form" => static::form_attrs([
                "window_location" => Url::grid_panel("Csv_upload")
            ]),
        );
    }



    public static function config_purge($vars = [])
    {
        $config_data = static::config($vars);
        unset($config_data['fields']['csv_file']);
        unset($config_data['fields']['entity']);
        unset($config_data['fields']['entity']);
        $config_data["fields"]["description"]['readonly'] = true;
        $config_data["fields"]["action_reason"] = array("label" => "Reason for Purge", "required" => true, "type" => "textarea");
        $config_data["fields"]["action"] = array("label" => "Action", "value" => function () {
            return "purge";
        }, "type" => "text", "readonly" => true);
        $config_data['form_actions'] = static::form_actions(['save']);
        return $config_data;
    }

    public static function config_reupload($vars = [])
    {
        $config_data = static::config_purge($vars);
        $config_data["fields"]["action_reason"] = array("label" => "Reason for Retry", "required" => true, "type" => "textarea");
        $config_data["fields"]["action"] = array("label" => "Action", "value" => function () {
            return "reimport";
        }, "type" => "text", "readonly" => true);
        return $config_data;
    }
};