<?php

class Originator_type extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'originator_types';
    static $title = "Originator Type";



    public static function config($vars = [])
    {
        return array(
            "conditions" => ["account_id=? AND deleted=0", Acl_user::account_id()],
            "fields" => array(
                "title" => array("label" => "Title", "required" => true),
            ),
        );
    }
}