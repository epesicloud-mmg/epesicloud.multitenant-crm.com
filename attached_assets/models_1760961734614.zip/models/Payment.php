<?php

/**
 * Handles User to Groups Many-to-many Lead_activitys
 *
 * User_group Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Payment extends pPort_model
{
    static $table = 'payments';
    static $name = "Payments";
    static $enabled_for_time_range = true;
    static $title = "Payment";
    static $description = "(Record payments)";
    static $connection = 'smart_real_estate';
    static $belongs_to = [
        "payment_method" => ["payment_method", "class_name" => "Payment_method", "foreign_key" => "payment_method_id"],
        "payment_plan" => ["payment_plan", "class_name" => "Payment_plan", "foreign_key" => "payment_plan_id"]
    ];

    static $before_save = ['add_meta_data'];


    public function add_meta_data()
    {
        if ($this->payment_plan_id) {
            $entity_object = Payment_plan::find($this->payment_plan_id);
        } elseif ($this->sale_interest_id) {
            $entity_object = Sale_interest::find($this->sale_interest_id);
            $sale = Sale::clone_from("Sale_interest", $this->sale_interest_id);
            $this->sale_id = $sale->id;
        } elseif ($this->sale_id) {
            $entity_object = Sale::find($this->sale_id);
        }
        if ($entity_object) {
            $this->enquiry_id = $entity_object->enquiry_id;
            $this->project_id = $entity_object->project_id;
            $this->unit_id = $entity_object->unit_id;
        }
    }



    public static function fields_config()
    {
        $fields = array(
            "payment_method_id" => array("label" => "Payment Method", "model" => array("Payment_method", "id", "title")),
            "amount" => array("label" => "Amount.", "required" => true),
            "payment_date" => array("label" => "Expected Payment Date", "type" => "date", "required" => true),
            "transaction_reference" => array("label" => "Transaction Reference", "placeholder" => "e.g. Cheque No, Deposit Slip No..", "required" => true),
            //"confirmation_upload" => array("label" => "Confirmation Upload", "type" => "file"),
        );
        if (isset($_GET['sale_interest_id'])) {
            $fields['sale_interest_id'] = array("label" => "Sale Reference For", "model" => array("Sale_interest", "id", ["name"]));
        }
        if (isset($_GET['sale_id'])) {
            $fields['sale_id'] = array("label" => "Sale", "model" => array("Sale", "id", ["name"]));
        }

        if (isset($_GET['sale_offer_id'])) {
            $fields['sale_offer_id'] = array("label" => "Sale Offer", "model" => array("Sale_offer", "id", ["name"]));
        }
        return $fields;
    }



    public static function config($vars = [])
    {
        $config_data = array(
            "filters" => true,
            "fields" => static::fields(),
            "grid_actions" => [],
            "form" => static::form_attrs(),
            "form_actions" => static::form_actions(),
        );

        $config_data['grid_fields'] = $config_data['fields'];
        $config_data['grid_fields']['enquiry_id'] = array(
            "label" => "Client", "required" => true,
            "model" => array("Enquiry", "id", "name", ['limit' => 20])
        );
        return $config_data;
    }
}
