<?php

class Meeting_type extends Title_description
{
    static $connection='smart_real_estate';
    static $table='meeting_types';
    static $title="Meeting Type";
   

}