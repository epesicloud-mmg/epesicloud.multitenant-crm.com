<?php

/**
 * Handles User to Groups Many-to-many Lead_activitys
 *
 * User_group Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Payment_plan extends pPort_model
{
    static $table = 'payment_plans';
    static $name = "Payment Plan";
    static $title = "Sale Payments";
    static $description = "(Record purchases made in your business)";
    static $connection = 'smart_real_estate';
    static $belongs_to = [
        "sale_offer" => ["sale_offer", "class_name" => "Sale_offer", "foreign_key" => "sale_offer_id"],
        "payment_method" => ["payment_method", "class_name" => "Payment_method", "foreign_key" => "payment_method_id"],
        "payment_item" => ["payment_item", "class_name" => "Payment_item", "foreign_key" => "payment_item_id"]
    ];

    static $has_many = [
        "payments" => ["payments", "class_name" => "Payment", "foreign_key" => "payment_plan_id"]
    ];

    static $before_save = ['add_other_data'];
    public function add_other_data()
    {
        $sale_offer = Sale_offer::find($this->sale_offer_id);
        $this->enquiry_id = $sale_offer->enquiry_id;
        $this->project_id = $sale_offer->project_id;
        $this->unit_id = $sale_offer->unit_id;
    }

    public static function ajaxfy_update_enquiry_id()
    {
        foreach (Payment_plan::all(["conditions" => ['enquiry_id IS NULL']]) as $payment_plan) {
            if ($sale_offer = Sale_offer::find($payment_plan->sale_offer_id)) {
                $payment_plan->enquiry_id = $sale_offer->enquiry_id;
                $payment_plan->save();
            }
        }
    }



    public static function config($vars = [])
    {

        return array(
            "filters" => true,
            "fields" => array(
                "payment_item_id" => array("label" => "Payment Item", "required" => true, "model" => array("Payment_item", "id", "title")),
                "amount" => array("label" => "Amount.", "format" => "currency", "required" => true),
                "due_date" => array("label" => "Due Date", "format" => "date", "type" => "date", "required" => true),
                //"payment_method_id"=>array("label"=>"Payment Method","required"=>true,"model"=>array("Payment_method","id","title")),
            ),
            'order' => 'id DESC',
            "limit" => 300,
            "grid_actions" => static::grid_actions(),
            "form" => static::form_attrs(),
            "form_actions" => static::form_actions(),
        );
    }



    public static function config_collect($vars = [])
    {
        $config_data = static::config($vars);
        $config_data['fields']['sale_offer_id'] = array("label" => "Sale Offer No.", "required" => true, "model" => array("Sale_offer", "id", "id"));
        $config_data['fields']['enquiry_id'] = array("label" => "Client", "required" => true, "model" => array("Enquiry", "id", "name", ['limit' => 1]));
        $config_data['fields']['amount_paid'] = array("label" => "Amount Paid", "format" => "currency", "value" => function ($result) {
            return Payment::sum(['sum' => 'amount', 'conditions' => ['payment_plan_id=?', $result->id]]);
        });
        $config_data['fields']['balance'] = array("label" => "Balance", "value" => function ($result) {
            $balance = $result->amount - Payment::sum(['sum' => 'amount', 'conditions' => ['payment_plan_id=?', $result->id]]);
            return to_currency($balance);
        });

        $config_data['row_conditional'] = function ($result) {
            if ($result->balance > 0) {
                return true;
            }
            return false;
        };
        $config_data['grid_actions'] = [
            'collect_payment' => [
                'label' => 'Collect Payment',
                'href' => Url::batch_panel("Payment_plan/payments/{@id}")
            ]
        ];
        return $config_data;
    }

    public function get_balance()
    {
        return $this->amount - Payment::sum(['sum' => 'amount', 'conditions' => ['payment_plan_id=?', $this->id]]);
    }
}
