<?php
class Agent extends Acl_user
{
    static $name = "Agent";
    static $overall_percentage_average = 0;
    static $overall_performance_score = 0;
    static $best_agent_score_card = 0;
    static $least_agent_score_card = 0;
    static $title = "Agent";
    static $conditionals = [];

    static $has_many = [
        'enquiries' => [
            'enquiries',
            'class_name' => 'Enquiry',
            'foreign_key' => 'agent_id'
        ],
        'sale_interests' => [
            'sale_interests',
            'class_name' => 'Sale_interest',
            'foreign_key' => 'agent_id',
            "title" => "Reservations"
        ],
        'sale_offers' => [
            'sale_offers',
            'class_name' => 'Sale_offer',
            'foreign_key' => 'agent_id',
            "title" => "Sale Offers"
        ],
        'sales' => [
            'sales',
            'class_name' => 'Sale',
            'foreign_key' => 'agent_id',
            "title" => "Sales"
        ],
        'commisions' => [
            'sales',
            'class_name' => 'Commision',
            'foreign_key' => 'agent_id',
            "title" => "Commisions"
        ],
        'payments' => [
            'sales',
            'class_name' => 'Payment',
            'foreign_key' => 'agent_id',
            "title" => "Payments"
        ],

        'mail_boxes' => [
            'mail_boxes',
            'class_name' => 'Mail_box',
            'foreign_key' => 'user_id',
            "title" => "Mail Boxes"
        ]
    ];



    static $child_before_save = [
        'check_leads_before_delete'
    ];

    public static function global_conditions()
    {
        return [
            "role_check" => ["role_id", "=", Role::alias_id("agent")]
        ];
    }

    public static function ajaxfy_role_id()
    {
        vd(Role::alias_id("agent"));
    }

    public static function stats()
    {
       $agent=Agent::find(Session::user('id'));
       return [
             'leads_count'=>Lead::count(['conditions'=>['agent_id=?',$agent->id]]),             
             'meetings_count'=>Lead_meeting::count(['conditions'=>['agent_id=?',$agent->id]]),
             'followups_count'=>Followup::count(['conditions'=>['agent_id=?',$agent->id]]),
             'deal_amount'=>Lead::sum(['sum'=>'deal_amount','conditions'=>['agent_id=?',$agent->id]]),
             'calls_count'=>Call::count(['conditions'=>['agent_id=?',$agent->id]]),

       ];
    }

    public static function personalizations()
    {
       $agent=Agent::find(Session::user('id'));
       return Followup::all(['limit'=>6,'conditions'=>['agent_id=?',$agent->id]]);
    }

    public static function recent_leads()
    {
       $agent=Agent::find(Session::user('id'));
       return Lead::all(['limit'=>6,'conditions'=>['agent_id=?',$agent->id]]);
    }

    public static function recent_followups()
    {
       $agent=Agent::find(Session::user('id'));
       return Followup::all(['limit'=>6,'conditions'=>['agent_id=?',$agent->id]]);
    }

    
    public static function recent_meetings()
    {
       $agent=Agent::find(Session::user('id'));
       return Lead_meeting::all(['limit'=>6,'conditions'=>['agent_id=?',$agent->id]]);
    }

    


    public static function has_many_relations($parent_id = NULL)
    {
        $parent_id = isset($_REQUEST['filter_belongs_to']['Agent']) ? $_REQUEST['filter_belongs_to']['Agent'] : $parent_id;
        $agent_sql = " agent_id=" . $parent_id . " AND ";
        return [
            'site_visits' => [
                'class_name' => 'Lead_meeting',
                'foreign_key' => 'agent_id',
                'conditions' => [$agent_sql . ' meeting_type_id=' . Meeting_type::alias_id("site_visit")],
                "title" => "Site Visits"
            ],
            'calls' => [
                'class_name' => 'Followup',
                'foreign_key' => 'agent_id',
                'conditions' => [$agent_sql . '  followup_type_id=' . Lead_activity_type::alias_id("call")],
                "title" => "Calls"
            ],
            'reminders' => [
                'class_name' => 'Followup',
                'foreign_key' => 'agent_id',
                'conditions' => [$agent_sql . ' followup_type_id=' . Lead_activity_type::alias_id("reminder")],
                "title" => "Reminders"
            ],
            'sms' => [
                'class_name' => 'Followup',
                'foreign_key' => 'agent_id',
                'conditions' => [$agent_sql . ' followup_type_id=' . Lead_activity_type::alias_id("sms")],
                "title" => "Sms"
            ]
        ];
    }



    public function check_leads_before_delete()
    {
        if ($this->deleted) {
            $enquiries_exist = Enquiry::exists(['conditions' => ['agent_id=' . $this->id]]);
            if ($enquiries_exist) {
                json_render(['info' => 'error', 'message' => 'Could not delete. The account has some existing leads.']);
            }
        }
    }





    public function get_supervisor()
    {
        return Supervisor::find($this->created_by);
    }

    public static function role_alias()
    {
        return isset($_REQUEST['supervisor_performance']) ? "supervisor" : "agent";
    }

    public function get_sales_count()
    {

        if (isset($_REQUEST['report_start_date'])) {
            $sales_count = Sale::count(['conditions' => [static::role_alias() . '_id=? AND sale_offer_date BETWEEN 
            "' . $_REQUEST['report_start_date'] . '" AND "' . $_REQUEST['report_end_date'] . '"', $this->id]]);
        } else {
            $sales_count = Sale::count(['conditions' => [static::role_alias() . '_id=?', $this->id]]);
        }
        return $sales_count;
    }


    public function get_sale_interests_count()
    {
        if (isset($_REQUEST['report_start_date'])) {

            $reservations_count = Sale_interest::count(['conditions' => [static::role_alias() . '_id=? AND sale_interest_date BETWEEN 
            "' . $_REQUEST['report_start_date'] . '" AND "' . $_REQUEST['report_end_date'] . '"', $this->id]]);
        } else {
            $reservations_count = Sale_interest::count(['conditions' => [static::role_alias() . '_id=?', $this->id]]);
        }
        return $reservations_count;
    }

    public function get_sale_interests_amount()
    {
        if (isset($_REQUEST['report_start_date'])) {

            $reservations_count = Sale_interest::sum(['sum' => 'sale_price', 'conditions' => [static::role_alias() . '_id=? AND sale_interest_date BETWEEN 
            "' . $_REQUEST['report_start_date'] . '" AND "' . $_REQUEST['report_end_date'] . '"', $this->id]]);
        } else {
            $reservations_count = Sale_interest::sum(['sum' => 'sale_price', 'conditions' => [static::role_alias() . '_id=?', $this->id]]);
        }
        return $reservations_count;
    }

    public function get_sale_offer_amount()
    {
        if (isset($_REQUEST['report_start_date'])) {

            $reservations_count = Sale_offer::sum(['sum' => 'sale_price', 'conditions' => [static::role_alias() . '_id=? AND sale_offer_date BETWEEN 
            "' . $_REQUEST['report_start_date'] . '" AND "' . $_REQUEST['report_end_date'] . '"', $this->id]]);
        } else {
            $reservations_count = Sale_offer::sum(['sum' => 'sale_price', 'conditions' => [static::role_alias() . '_id=?', $this->id]]);
        }
        return $reservations_count;
    }

    public function get_sale_amount()
    {
        if (isset($_REQUEST['report_start_date'])) {

            $reservations_count = Sale::sum(['sum' => 'sale_price', 'conditions' => [static::role_alias() . '_id=? AND sale_date BETWEEN 
            "' . $_REQUEST['report_start_date'] . '" AND "' . $_REQUEST['report_end_date'] . '"', $this->id]]);
        } else {
            $reservations_count = Sale::sum(['sum' => 'sale_price', 'conditions' => [static::role_alias() . '_id=?', $this->id]]);
        }
        return $reservations_count;
    }


    public function get_estimate_deal_amounts()
    {
        if (isset($_REQUEST['report_start_date'])) {

            $estimate_deal_amounts = Enquiry::sum(['sum' => 'deal_amount', 'conditions' => [static::role_alias() . '_id=? AND enquiry_date BETWEEN 
            "' . $_REQUEST['report_start_date'] . '" AND "' . $_REQUEST['report_end_date'] . '"', $this->id]]);
        } else {
            $estimate_deal_amounts = Enquiry::sum(['sum' => 'deal_amount', 'conditions' => [static::role_alias() . '_id=?', $this->id]]);
        }
        return $estimate_deal_amounts;
    }



    public function get_sale_offers_count()
    {
        if (isset($_REQUEST['report_start_date'])) {
            $reservations_count = Sale_offer::count(['conditions' => [static::role_alias() . '_id=? AND sale_offer_date BETWEEN 
            "' . $_REQUEST['report_start_date'] . '" AND "' . $_REQUEST['report_end_date'] . '"', $this->id]]);
        } else {
            $reservations_count = Sale_offer::count(['conditions' => [static::role_alias() . '_id=?', $this->id]]);
        }

        return $reservations_count;
    }

    public function get_leads_count()
    {
        $reservations_count = Enquiry::count(['conditions' => [static::role_alias() . '_id=? AND ' . Enquiry::date_filter_sql("AND") . ' 
              account_id=?', $this->id, Acl_user::account_id()]]);
        return $reservations_count;
    }

    public function get_emails_count()
    {
        $start_date=php_request_data('report_start_date',the_past(1,'year'));
        $end_date=php_request_data('report_end_date',date('Y-m-d'));
        $mail_box = Email_message::find_by_sql("SELECT COUNT(*) AS entity_count FROM " . Email_message::t() . " 
        WHERE ".static::role_alias() . "_id=" . $this->id . " AND account_id=" . Acl_user::account_id().' AND email_message_date>="'.$start_date.'" AND email_message_date<="'.$end_date.'"');
        return $mail_box[0]->entity_count;
    }



    public function get_whatsapp_count()
    {
        $start_date=php_request_data('report_start_date',the_past(1,'year'));
        $end_date=php_request_data('report_end_date',date('Y-m-d'));

        $reservations_count = Whatsapp_message::count(['conditions' => 
        [static::role_alias() . '_id=? AND account_id=? AND whatsapp_message_date>="'.$start_date.'" AND whatsapp_message_date<="'.$end_date.'"', $this->id, Acl_user::account_id()]]);

        return $reservations_count;
    }

    public function get_lead_activity_count($lead_activity_type = null)
    {
        $agent_id = $this->id;
        $id = Lead_activity_type::alias_id($lead_activity_type);
        $filter_sql = "";
        $report_date_sql = "";
        if ($id) {
            $filter_sql = " AND followup_type_id=" . Lead_activity_type::alias_id($lead_activity_type);
        }
        if (isset($_REQUEST['report_start_date'])) {
            $report_date_sql = " AND " . Followup::date_filter_sql();
        }
        //echo("SELECT * FROM ".Lead_activity::t()." WHERE agent_id=".$agent_id." ".$filter_sql." ".$report_date_sql);
        //Lead_activity::find_by_sql("SELECT * FROM ".Lead_activity::t()." WHERE agent_id=".$agent_id." ".$filter_sql." ".$report_date_sql);
        if ($lead_activity_type == "site_visit_checkout") {
            if (Meeting_type::alias_id("site_visit")) {
                $report_date_sql = " AND " . Lead_meeting::date_filter_sql();
                $filter_sql = " AND meeting_type_id=" . Meeting_type::alias_id("site_visit") . " AND is_checked_out=1 ";

                return Lead_meeting::count([
                    "conditions" => [
                        "account_id=? AND " . static::role_alias() . "_id=? 
                        " . $filter_sql . $report_date_sql, Session::user('account_id'), $agent_id
                    ]
                ]);
            }
            return 0;
        } else {
            return Lead_activity::count([
                "conditions" => [
                    "account_id=? AND " . static::role_alias() . "_id=? 
                    " . $filter_sql . $report_date_sql, Session::user('account_id'), $agent_id
                ]
            ]);
        }
    }

    public function get_agents_count()
    {
        $reservations_count = Agent::count(['conditions' => [static::role_alias() . '_id=?', $this->id]]);

        return $reservations_count;
    }



    public function get_pending_followup_count()
    {

        $sql_condition = "";
        if (static::role_alias() == "supervisor") {
            $sql_condition = " AND enquiries.supervisor_id=" . $this->id . " ";
        } else {
            $sql_condition = " AND enquiries.agent_id=" . $this->id . " ";
        }





        if (isset($_REQUEST['report_start_date'])) {
            $date_condition = ' AND enquiry_date BETWEEN "' . $_REQUEST['report_start_date'] . '" AND "' . $_REQUEST['report_end_date'] . '"';
        } else {
            $date_condition = "";
        }
        $sql = "SELECT COUNT(*) AS pending_count
        FROM enquiries WHERE is_qualified=1 
         " . $sql_condition . $date_condition . " AND enquiries.account_id=" . Session::user("account_id") . " 
         AND enquiries.id NOT IN(SELECT enquiry_id FROM followups WHERE account_id=" . Acl_user::account_id() . ") ";

        $results = Enquiry::find_by_sql($sql);
        return $results[0]->pending_count;
    }

    public function get_pending_site_visit_count()
    {

        $sql_condition = "";
        if (static::role_alias() == "supervisor") {
            $sql_condition = " AND enquiries.supervisor_id=" . $this->id . " ";
        } else {
            $sql_condition = " AND enquiries.agent_id=" . $this->id . " ";
        }

        if (isset($_REQUEST['report_start_date'])) {
            $date_condition = ' AND enquiry_date BETWEEN "' . $_REQUEST['report_start_date'] . '" AND "' . $_REQUEST['report_end_date'] . '"';
        } else {
            $date_condition = "";
        }
        $sql = "SELECT COUNT(*) AS pending_count
        FROM enquiries WHERE is_qualified=1 
         " . $sql_condition . $date_condition . " AND enquiries.account_id=" . Session::user("account_id") . " 
         AND enquiries.id NOT IN(SELECT enquiry_id FROM followups WHERE account_id=" . Acl_user::account_id() . ") ";

        $results = Enquiry::find_by_sql($sql);
        return $results[0]->pending_count;
    }

    public function get_score_card()
    {
        $total_score = 0;
        $score_items['agent_id'] = $this->id;

        $score_items['reservations'] = $this->get_sale_interests_count();
        $score_items['reservation_amounts'] = $this->get_sale_interests_amount();
        $score_items['sale_offer_amounts'] = $this->get_sale_offer_amount();
        $score_items['sale_amounts'] = $this->get_sale_amount();

        $score_items['sale_offers'] = $this->get_sale_offers_count();
        $score_items['sales'] = $this->get_sales_count();
        $score_items['leads'] = $this->get_leads_count();
        $score_items['whatsapp'] = $this->get_whatsapp_count();
        $score_items['lead_activities'] = $this->get_lead_activity_count();
        $score_items['pending_followup_count'] = $this->get_pending_followup_count();
        $score_items['followup_count'] = $score_items['leads'] - $score_items['pending_followup_count'];
        if (Session::user("account_id") == 2) {
            $score_items['emails'] = $this->get_emails_count();
        }


        if ($score_items['leads']) {
            $score_items['conversion_rate'] = to_currency(($score_items['reservations'] / $score_items['leads']) * 100);
        } else {
            $score_items['conversion_rate'] = 0;
        }




        if (static::role_alias() == "supervisor") {
            $score_items['agents'] = $this->get_agents_count();
        }
        $total_score += $score_items['reservations'] * 5;
        foreach (['call', 'sms', 'site_visit_checkout', 'meeting_checkout', 'meeting_scheduling', 'site_visit_scheduling', 'site_visit_checkin', 'meeting_checkin'] as $lead_activity_type) {
            $score_items[$lead_activity_type] = $this->get_lead_activity_count($lead_activity_type);
            if ($lead_activity_type == "site_visit_checkout") {
                $total_score += $score_items[$lead_activity_type] * 4;
            } elseif ($lead_activity_type == "site_visit_scheduling") {
                $total_score += $score_items[$lead_activity_type] * 3;
            } else {
                if ($lead_activity_type == "reservation_amounts") {
                } else {
                    $total_score += $score_items[$lead_activity_type] * 1;
                }
            }
        }

        $score_items['score'] = $total_score;
        $score_items['agent_id'] = $this->id;
        $score_items['supervisor_id'] = $this->supervisor_id;
        $score_items['supervisor_name'] = $this->supervisor->first_name . " " . $this->supervisor->last_name;
        $score_items['agent_name'] = $this->first_name . " " . $this->last_name;
        return $score_items;
    }

    public static function overall_team_performance()
    {
        $total_score = 0;
        $agents_count = 0;
        $role_alias = static::role_alias();

        foreach (static::all(['conditions' => ['account_id=? AND role_id=' . Role::alias_id($role_alias), Acl_user::account_id()]]) as $agent) {
            $agents_score_cards[$agent->id] = $agent->score_card;
            $total_score += $agents_score_cards[$agent->id]['score'];
            $agents_count++;
        }

        $ordered_results = sort_array_by_key($agents_score_cards, "score", SORT_DESC);
        $overall_score_percentage = 0;
        foreach ($ordered_results as $score_card_key => $agent_score_card) {
            if ($total_score) {
                $ordered_results[$score_card_key]['score_percentage'] = number_format($ordered_results[$score_card_key]['score'] / $total_score * 100, 2);
            } else {
                $ordered_results[$score_card_key]['score_percentage'] = 0;
            }
            $overall_score_percentage += $ordered_results[$score_card_key]['score_percentage'];
        }

        static::$overall_performance_score = $total_score;
        static::$overall_percentage_average = $overall_score_percentage / $agents_count;
        static::$best_agent_score_card = $ordered_results[0];
        static::$least_agent_score_card = end($ordered_results);
        $team_performance = ['total_score' => $total_score, 'agents_score_cards' => $ordered_results];

        return $team_performance;
    }




    public static function overall_ratings()
    {
        return $ratings = [
            '20' => ['score' => 20, 'rating' => 'poor', 'advisory' => 'Poor perfromance from your team'],
            '100' => ['score' => 100, 'rating' => 'average', 'advisory' => 'Average performance from your team'],
        ];
    }

    public static function team_ratings()
    {
        return $ratings = [
            '20' => ['score' => 20, 'rating' => 'poor', 'advisory' => 'Poor perfromance from your team'],
            '100' => ['score' => 100, 'rating' => 'average', 'advisory' => 'Average performance from your team'],
        ];
    }

    public static function individual_ratings()
    {
        return $ratings = [
            '20' => ['score' => 25, 'rating' => 'Poor', 'advisory' => 'Poor perfromance from your team'],
            '50' => ['score' => 50, 'rating' => 'Average', 'advisory' => 'Average performance from your team'],
            '75' => ['score' => 75, 'rating' => 'Good', 'advisory' => 'Good performance from your team'],
            '100' => ['score' => 100, 'rating' => 'Excellent', 'advisory' => 'Excellent performance from your team'],
        ];
    }



    public static function overall_rating($score = NULL)
    {
        $ratings = static::overall_ratings();
        $score = $score ?: static::$overall_percentage_average;
        foreach ($ratings as $rating) {
            if ($score < $rating['score']) {
                break;
            }
        }
        return $rating;
    }

    public static function individual_rating($score)
    {
        $ratings = static::individual_ratings();

        foreach ($ratings as $rating) {
            if ($rating['score'] < $score) {
                break;
            }
        }
        return $rating;
    }


    public static function config_score_card_week($vars = [])
    {
        static::$title = "Least Performing Last Week";
        return static::config_score_card_all_time($vars);
    }

    public static function config_score_card_all_time($vars = [])
    {

        $score_order = arr("score_order", $vars, "least");
        static::$title = "Least Performing All Time";

        $agents_score_cards = [];
        $team_performance = static::overall_team_performance();

        $results = $team_performance['agents_score_cards'];
        $total_score = $team_performance['total_score'];

        $config = array(
            "filter_date" => "created_at",
            "filter_entity" => NULL,
            "results" => $results,
            "fields" => array(
                "agent_name" => array("label" => "Agent/Supervisor"),
                "score_percentage" => array("label" => "Score", "value" => function ($result) {
                    return $result->score_percentage;
                }),
                "leads" => array("label" => "Leads"),
                //"lead_activities" => array("label" => "Interactions Count"),
                "site_visit_checkout" => array("label" => "SiteVisits", "value" => function ($result) {
                    return $result->site_visit_checkout;
                }),
                "recent_interactions"=>array("label"=>"Activities","value"=>function($result){
                  $interactions=Followup::all(['order'=>'created_at DESC','conditions'=>['agent_id=?',$result->agent_id]]);
                  $li=[];
                  $count=1;
                  foreach($interactions as $interaction)
                  {
                    $hidden_class=$count>1?'hidden-interactions':'';
                    $li[]="<li class='".$hidden_class."'><b>".$interaction->followup_type->title."</b><br/>".$interaction->enquiry->name."<br/>".date("Y-m-d H:i",strtotime($interaction->created_at))."</li>";
                    $count++; 
                  }
                  return "<style type='text/css'>.hidden-interactions{display:none;}</style><ul>".implode("",$li)."</ul><a href='javascript:;' onclick=\"jQuery('.hidden-interactions').slideToggle();\">Toggle View</a>";

                }),
                //"sale_interests" => array("label" => "Sales Count"),
                "sale_interest_amounts" => array("label" => "Sales Total"),
                "conversion_rate" => array("label" => "Conversion Rate (%)"),


                //"call" => array("label" => "Calls"),
                //"sms" => array("label" => "Sms"),
                
                /**"meeting_scheduling"=>array("label"=>"Scheduled Meetings","value"=>function($result){
                    return $result->meeting_scheduling;
                    
                }),**/
                //"meeting_checkout" => array("label" => "Meetings"),
                /**"site_visit_scheduling"=>array("label"=>"Scheduled SiteVisit","value"=>function($result){
                    return $result->site_visit_scheduling;
                    
                }),**/
                
                /**"whatsapp" => array("label" => "Whatsapp"),
                "emails" => array("label" => "Emails"),
                "followup_count" => array("label" => "Followed Up Leads"),
                "pending_followup_count" => array("label" => "Pending Followup"),
                

                "estimate_deal_amounts" => array("label" => "Estimated Deal Values "),**/
               
                //"sale_offers" => array("label" => "LOFs"),
                //"sale_offer_amounts" => array("label" => "LOF Totals "),

                //"sales" => array("label" => "Sales"),
                //"sale_amounts" => array("label" => "Sale Totals "),
                
                "site_visit_scheduling" => array("label" => "Planned Site Visits", "type" => "hidden"),
                //"site_visit_checkout"=>array("label"=>"Actual Site Visits","type"=>"hidden"),
                "site_visit_checkin" => array("label" => "Actual Site Visits", "type" => "hidden"),
                "meeting_checkin" => array("label" => "Actual Site Visits", "type" => "hidden"),
                "agent_id" => array("label" => "Agent", "type" => "hidden"),

            ),
            "grid" => ["data-page-length" => 10],
            "grid_actions" => [
                'view_activities' => [
                    'text' => 'Detailed Lead Activities',
                    'href' => function ($result) {

                        return Url::ajaxfy('Agent/tabs?parent_filters=project,lead_source&relations=enquiries,site_visits,calls,sms,reminders,sale_interests,sale_offers,sales,commisions,payments&id=' . $result->agent_id);
                    }
                ]
            ],
            //"grid_actions"=>[],
            //"conditions"=>["account_id=?",Acl_user::account_id()],
            'form_actions' => [],
            "form" => [],

        );



        if (static::role_alias() == "supervisor") {
            $config['fields']["agents"] = array("label" => "Agents");
            $config["grid_actions"] = [];
        }
        if (Acl_user::account_id() == 71) {
            $config['fields']['sale_offers']['type'] = "hidden";
            $config['fields']['sales']['type'] = "hidden";
        }
        return $config;
    }


    public static function config_summary_report($vars = [])
    {
        static::$title = "Agent Summary Report";
        return array(
            //"before_grid"=>Followup::grid(['config'=>'account_executives_summary']),
            "fields" => array(
                "name" => array("label" => "Name", "value" => function ($result) {
                    return $result->first_name . " " . $result->last_name;
                }),
                "leads_assigned_count" => array("label" => "Leads Assigned", "value" => function ($result) {
                    return Enquiry::count(['conditions' => ['agent_id=? AND account_id=' . Acl_user::account_id(), $result->id]]);
                }),
                "leads_qualified_count" => array("label" => "Leads Qualified", "value" => function ($result) {
                    return Enquiry::count(['conditions' => ['agent_id=? AND is_qualified=1', $result->id]]);
                }),
                "lead_activities_count" => array("label" => "Lead_activitys Count", "value" => function ($result) {
                    return Lead_activity::count(['conditions' => ['agent_id=?', $result->id]]);
                }),
                "calls_count" => array("label" => "Calls Count", "value" => function ($result) {
                    return Lead_activity::count(['conditions' => ['agent_id=? AND 
                    followup_type_id=?', $result->id, Lead_activity_type::alias_id("call")]]);
                }),
                "sms_count" => array("label" => "Sms Count", "value" => function ($result) {
                    return Lead_activity::count(['conditions' => ['agent_id=? AND 
                    followup_type_id=?', $result->id, Lead_activity_type::alias_id("sms")]]);
                }),
                "visit_count" => array("label" => "Visit Count", "value" => function ($result) {
                    return Lead_activity::count(['conditions' => ['agent_id=? AND 
                    followup_type_id=?', $result->id, Lead_activity_type::alias_id("site_visit_checkout")]]);
                }),
                "planned_visit_count" => array("label" => "Planned Visit Count", "value" => function ($result) {
                    return Lead_activity::count(['conditions' => ['agent_id=? AND 
                    followup_type_id=?', $result->id, Lead_activity_type::alias_id("site_visit_scheduling")]]);
                }),
                "reminder_count" => array("label" => "Reminder Count", "value" => function ($result) {
                    return Lead_activity::count(['conditions' => ['agent_id=? AND 
                    followup_type_id=?', $result->id, Lead_activity_type::alias_id("reminder")]]);
                }),
                "last_lead_activity_type" => array("label" => "Last Followup", "value" => function ($result) {
                    $followup = Followup::last(['conditions' => ['agent_id=?', $result->id]]);
                    if ($followup) {
                        return @$followup->followup_type->title;
                    } else {
                        return "No Lead_activity";
                    }
                }),
                "last_lead_activity_date" => array("label" => "Last Lead_activity Date", "value" => function ($result) {
                    $followup = Followup::last(['conditions' => ['agent_id=?', $result->id]]);
                    if ($followup) {
                        return $followup->followup_date;
                    } else {
                        return "No Lead_activity";
                    }
                }),

            ),
            "grid_actions" => [],
            'form_actions' => [],
            "form" => [],

        );
    }

    public static function fields_config()
    {



        if (Session::has_user()) {
            if (Session::user()->role->alias == 'supervisor') {
                $user_label = array("label" => "Assigned Supervisor", "disable_reload_select" => true, "model" => [
                    "Acl_user", 'id',
                    ['first_name', 'last_name'], ['prepend' => ["" => "-Select Supervisor-"], 'conditions' => [
                        'account_id=? AND role_id=?',
                        Acl_user::account_id(), Role::alias_id("supervisor")
                    ]]
                ]);
                $conditions = ["created_by=?", Session::user('id')];
            } else {
                $user_label = array("label" => "Assigned Supervisor", "disable_reload_select" => true,  "model" => ["Acl_user", 'id', [
                    'first_name',
                    'last_name'
                ], ['prepend' => ["" => "-Select Supervisor-"], 'conditions' => [
                    'account_id=? AND role_id=?',
                    Acl_user::account_id(), Role::alias_id("supervisor")
                ]]]);

                $conditions = ["role_id=?", Role::alias_id('agent')];
            }
        }



        $field_data = array(
            'supervisor_id' => $user_label,
            "role_id" => array("label" => "Role", 'model' => array(
                'Role', 'id', 'title',
                array('conditions' => array('id=? AND account_id=?', Role::alias_id('agent'), Session::user("account_id")))
            )),
            "first_name" => array("label" => "First Name"),
            "last_name" => array("label" => "Last Name"),
            "email" => array("label" => "Email"),
            "phone" => array("label" => "Phone"),
            "password" => array("label" => "Password", "is_private" => true, "type" => "password"),
            "confirm_password" => array("label" => "Confirm Password", "is_private" => true, "type" => "password"),
            "mail_password" => array("label" => "IMAP Password (Optional)", "is_private" => true, "type" => "password"),
            "mail_server" => array("label" => "IMAP Server (Optional)", "is_private" => true),
            //"is_invite" => array("label" => "Is Invite", "type" => "hidden", 'value' => 1),
            "leads_assigned" => array("disabled" => true, "label" => "Leads Assigned", "value" => function ($result) {
                return $result->leads_assigned_count;
            }),
            "leads_qualified" => array("disabled" => true, "label" => "Leads Qualified", "value" => function ($result) {
                return $result->leads_qualified_count;
            }),
            "deleted" => ["label" => "Status", "params" => ["0" => "Active", "1" => "Inactive"]]
        );


        return $field_data;
    }


    public static function config($vars = [])
    {

        return array(
            "fields" => static::fields(),
            "grid_fields" => ["deleted", "supervisor_id", "first_name", "last_name", "email", "phone", "leads_assigned", "leads_qualified"],
            "conditions" => array("role_id=? AND account_id=?", Role::alias_id("agent"), Acl_user::account_id()),
            "form" => static::form_attrs(),
            "grid_actions" => static::grid_actions(['view']),
            "form_actions" => static::form_actions(),
        );
    }




    public static function fetch_count()
    {
        return Agent::count(['conditions' => ['role_id=?', Role::alias_id('agent')]]);
    }

    public static function config_followup_report()
    {
        return [];
    }

    public static function ajaxfy_qualify_agent_leads($agent_id)
    {
        if (Session::has_user()) {
            $qualified_count = 0;
            $agent_enquiries = Enquiry::all(['order' => 'id DESC', 'limit' => 50, 'conditions' => ['account_id=? AND is_qualified=0 AND agent_id=?', Session::user('account_id'), $agent_id]]);
            if ($agent_enquiries) {
                if (isset($agent_enquiries[0])) {
                    foreach ($agent_enquiries as $agent_enquiry) {

                        $agent_enquiry->qualify_status = "qualified";
                        $agent_enquiry->save();
                        $qualified_count++;
                    }
                }
            } else {
                $bulk_enquiries_for_agent = Enquiry_bulk::all(['conditions' => ['account_executive=?', $agent_id]]);
                if (isset($bulk_enquiries_for_agent[0])) {
                    foreach ($bulk_enquiries_for_agent as $bulk_enquiry) {
                        $enquiry = Enquiry::find($bulk_enquiry->enquiry_id);
                        $agent_user = Acl_user::last(['conditions' => ['account_id=? AND email="' . $agent_id . '"', Session::user("account_id")]]);

                        if ($enquiry && $agent_user) {
                            $enquiry->qualify_status = "qualified";
                            $enquiry->agent_id = $agent_user->id;
                            $enquiry->save();
                            $qualified_count++;
                        }
                    }
                } else {
                    $agent_user = Acl_user::last(['conditions' => ['account_id=?   AND email="' . $agent_id . '"', Session::user("account_id")]]);
                    $agent_enquiries_by_email = Enquiry::all(['order' => 'id DESC', 'limit' => 1, 'conditions' => ['account_id=? 
                    AND is_qualified=0 AND account_executive=?', Session::user('account_id'), $agent_user->email]]);
                    if (isset($agent_enquiries_by_email[0])) {
                        foreach ($agent_enquiries_by_email as $agent_enquiry) {
                            $agent_enquiry->qualify_status = "qualified";
                            $agent_enquiry->agent_id = $agent_user->id;
                            $agent_enquiry->save();
                            $qualified_count++;
                        }
                    }
                }
            }
        }
    }

    public function get_leads_assigned_count()
    {
        return  Enquiry::count(['conditions' => ['account_id=? AND agent_id=?', Acl_user::account_id(), $this->id]]);
    }

    public function get_leads_qualified_count()
    {
        return Enquiry::count(['conditions' => ['account_id=? AND agent_id=? AND is_qualified=1', Acl_user::account_id(), $this->id]]);
    }

    public static function ajaxfy_resend_password($agent_id)
    {
        if (Session::has_user()) {
            $agent = Agent::find($agent_id);

            $password = ucfirst($agent->last_name);
            $password .= "@123???";
            echo $message = "Hello " . $agent->first_name . ", Your account is active, login with your email and password : " . $password . " . You can proceed to login.";

            $phone = $agent->phone;

            Sms::send($message, $phone, "UWAZII");
            echo "<script type='text/javascript'>setTimeout(function(){ window.location='" . Url::grid_panel("Agent") . "'; }, 3000);</script>";
        }
    }

    public static function ajaxfy_update_ids()
    {
        $models_updated = [];



        $specials = [
            'Batch_enquiry_agent' => ['from_agent_id', 'to_agent_id'],
            'Batch_enquiry_agent_rollback' => ['from_agent_id', 'to_agent_id'],

        ];
        $invalids = ['Generic_migrate_model', 'Unit_group_item', 'Lead_allocation_rule', 'Lead_meeting_cancellation', 'Permission', 'Sale_document', 'Sale_offer_buyer', 'Salesify_calendar_event_type'];




        $valids = ['Followup', 'Commision_request', 'Csv_upload', 'Email_message', 'Enquiry', 'Enquiry_account_executive', 'Followup_action', 'Followup_call', 'Followup_reminder', 'Followup_scheduled_visit', 'Followup_sms', 'Followup_visit', 'Lead_bulk', 'Lead_contact', 'Lead_document', 'Lead_meeting', 'Lead_meeting_cancellation', 'Lead_meeting_bulk', 'Lead_note', 'Lead_other_interaction', 'Location_log', 'Payment', 'Prospect', 'Reminder', 'Sale_agreement', 'Sale', 'Sale_document', 'Sale_interest', 'Sale_offer', 'Sale_payment', 'Trip_booking', 'Trip_attendance', 'Trip_confirmation', 'Trip_lead', ''];
        $models = Portlet::models();


        $invalids = ['Generic_migrate_model', 'Unit_group_item', 'Lead_allocation_rule', 'Lead_meeting_cancellation', 'Permission', 'Sale_document', 'Sale_offer_buyer', 'Salesify_calendar_event_type'];
        $queries_arr = [];
        foreach ([

            //"515" => ["532", "71"],
            "513" => ["531", "2"],
            //"516" => ["533", "71"],
            //"517" => ["534", "71"],
            //"518" => ["535", "71"],
            // "519" => ["536", "71"],
            // "520" => ["537", "71"],
            //"485" => ["486", "15"],
        ] as $old_id => $new_id) {
            $models = Portlet::models();



            foreach ($models as $model) {

                if (!in_array($model, $invalids)) {
                    //var_dump($model);
                    if (class_exists($model)) {
                        $connection = Enquiry::connection();

                        $table = obj("table_name", $model, obj("table", $model, NULL));
                        if (in_array($table, $connection->tables())) {
                            if ($model::field_exists("agent_id")) {

                                if ($model::exists(['conditions' => ['agent_id=? AND account_id=?', $old_id, $new_id[1]]])) {
                                    $models_updated[] = $model;
                                    $query = "UPDATE " . $table . " SET agent_id=" . $new_id[0] . " WHERE agent_id=" . $old_id . " AND account_id=" . $new_id[1];
                                    //$model::find_by_sql($query);
                                    $queries_arr[] = $query;
                                    //vd(Generic_migrate_model::$table_name);
                                    //Generic_migrate_model::update_all(array('conditions' => ['agent_id=? AND account_id=?', $old_id, $new_id[1]], 'set' => ['agent_id' => $new_id[0]]));
                                }
                            }
                        }
                    }
                }
            }
        }
        echo  $query_update = (implode(";", $queries_arr));
    }

    public static function update_login_passwords()
    {
    }
}
