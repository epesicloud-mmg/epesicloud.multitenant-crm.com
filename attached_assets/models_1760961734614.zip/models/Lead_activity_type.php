<?php
class Lead_activity_type extends pPort_model
{

    static $table = 'followup_types';
    static $title = 'Followup Type';
    static $description = '(Manage Followup Types)';
    static $connection = 'smart_real_estate';
    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "title" => array("label" => "Type Name"),
                "description" => array("label" => "Description", "type" => "textarea"),

            ),
            "cols" => 1,
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),

            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions(),
            "form" => static::form_attrs(),
        );
    }
}
