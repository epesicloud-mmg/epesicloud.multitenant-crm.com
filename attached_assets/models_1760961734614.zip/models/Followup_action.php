<?php

/**
 * Handles User lead_activities
 *
 * User Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Followup_action extends pPort_model
{

    static $table = 'followup_actions';
    static $title = 'Followup Action';
    static $description = '(Manage Followup actions)';
    static $connection = 'smart_real_estate';
    static $belongs_to = [
        'enquiry' => ["enquiry", "foreign_key" => "enquiry_id", "class_name" => "Enquiry"],
        'account_executive' => ["account_executive", "foreign_key" => "agent_id", "class_name" => "Agent"],
        'followup' => ["followup", "foreign_key" => "followup_id", "class_name" => "Followup"]
    ];



    public static function config($vars = [])
    {

        return array(
            "fields" => array(
                "description" => array("label" => "Action Notes", "type" => "textarea"),
                "due_date" => array("label" => "Followup Date", "type" => "date", "required" => true),
                "reminder_date" => array("label" => "Reminder Date", "type" => "date", "required" => true),
            ),
            "cols" => 2,
            "conditions" => array("deleted=? AND account_id=?", 0, Acl_user::account_id()),
            "limit" => 500,
            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions(['save']),
            "form" => static::form_attrs(),
        );
    }
}
