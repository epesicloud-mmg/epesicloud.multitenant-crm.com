<?php
class Agent_last_location extends Followup
{
    static $title="Agents Locations";
    static $name="Agents Locations";
    
}