<?php

class Sale_interest extends pPort_Model
{
    static $table = 'sale_interests';
    static $title = "Sale Interests";
    static $connection = 'smart_real_estate';
    static $enabled_for_time_range = true;
    static $before_create = ["check_unit_existence_on_create"];
    static $before_save = ['add_tax_rate_id', 'add_parent_units', 'add_is_deleted_if_cancelled', 'add_supervisor_id'];
    static $after_save = ["propagate_status", "update_sale_stage_to_won","create_commision"];

    static $filter_date = "sale_interest_date";

    static $currency_fields = [
        'sale_price', 'deposit'
    ];

    /**static $entity_status_logs=[
        'Enquiry'=>[
            'entity'=>'Enquiry',
            'status'=>"interest_form_added",
            "entity_reference_key"=>'id' 
        ]
            
    ];**/

    static $belongs_to = [
        'unit' => ['unit', 'class_name' => 'Unit', 'foreign_key' => 'unit_id', 'show' => 'grid'],
        'supervisor' => ['supervisor', 'class_name' => 'Supervisor', 'foreign_key' => 'supervisor_id', 'show' => 'grid', "visualize" => true],
        'agent' => ['agent', 'class_name' => 'Agent', 'foreign_key' => 'agent_id', 'show' => 'grid', "visualize" => true],
        'lead_source' => ['lead_source', 'class_name' => 'Lead_source', 'foreign_key' => 'lead_source_id', 'show' => 'grid', "visualize" => true],
        'project' => ['project', 'class_name' => 'Project', 'foreign_key' => 'project_id', 'show' => 'grid', "visualize" => true],
        'unit_group' => ['unit_group', 'class_name' => 'Unit_group', 'foreign_key' => 'unit_group_id', 'show' => 'grid', "visualize" => true],
        'customer_type' => ['customer_type', 'class_name' => 'Customer_type', 'foreign_key' => 'customer_type_id', 'show' => 'grid', "visualize" => true],
        'lead_interest_level' => ['lead_interest_level', 'class_name' => 'Lead_interest_level', 'foreign_key' => 'lead_interest_level_id', 'show' => 'grid', "visualize" => true],
        'lead_budget' => ['lead_budget', 'class_name' => 'Lead_budget', 'foreign_key' => 'lead_budget_id', 'show' => 'grid', "visualize" => true],

        'court' => ['court', 'class_name' => 'Court', 'foreign_key' => 'court_id', 'show' => 'grid'],
        'enquiry' => ['enquiry', 'class_name' => 'Enquiry', 'foreign_key' => 'enquiry_id', 'show' => 'grid'],
        'block' => ['block', 'class_name' => 'Block', 'foreign_key' => 'block_id', 'show' => 'grid'],
        'industry' => ['industry', 'class_name' => 'Industry', 'foreign_key' => 'industry_id', 'show' => 'grid'],

        'apartment' => ['apartment', 'class_name' => 'Apartment', 'foreign_key' => 'apartment_id', 'show' => 'grid'],
        'payment_method' => [
            'payment_method', 'class_name' => "Payment_method", 'foreign_key' => 'payment_method_id'
        ]

    ];

    public function create_commision()
    {
        if($this->is_verified && !Commision::exists(['conditions'=>['sale_interest_id=?',$this->id]]))
        {
          $commision=Commision::create([
            'sale_interest_id'=>$this->id,
            'account_id'=>$this->account_id,
            'user_id'=>$this->agent_id,

            'commision_date'=>date('Y-m-d')
          ]);
          if($commision)
          {
            Commision_item::create([
                'commision_id'=>$commision->id,
                'account_id'=>$commision->account_id,

                'sale_interest_id'=>$this->id,
                'unit_id'=>$this->unit_id,
                'title'=>$this->name,
                'sale_price'=>$this->sale_price,
                'paid_amount'=>$this->deposit

            ]);
          }
        }
    }

    public function add_tax_rate_id()
    {
        if (!$this->tax_rate_id) {
            $unit = Unit::find($this->unit_id);
            $unit_group = $unit->unit_group;
            $this->tax_rate_id = $unit_group->tax_rate_id;
        }
    }

    public function update_sale_stage_to_won()
    {
        if ($this->enquiry_id) {
            $won_stage_id = Sale_stage::fetch_won_stage_id();
            if ($won_stage_id) {
                $enquiry = Enquiry::find($this->enquiry_id);
                $enquiry->sale_stage_id = $won_stage_id;
                $enquiry->save();
            }
        }
    }

    public static function ajaxfy_sale_interest_date()
    {
        // $sql="SELECT * FROM `reservations` WHERE `account_id` = 2 AND `sale_offer_id` IS NOT NULL ";
        $reservations = static::all(['conditions' => ['account_id=? AND sale_offer_id IS NOT NULL AND sale_interest_date IS NULL', 2]]);
        foreach ($reservations as $reservation) {
            $sale_offer = Sale_offer::find($reservation->sale_offer_id);
            $reservation->sale_interest_date = $sale_offer->sale_offer_date;
            $reservation->save();
        }
    }




    public static function workflow_config()
    {
        return [
            'verified' => [
                'editor_roles' => ['admin'],
                //"shared_stages"=>["cancelled"],
                //"condition"=>"is_cancelled=0",
                'pending_label' => 'Pending Review',
                //"after_approved"=>['update_unit_reservation'],
                "after_reject" => function ($workflow, $stage, $entity_data) {
                },
                "show_approved_menu" => true,
                'approved_label' => 'All Verified',

            ],
            'cancelled' => [
                'editor_roles' => ['admin'],
                'cancel_roles' => ['admin'],
                'pending_label' => 'Cancel Reservation',
                'approved_label' => 'Cancelled',
                //"after_approved"=>['update_unit_reservation'],
                "do_label" => "Cancel Reservation",
                "show_pending_menu" => false,
                "show_approved_menu" => true
            ],
        ];
    }


    public function check_unit_existence_on_create()
    {
        /**if(Reservation::exists(['conditions'=>['unit_id=? AND account_id=?
         AND is_verified=?',$this->unit_id,Acl_user::account_id(),1]]))
        {
            exit(json_encode(['info'=>'error','message'=>'Unit has already been reserved.']));
        }**/
    }



    public function add_supervisor_id()
    {
        if ($this->agent_id) {
            $agent = Agent::find($this->agent_id);
            $this->supervisor_id = $agent->supervisor_id;
        }
    }



    public function add_parent_units()
    {
        $unit = Unit::find($this->unit_id);
        if ($unit) {
            foreach (['project_id', 'unit_group_id', 'floor_id', 'block_id', 'court_id', 'apartment_id'] as $field) {
                $this->{$field} = $unit->{$field};
            }
        }
    }






    public function propagate_status()
    {
        if ($this->unit_id) {
            $unit = Unit::find($this->unit_id);
            if ($this->is_cancelled) {
                $unit->status = "available";
                $unit->enquiry_id = NULL;
                $unit->save();
            } elseif ($this->is_verified) {
                if ($unit->status <> "sold") {
                    $unit->status = "reserved";
                    $unit->enquiry_id = $this->enquiry_id;
                    $unit->save();
                }
            }
        }
    }


    public function get_payments_total()
    {
        return Payment::sum(['sum' => 'amount', 'conditions' => ['sale_interest_id=?', $this->id]]);
    }



    public function get_balances_total()
    {
        $payments_total = $this->payments_total;
        return $this->deal_amount - $payments_total;
    }


    public static function global_grid_actions()
    {
        return [
            'client_feed' => [
                "text" => 'Client Feed',
                'target' => '_blank',
                'href' => Url::component_panel("Enquiry/timeline/{@enquiry_id}"),
                //Exclude in these configs
                'excluded_configs' => []
            ]
        ];
    }


    public static function grid_actions_config()
    {
        return [
            "activity_feed" => function ($result) {
                return [
                    "label" => 'Client Feed',
                    'href' => Url::portlet("main/feed/{@enquiry_id}"),
                    'excluded_configs' => []
                ];
            },
            "make_sale" =>  function ($result) {
                if (!Sale::exists(['conditions' => ['enquiry_id=?', $result->id]])) {
                    return [
                        "label" => 'Confirm Sale',
                        'target' => '_blank',
                        'href' => Url::portlet("main/form_panel/Sale/clone/Enquiry/id/{@id}"),
                        'excluded_configs' => []
                    ];
                }
                return false;
            },
            "record_payment" =>  function ($result) {
                return [
                    "label" => 'Record Payment',
                    'href' => Url::form_panel("Payment?sale_interest_id=" . $result->id)
                ];
            },



        ];
    }


    public static function fields_config()
    {

        if (Session::user()->role->alias == "agent") {
            $agent_condition = ["role_id=? AND id=" . Session::user("id") . " AND account_id=? AND deleted=0", Role::alias_id('agent'), Acl_user::account_id()];
        } else {
            $agent_condition = ["role_id=? AND account_id=? AND deleted=0", Role::alias_id('agent'), Acl_user::account_id()];
        }

        if (static::$model_id) {
            $reservation = static::find(static::$model_id);
            $unit_field = array(
                "label" => "Unit", 'required' => true,
                'model' => array(
                    'Unit', 'id', 'title',
                    ['prepend' => ['' => '-Select Unit-'], 'conditions' => ['account_id=? AND id="' . $reservation->unit_id . '"', Acl_user::account_id()]]
                )
            );
        } else {
            $unit_field = array(
                "label" => "Unit", 'required' => true,
                'model' => array(
                    'Unit', 'id', 'title',
                    ['prepend' => ['' => '-Select Unit-'], 'conditions' => ['account_id=? AND status="available"', Acl_user::account_id()]]
                )
            );
        }

        return array(
            "name" => array("label" => "Client Name"),
            "email" => array("label" => "Client Email"),
            "phone" => array("label" => "Client Phone"),
            "company_name" => array("label" => "Company Name"),
            "customer_type_id" => array("label" => "Buyer Type", 'required' => true, 'model' => array('Customer_type', 'id', 'title')),
            //"industry_id" => array("label" => "Industry", 'required' => true, 'model' => array('Industry', 'id', 'title')),
            "interest_form_upload" => ['label' => 'Interest Form(Reservation) Upload', 'type' => 'file'],
            "postal_address" => array("label" => "Postal Address", "required" => true),
            "postal_code" => array("label" => "Postal Code", "required" => true),
            "agent_id" => array(
                "label" => "Account Exec", 'required' => true,
                'model' => array(
                    'Acl_user', 'id',
                    ['first_name', 'last_name'],
                    [
                        "conditions" => $agent_condition,
                        "prepend" => ["0" => "--Assigned Agent--"]
                    ]
                )
            ),
            "lead_source_id" => array("label" => "Lead Source", 'required' => true, 'model' => array('Lead_source', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
            "deal_amount" => array("label" => "Deal Amount"),
            "sale_interest_date" => array("label" => "Actual Reservation Date", "required" => true, "value" => date("Y-m-d"), "type" => "date"),

            "deposit_amount" => array("label" => "Deposit", "required" => true),

            "payments_total" => array("label" => "Payments Total", "required" => true),

            "balances_total" => array("label" => "Balances Total", "required" => true),

            "enquiry_id" => array("label" => "EnquiryID", "type" => "hidden"),

        );
    }


    public static function config($vars = [])
    {
        if(Session::user()->role->alias=="admin")
        {
            $actions=static::grid_actions(['view','delete']);
        }
        else
        {
            $actions=static::grid_actions();
        }
        return array(
            "filters" => 1,
            "fields" => static::fields(["name", "email", "phone", "company_name", "industry_id", "interest_form_upload", "postal_address", "postal_code", "agent_id", "lead_source_id", "deal_amount", "sale_interest_date", "deposit_amount", "enquiry_id"]),
            "grid_fields" => static::fields(["name", "email", "phone", "company_name", "agent_id",  "deal_amount", "sale_interest_date", "deposit_amount", "payments_total", "balances_total"]),
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),
            "order" => "id DESC",
            'form_actions' => static::form_actions(['save']),
            'grid_actions' => $actions,
            "form" => static::form_attrs(),
            "form_attrs" => ["window_location" => Url::grid_panel("Sale_offer")]
        );
    }




    public static function config_offer($vars)
    {


        return array(
            "row_conditional" => function ($result) {
                return true;
                if (Sale_offer::exists(['conditions' => ["reservation_id=?", $result->id]])) {
                    return false;
                }
                return true;
            },
            "fields" => array(
                "name" => array("label" => "Client Name"),
                "email" => array("label" => "Client Email"),
                "phone" => array("label" => "Client Phone"),
                "company_name" => array("label" => "Company"),
                "customer_type_id" => array("label" => "Buyer Type", 'required' => true, 'model' => array('Customer_type', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),
                "project_id" => array("label" => "Project", 'required' => true, 'model' => array('Project', 'id', 'title', ['conditions' => ['account_id=?', Acl_user::account_id()]])),

                "budget" => array("label" => "Budget", "required" => true),
                "sale_price" => array("label" => "Sale Price", "required" => true),
                "deposit" => array("label" => "Deposit", "required" => true),



            ),
            "grid_actions" => [
                'view' => ['text' => 'Add LOF', 'href' => Url::batch_panel('Sale_offer/payment_plans/clone/Reservation/id/{@id}')]
            ],
            "conditions" => array("account_id=? AND deleted=? AND is_verified=1", Acl_user::account_id(), 0),
            'form_actions' => static::form_actions(['save']),
            //'grid_actions'=>static::grid_actions(),
            "form" => static::form_attrs(),


        );
    }

    public static function config_auto_sale($vars)
    {
        $config_data = static::config_offer($vars);
        /**$config_data['grid_actions']=[
            'convert_to_sale'=>['text'=>'Record Sale','href'=>Url::form_panel('Sale_offer/c/auto_sale/clone/Reservation/id/{@id}')]
        ];**/
        $config_data['grid_actions'] = [
            'convert_to_sale' => ['text' => 'Confirm Sale', 'href' => Url::form_panel('Home_owner/c/auto_sale/clone/Reservation/id/{@id}')]
        ];
        return $config_data;
    }

    public static function config_commision($vars = [])
    {
        static::$title = "Verified Reservations";
        $config_data = static::config($vars);
        $config_data['grid_actions'] = [
            'create_lof' => [
                'href' => Url::form_panel('Commision_request/clone/Reservation/id/{@id}'),
                'label' => 'Place Commission Request',
            ]
        ];
        $config_data["conditions"] = ["account_id=? AND deleted=? AND is_verified=1 AND is_cancelled=0", Acl_user::account_id(), 0];
        return $config_data;
    }
}
