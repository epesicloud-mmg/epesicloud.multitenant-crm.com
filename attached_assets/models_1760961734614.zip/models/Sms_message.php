<?php

class Sms_message extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'whatsapp_messages';
    static $title = "Log Sms Message";
    static $description = "(Sms Message)";
    static $before_create = ["add_agent_id"];
    static $after_create = ["add_lead_activity", "update_enquiry_statuses"];


    function update_enquiry_statuses()
    {
        $lead = Enquiry::find($this->enquiry_id);
        if ($this->lead_interest_level_id) {
            $lead->lead_interest_level_id = $this->lead_interest_level_id;
        }

        if ($this->sale_stage_id) {
            $lead->sale_stage_id = $this->sale_stage_id;
        }
    }

    function add_agent_id()
    {
        if (!$this->agent_id) {
            $user = Session::user();
            $this->agent_id = $user->id;
            $this->supervisor_id = $user->supervisor_id;
        }
    }

    function add_lead_activity()
    {
        Lead_activity::create([
            'enquiry_id' => $this->enquiry_id,
            'followup_type_id' => Lead_activity_type::alias_id_or_create("sms"),
            'description' => $this->content,
            'linked_entity' => 'Sms_message',
            'linked_entity_reference' => $this->id,
            "account_id" => $this->account_id,
            'agent_id' => $this->agent_id,

            'followup_date' => $this->sms_message_date
        ]);
    }



    public static function fields_config()
    {
        $sale_stage_id = NULL;
        $lead_interest_level_id = NULL;

        if (isset($_GET['enquiry_id'])) {
            $enquiry = Enquiry::find($_GET['enquiry_id']);
            $sale_stage_id = $enquiry->sale_stage_id;
            $lead_interest_level_id =  $enquiry->lead_interest_level_id;
        }
        return array(
            "enquiry_id" => ['label' => "Select Lead", "type" => "hidden", "value" => $_REQUEST['enquiry_id']],
            "phone" => array("label" => "Phone", "required" => true),
            "content" => array("label" => "Additional Notes", "type" => "textarea", "required" => true),
            "lead_interest_level_id" => ['label' => "Interest Level",  "model" => ["Lead_interest_level", "id", "title", ["selected" => $lead_interest_level_id]]],
            "sale_stage_id" => ['label' => "Sale Stage", "model" => ["Sale_stage", "id", "title", ["selected" => $sale_stage_id]]],
            "sms_message_date" => array("label" => "Date Sent", "type" => "date", "format" => "date"),
        );
    }

    public static function config($vars = [])
    {
        $config_data = array(
            "fields" => static::fields(['enquiry_id', "sms_message_date", 'content', "lead_interest_level_id", "sale_stage_id"]),
            "grid_fields" => static::fields(),
            "form_actions" => static::form_actions(["save"])
        );
        return $config_data;
    }
}