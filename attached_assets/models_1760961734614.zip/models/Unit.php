<?php
class Unit extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'units';
    static $title = "Units";
    static $description = "(Manage Units)";
    static $before_save = array('update_enquiry_id');
    static $belongs_to = [
        'project'=>array("project","class_name"=>"Project","foreign_key"=>"project_id"),
        'unit_group' => ['unit_group', 'class_name' => 'Unit_group', 'foreign_key' => 'unit_group_id'],
        'unit_type' => ['unit_type', 'class_name' => 'Unit_type', 'foreign_key' => 'unit_type_id'],
        'floor' => ['floor', 'class_name' => 'Floor', 'foreign_key' => 'floor_id'],
        'block' => ['block', 'class_name' => 'Block', 'foreign_key' => 'block_id']
    ];



    public static function statuses()
    {
        return ["sold" => "Sold", "available" => "Available", "reserved" => "Reserved", "not_released" => "Not Released"];
    }

    public static function ajaxfy_update_enquiry()
    {
        foreach (Unit::all() as $unit) {
            $sale_offer = Sale_offer::find_by_unit_id($unit->id);
            if ($sale_offer) {
                $unit->enquiry_id = $sale_offer->enquiry_id;
                $unit->save();
            }
        }
    }

    public static function ajaxfy_update_floors()
    {
        foreach (Unit::all() as $unit) {
            $unit->floor_id = $unit->floor_id + 1;
            $unit->save();
        }
    }

    public static function ajaxfy_update_unit_groups()
    {
        $units_updated = 0;
        foreach (Unit_group::label_list() as $unit_k => $unit_group_id) {
            foreach (Unit::all(['conditions' => ['account_id=?', Acl_user::account_id()]]) as $unit) {
                if (substr($unit->title, 0, 2) == $unit_k) {
                    $units_updated++;
                    $unit->unit_group_id = $unit_group_id;
                    $unit->save();
                }
            }
        }
        json_render(["info" => "success", "units_count" => $units_updated]);
    }

    public function update_enquiry_id()
    {
        return;
        if (in_array($this->status, ['sold', 'reserved'])) {
            $this->enquiry_id = NULL;
        }
    }


    public static function fields_config()
    {
        return array(
            "project_id" => array("label" => "Project", "required" => true, "model" => array(
                'Project', 'id',
                array('title'), array('conditions' => array('account_id=?', Acl_user::account_id()))
            )),
            "court_id" => array("label" => "Court", "model" => array('Court', 'id', array('title'), array('conditions' => array('account_id=?', Acl_user::account_id())))),

            "apartment_id" => array("label" => "Apartment", "model" => array('Apartment', 'id', array('title'), array('conditions' => array('account_id=?', Acl_user::account_id())))),
            "block_id" => array("label" => "Block", "model" => array('Block', 'id', array('title'), array('conditions' => array('account_id=?', Acl_user::account_id())))),

            "unit_group_id" => array(
                "label" => "Unit Group",
                "model" =>
                array(
                    'Unit_group', 'id', array('title'),
                    array('conditions' => array('account_id=?', Acl_user::account_id()))
                )
            ),

            "title" => array("label" => "Unit Title ", "required" => true),
            "floor_id" => array("label" => "Floor", "model" => array('Floor', 'id', array('title'))),

            "number_of_bedrooms" => array("label" => "Number of Bedrooms ", "value" => 0),
            "status" => array("label" => "Status", "params" => static::statuses()),
            "area_size" => array("label" => "Area Size"),
            "measurement_type" => array(
                "label" => " Measurement Type",
                "params" => [
                    "square_feet" => "Square Feet",
                    "hectares" => "Hectares",
                    "acres" => "Acres",
                    "meters" => "meters"
                ]
            ),

            /** "enquiry_id"=>array("label"=>"Enquiry * ",
                "model"=>array('Enquiry','id',array('name'),array('prepend'=>[""=>"-Select Lead-"],'conditions'=>array('account_id=?',Acl_user::account_id())))),
             **/
            "description" => array("label" => "Unit Description", "type" => "textarea"),
        );
    }


    public static function config($vars = [])
    {
        $config_data = array(
            "fields" => static::fields(),
            "grid_fields" => static::fields(["status", "project_id", "unit_group_id", "court_id", "block_id", "floor_id", "title"]),
            "conditions" => array("account_id=?", Acl_user::account_id()),
            "build_attrs" => true
        );


        if ($vars['screen'] == "grid") {
            $config_data['fields']['enquiry_id'] = array(
                "label" => "Enquiry * ",
                "model" => array('Enquiry', 'id', array('name'), array('prepend' => ["" => "-Select Lead-"]))
            );
            array_push($config_data['grid_fields'], 'enquiry_id');
        }
        return $config_data;
    }

    public static function config_available($vars)
    {
        static::$title = "Units Available List";
        $config = static::config($vars);
        //$config["conditions"]=static::available_units_sql();
        $config["conditions"] = ['account_id=? AND status="available"', Session::user('account_id')];
        $config['grid_actions'] = [];
        return $config;
    }

    public static function config_sold($vars)
    {
        static::$title = "Units Occupied Report";
        $config = static::config($vars);
        $config['fields']['client'] = ['label' => 'Client', 'value' => function ($result) {
            $reservation = Reservation::find_by_unit_id($result->id);
            return $reservation->enquiry->name;
        }];
        $config["grid_fields"] = ["court_id", "block_id", "floor_id", "title", 'client'];
        $config["conditions"] = ['account_id=? AND status="sold"', Session::user('account_id')];

        //$config["find_by_sql"]=static::occupied_units_sql();
        $config['grid_actions'] = [];
        return $config;
    }

    public static function  available_units_sql()
    {
        return "SELECT * FROM " . static::fetch_table() . " WHERE account_id=" . Acl_user::account_id() . " AND id 
        NOT IN(SELECT unit_id FROM " . Reservation::fetch_table() . " WHERE cancelled=0)";
    }

    public static function  occupied_units_sql()
    {
        return "SELECT * FROM " . static::fetch_table() . " WHERE account_id=" . Acl_user::account_id() . " AND id 
        IN(SELECT unit_id FROM " . Reservation::fetch_table() . " WHERE cancelled=0)";
    }

    public static function available_units()
    {
        return static::find_by_sql(static::available_units_sql());
    }

    public static function occupied_units()
    {
        return static::find_by_sql(static::occupied_units_sql());
    }

    public static function parse_floor($id)
    {
        $floors = [
            '0' => 'Ground Floor',
            '1' => 'First Floor',
            '2' => 'Second Floor',
            '3' => 'Third Floor',
            '4' => 'Fourth Floor',
            '5' => 'Fifth Floor',
        ];
        return $floors[$id];
    }

    public static function fetch_by_court_apartment_block($court_id, $block_id, $apartment_id, $floor_id = NULL)
    {
        if ($floor_id) {
            $units = Unit::all(['conditions' => ['court_id=? AND apartment_id=? AND block_id=? AND floor_id=?', $court_id, $apartment_id, $block_id, $floor_id]]);
        } else {
            $units = Unit::all(['conditions' => ['court_id=? AND apartment_id=? AND block_id=?', $court_id, $apartment_id, $block_id]]);
        }
        $results = [];
        foreach ($units as $unit) {
            $reservation = Reservation::find(['conditions' => ['unit_id=?', $unit->id]]);
            if ($reservation) {
                $occupant = $reservation->enquiry->name;
            } else {
                $occupant = "<b style='color:red;'>UNSOLD</b>";
            }
            $results[] = [
                'id' => $unit->title,
                'floor_id' => static::parse_floor($unit->floor_id),
                'unit_title' => $unit->title,
                'occupant' => $occupant,
                'unit_type_title' => $unit->type->title,
                'unit' => $unit,
                'unit_type' => $unit->type,
                'reservation' => $reservation
            ];
        }
        usort($results, 'sort_by_sub_array_key');
        return $results;
    }
}