<?php

/**
 * Handles User to Groups Many-to-many Lead_activitys
 *
 * User_group Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Sale_offer_buyer extends pPort_model
{
    static $connection = 'smart_real_estate';

    static $table = 'sale_offer_buyers';
    static $title = "Buyers";
    static $name = "Sale Buyers";
    static $description = "(Manage Buyers)";


    public static function config($vars = [])
    {
        $conditions = Session::get('collection_model') ? ['sale_offer_id=' . Session::get('collection_model')] : array("account_id=?", Acl_user::account_id());
        return array(
            "fields" => array(
                "name" => array("label" => "Title", "required" => true),
                "identitifaction_type" => array("label" => "Title", "required" => true),
                "identitifaction_number" => array("label" => "Ifentification Number", "required" => true),
                "personal_identification_number" => array("label" => "KRA PIN", "required" => true),

            ),
            // "hidden_fields"=>["sale_id"],
            "conditions" => $conditions,
            "grid_actions" => array(),

            "form" => array(
                "name" => "Document", "class" => "form-det", "id" => "Document", "method" => "POST",
                "action" => Url::base() . Portlet::get_active() . '/main/create'
            ),
        );
    }
}
