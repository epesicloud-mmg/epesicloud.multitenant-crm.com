<?php
class Agent_analysis extends Agent
{
    static $name="Agent";
    static $title="Agent";
    static $belongs_to=[

    ];
    static $has_many=[
        'enquiries'=>[
            'enquiries',
            'class_name'=>'Enquiry',
            'foreign_key'=>'agent_id'
        ],
        'reservations'=>[
            'sales',
            'class_name'=>'Sale_interest',
            'foreign_key'=>'agent_id'
        ]
    ];

  

}