<?php
class Agent_visited_location extends Followup
{
    static $title="Agents Locations";
    static $name="Agents Locations";
}