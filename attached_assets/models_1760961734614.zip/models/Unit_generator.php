<?php
/**
 * 
 * @author Martin Muriithi <martin@pporting.org>
 *
 **/
class Unit_generator extends Title_description
{
    static $connection='smart_real_estate';
    static $table='unit_generators';
    static $title="Unit Generator";
    static $description="(Manage Unit Generator)";
    static $before_save=['add_token'];
    static $after_create=['update_units'];
    
    public function add_token()
    {
        $this->token=mt_rand();
    }

    public function update_units()
    {
        if(($this->end_number-$this->start_number)>100)
        {
            json_render(['info'=>'error','message'=>'Can only input in batches of 50']);
        }
        for($i=$this->start_number;$i<=$this->end_number;$i++)
        {
            Unit::create(
                [
                    'account_id'=>Acl_user::account_id(),
                    'project_id'=>$this->project_id,
                    'block_id'=>$this->block_id,
                    'court_id'=>$this->court_id,
                    'unit_group_id'=>$this->unit_group_id,
                    'unit_generator_id'=>$this->id,
                    'unit_generator_token'=>$this->token,
                    'title'=>$this->prefix.$i
                ]

            );
        }
    }

    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "project_id"=>array("label"=>"Project*","required"=>true,
                    "model"=>array("Project","id",array("title"),['conditions'=>['account_id=?',Acl_user::account_id()]])),
                "unit_group_id"=>array("label"=>"Unit Group *","required"=>true,
                    "model"=>array("Unit_group","id",array("title"),['prepend'=>[''=>'-Select Unit Group-'],'conditions'=>['account_id=?',Acl_user::account_id()]])),
                "court_id"=>array("label"=>"Court *",
                    "model"=>array("Court","id",array("title"),['prepend'=>[''=>'-Select Court-'],'conditions'=>['account_id=?',Acl_user::account_id()]])),               
                "prefix"=>array("label"=>"Prefix"),
                "start_number"=>array("label"=>"Start Number *","required"=>true),
                "end_number"=>array("label"=>" End Number","required"=>true),
            ),
        );
    }
    
}