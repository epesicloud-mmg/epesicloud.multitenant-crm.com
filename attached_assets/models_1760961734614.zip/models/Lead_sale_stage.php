<?php
class Lead_sale_stage extends pPort_model
{

    static $table = 'lead_sale_stages';
    static $name = 'Lead Sale Stages';

    static $connection = 'smart_real_estate';
    static $belongs_to = [
        'sale_pipeline' => ['sale_pipeline', 'class_name' => 'Sale_pipeline', 'foreign_key' => 'sale_pipeline_id'],
        'sale_stage' => ['sale_stage', 'class_name' => 'Sale_stage', 'foreign_key' => 'sale_stage_id'],
        'enquiry_id' => ['lead', 'class_name' => 'Lead', 'foreign_key' => 'enquiry_id']
    ];

    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                //"sale_pipeline_id"=>array("label"=>"Sale Pipeline","model"=>["Sale_pipeline","id","title"]),
                "sale_stage_id" => array("label" => "Sale Stage", "model" => ["Sale_stage", "id", "title"]),
                "enquiry_id" => array("label" => "Lead", "model" => ["Lead", "id", ["name"]]),
                "description" => array("label" => "Description", "type" => "textarea"),
            ),
            "cols" => 1,
            "conditions" => array("account_id=? AND deleted=?", Acl_user::account_id(), 0),
            "grid_actions" => static::grid_actions(),
            "form_actions" => static::form_actions(),
            "form" => static::form_attrs(),
        );
    }
}