<?php

class Call_log extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'call_logs';
    static $title = "Call Log";
    static $description = "(Call Log Schedules)";
    static $before_create = ["add_agent_id"];
    static $after_create = ["add_lead_activity", "update_enquiry_statuses"];
    static $belongs_to = [
        "call_purpose" => ["call_purpose", "class_name" => "Call_purpose", "foreign_key" => "call_purpose_id"],
        "call_type" => ["call_type", "class_name" => "Call_type", "foreign_key" => "call_type_id"],
        "agent" => ["agent", "class_name" => "Agent", "foreign_key" => "agent_id"]
    ];


    function update_enquiry_statuses()
    {
        $lead = Enquiry::find($this->enquiry_id);
        if ($this->lead_interest_level_id) {
            $lead->lead_interest_level_id = $this->lead_interest_level_id;
        }

        if ($this->sale_stage_id) {
            $lead->sale_stage_id = $this->sale_stage_id;
        }
    }

    function add_agent_id()
    {
        if (!$this->agent_id) {
            $user = Session::user();
            $this->agent_id = $user->id;
            $this->supervisor_id = $user->supervisor_id;
        }
    }

    function add_lead_activity()
    {
        Lead_activity::create([
            'enquiry_id' => $this->enquiry_id,
            'followup_type_id' => Lead_activity_type::alias_id_or_create("call"),
            'description' => $this->phone . " : " . $this->content,
            'linked_entity' => 'Call_log',
            'linked_entity_reference' => $this->id,
            "account_id" => $this->account_id,
            'agent_id' => $this->agent_id,
            "followup_date" => $this->call_date,
            "meta_data" => json_encode($this->to_array())
        ]);
    }

    public static function fields_config()
    {
        return array(
            //Inbound, Outbound, Missed
            "enquiry_id" => ['label' => "Enquiry",  "model" => ["Enquiry", "id", ["name"]]],
            "agent_id" => ['label' => "Agent",  "model" => ["Agent", "id", ["first_name", "last_name"]]],
            "call_type_id" => ['label' => "Call Type",  "model" => ["Call_type", "id", "title"]],
            "enquiry_id" => ['label' => "Select Lead", "type" => "hidden", "value" => $_REQUEST['enquiry_id']],
            "call_date" => array("label" => "Call Date", "value" => date("Y-m-d"), "required" => true, "type" => "date", "format" => "date"),
            "call_time" => array("label" => "Call  Time", "params" => hours_range(), "required" => true),
            "call_duration" => array("label" => "Call Duration (Minutes)",  "required" => true),
            //
            "call_purpose_id" => ['label' => "Call Purpose",  "model" => ["Call_purpose", "id", "title"]],
            "phone" => array("label" => "Phone", "required" => true),
            "content" => array("label" => "Additional Notes", "type" => "textarea", "required" => true),
            "lead_interest_level_id" => ['label' => "Interest Level",  "model" => ["Lead_interest_level", "id", "title"]],
            "sale_stage_id" => ['label' => "Sale Stage",  "model" => ["Sale_stage", "id", "title"]],
        );
    }


    public static function config($vars = [])
    {
        $config_data = array(
            "fields" => static::fields(['enquiry_id', "call_type_id", "call_date", "call_time", "call_duration", "call_purpose_id", 'content', "lead_interest_level_id", "sale_stage_id"]),
            "grid_fields" => static::fields(),
            "form_actions" => static::form_actions(["save"]),
            "colspan" => 6
        );
        return $config_data;
    }
}