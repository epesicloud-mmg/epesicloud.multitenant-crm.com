<?php
class Project_facility extends pPort_model
{
    static $connection='smart_real_estate';
    static $table='project_facilities';
    static $title="Project Facility";
    
    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "facility_type_id"=>array("label"=>"Facility Type","required"=>true,"model"=>array('Facility_type','id','title',['conditions'=>['account_id=?',Acl_user::account_id()]])), 
                "project_id"=>array("label"=>"Project","required"=>true,"model"=>array('Property','id','title',array('conditions'=>array('account_id=?',Session::user('account_id'))))),              
                "title"=>array("label"=>"Title *","required"=>true),
                "distance"=>array("label"=>"Distance *","required"=>true),
                
                "description"=>array("label"=>"Additional Description","type"=>"textarea")
            ),
            "grid_actions"=>[],
            
        );
    }
}