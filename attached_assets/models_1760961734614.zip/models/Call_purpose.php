<?php
class Call_purpose extends Title_description
{
    static $connection = 'smart_real_estate';
    static $table = 'call_purposes';
    static $title = "Call Purpose";
}