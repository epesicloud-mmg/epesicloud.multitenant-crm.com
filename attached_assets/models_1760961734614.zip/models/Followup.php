<?php

/**
 * Handles User lead_activities
 *
 * User Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Followup extends pPort_model
{

  static $table = 'followups';
  static $title = 'Followups';
  static $description = '(Manage Followups)';
  static $after_create = array('update_enquiry_status');
  static $connection = 'smart_real_estate';
  static $belongs_to = [
    'enquiry' => ["enquiry", "foreign_key" => "enquiry_id", "class_name" => "Enquiry"],
    'account_executive' => ["account_executive", "foreign_key" => "agent_id", "class_name" => "Agent"],
    'agent' => ["agent", "foreign_key" => "agent_id", "class_name" => "Agent"],
    'user' => ["user", "foreign_key" => "user_id", "class_name" => "User"],


    'followup_type' => ["followup_type", "foreign_key" => "followup_type_id", "class_name" => "Followup_type"],
    'meeting' => ["meeting", "foreign_key" => "meeting_id", "class_name" => "Lead_meeting"],
    'reminder_type' => ["reminder_type", "foreign_key" => "reminder_type_id", "class_name" => "Reminder_type"],
    'lead_interest_level' => ["lead_interest_level", "foreign_key" => "lead_interest_level_id", "class_name" => "Lead_interest_level"]

  ];
  static $has_many = [
    'followup_actions' => ["followup_actions", "foreign_key" => "followup_id", "class_name" => "Followup_action"],
  ];

  static $before_save = ["add_user","add_supervisor"];

  function add_supervisor()
  {
    if (!$this->supervisor_id) {
      $agent = Agent::find($this->agent_id);
      $this->supervisor_id = $agent->supervisor_id;
    }
  }

  function add_user()
  {
    if ($this->user_id==NULL) {
      $this->user_id=$this->agent_id;
    }
    
  }



  function update_enquiry_status()
  {
    if($this->enquiry_id)
    {
      $enquiry = Enquiry::find($this->enquiry_id);
      if($enquiry)
      {
        $enquiry->status = "followup";
        $enquiry->save();
      }
    }
    
    
  }

  function add_account_executive()
  {
    if (Session::exists()) {
      if (is_null($this->agent_id)) {
        $enquiry = Enquiry::find($this->enquiry_id);
        $this->agent_id = $enquiry->agent_id;
      }
    }
  }


  public static function config_basic_report($vars = [])
  {
    return array(
      "find_by_sql"=>"SELECT followups.id,followups.followup_date,epesi_acl_cloud.acl_users.first_name,epesi_acl_cloud.acl_users.last_name,followup_types.title,enquiries.name FROM `followups` INNER JOIN enquiries ON followups.enquiry_id=enquiries.id INNER JOIN followup_types ON followups.followup_type_id=followup_types.id 
      INNER JOIN epesi_acl_cloud.acl_users ON followups.agent_id=epesi_acl_cloud.acl_users.id 
      WHERE followups.created_at LIKE '%".date('Y-m-d')."%' ORDER BY followups.agent_id DESC",
      "fields" => array(
        "first_name"=>['label'=>'First Name'],
        "followup_date"=>['label'=>'Followup Date'],
        "title"=>['label'=>'Followup Type'],
        "name"=>['label'=>'Name']       
      ));
  }


  public static function config_report($vars = [])
  {

    if (static::$model_id) {
      $followup = Followup::find(static::$model_id);
      $enquiry_id = $followup->enquiry_id;
    } else {
      $enquiry_id = arr('enquiry_id', $vars, NULL);
    }
    if (arr('screen', $vars) == 'form') {
      $enquiry = Enquiry::find($enquiry_id);
      if ($enquiry) {
        static::$title = "Followups Post : " . $enquiry->name;
      }
    }

    return array(
      "fields" => array(

        "enquiry_id" => array("label" => "Lead", "model" => array("Enquiry", "id", array("name"), ["conditions" => ["account_id=?", Session::user("account_id")], "selected" => $enquiry_id])),
        "lead_source" => array("label" => "Lead Source", "disabled" => true, "value" => function ($result) {
          $enquiry = Enquiry::find($result->enquiry_id);
          if ($enquiry) {
            $lead_source = Lead_source::find($enquiry->lead_source_id);
            return ($lead_source) ? $lead_source->title : $enquiry->lead_source;
          }
          return "";
        }),
        "agent_id" => array("label" => "Account Exec", "model" => array("Account_executive", "id", array("first_name", "last_name"), ["conditions" => ['account_id=?', Session::user('account_id')]])),
        "followup_date" => array("label" => "Followup Date", "type" => "date"),
        "followup_type_id" => array("label" => "Followup Type", "model" => array("Followup_type", "id", array("title"))),
        "description" => array("label" => "Notes", "type" => "textarea"),

        "reminder_date" => array("label" => "Reminder Date", "type" => "date"),
        "reminder_description" => array("label" => "Reminder Description", "type" => "textarea"),
        "lead_interest_level_id" => array("label" => "Interest Level (Optional)", 'model' => array(
          'Lead_interest_level', 'id',
          ['title'], ["conditions" => ["account_id=?", Acl_user::account_id()], "prepend" => ["0" => "--Interest Level--"]]
        )),
        "sale_stage_id" => array("label" => "Sale Stage (Optional)", 'model' => array(
          'Sale_stage', 'id',
          ['title'], ["conditions" => ["account_id=?", Acl_user::account_id()], "prepend" => ["0" => "--Sale Stage--"]]
        )),
        "estimate_deal_close_date" => array("label" => "Estimate Deal Close Date (Optional)", 'type' => 'date'),
        "estimate_deal_revenue" => array("label" => "Estimate Deal Revenue"),
        "year_month" => array("label" => "Year", "type" => "text", "disabled" => true, "value" => function ($result) {
          if ($result->id) {
            return date("Y-M", strtotime($result->followup_date));
          }
        }),
        "lead_activities_count" => array("label" => "Lead_activitys", "disabled" => true, "value" => function ($result) {
          if ($result->id) {
            $followups = Followup::all(['conditions' => ['enquiry_id=?', $result->enquiry_id]]);
            $followups_string = "<h5>" . count($followups) . "-Lead_activitys</h5>";
            if (count($followups) > 0) {
              $followups_string = "<ul>";
              foreach ($followups as $followup) {
                $followup_type = $followup->followup_type ? $followup->followup_type->title : "Uncategorized";
                $followups_string .= "<li>" . $followup_type . "(Followup Date : " . date("Y-m-d", strtotime($followup->followup_date)) . ", Note : " . $followup->description . ")</li>";
              }
              $followups_string .= "</ul>";
            }
            return $followups_string;
          } else {
            return 0;
          }
        }),
        "followup_actions_count" => array("label" => "Actions", "disabled" => true, "value" => function ($result) {
          if ($result->id) {
            $actions = Followup_action::all(['conditions' => ['followup_id=?', $result->id]]);
            $action_string = "";
            if (count($actions) > 0) {
              $action_string = "<ul>";
              foreach ($actions as $action) {
                $action_string .= "<li>" . $action->description . "(Due Date : " . date("Y-m-d", strtotime($action->due_date)) . ")</li>";
              }
              $action_string .= "</ul>";
            }
            return $action_string;
          } else {
            return 0;
          }
        }),
      ),
      /**"front_end_filters"=>[
              "col_0"=> "select", 
              "col_1"=> "select", 
              "col_2"=> "select", 
              "col_3"=> "select", 
              "col_4"=> "select",  
              "col_5"=> "select",
              "col_6"=> "none",
              "display_all_text"=> " [ Show all ] ",  
              "sort_select"=> true ,
              "btn"=>"Search"  
          ],**/

      "grid_fields" => [
        "followup_date",
        "enquiry_id",
        "agent_id",
        "lead_interest_level_id",
        "followup_type_id",
        "description",
        "lead_activities_count",
        "followup_actions_count"
      ],

      "cols" => 2,
      "conditions" => array("deleted=? AND account_id=?", 0, Acl_user::account_id()),
      "limit" => 1000,
      "grid_actions" => [
        'view_actions' => [
          'label' => 'View',
          'text' => 'View',
          'href' => Url::batch_panel('Followup/followup_actions/{@id}')
        ]
      ],
      "filters"=>true,
      "limit"=>500,
      "form_actions" => static::form_actions(['save']),
      "form" => static::form_attrs(['window_location' => Url::entry_panel('Followup/enquiry_id/' . $enquiry_id)]),
    );
  }

  public static function config($vars = [])
  {

    if (static::$model_id) {
      $followup = Followup::find(static::$model_id);
      $enquiry_id = $followup->enquiry_id;
    } else {
      $enquiry_id = arr('enquiry_id', $vars, NULL);
    }
    if (arr('screen', $vars) == 'form') {
      $enquiry = Enquiry::find($enquiry_id);
      if ($enquiry) {
        static::$title = "Followups Post : " . $enquiry->name;
      }
    }

    return array(
      "fields" => array(
        "agent_id" => array("label" => "Agent", "model" => array("Account_executive", "id", array("first_name", "last_name"), ["conditions" => ['account_id=?', Session::user('account_id')]])),
        "enquiry_id" => array("label" => "Lead", "model" => array("Enquiry", "id", array("name"), ["conditions" => ["account_id=?", Session::user("account_id")], "selected" => $enquiry_id])),
        "followup_date" => array("label" => "Followup Date", "type" => "date"),
        "followup_type_id" => array("label" => "Followup Type", "model" => array("Followup_type", "id", array("title"))),
        "description" => array("label" => "Notes", "type" => "textarea"),
        "reminder_type_id" => array("label" => "Reminder Type", "model" => array("Reminder_type", "id", array("title"))),

        "reminder_date" => array("label" => "Reminder Date", "type" => "date"),

        "lead_interest_level_id" => array("label" => "Interest Level", 'model' => array(
          'Lead_interest_level', 'id',
          ['title'], ["conditions" => ["account_id=?", Acl_user::account_id()], "prepend" => ["0" => "--Interest Level--"]]
        )),
      ),
      /**"front_end_filters"=>[
              "col_0"=> "select", 
              "col_1"=> "select", 
              "col_2"=> "select", 
              "col_3"=> "select", 
              "col_4"=> "select",  
              "col_5"=> "select",
              "col_6"=> "none",
              "display_all_text"=> " [ Show all ] ",  
              "sort_select"=> true ,
              "btn"=>"Search"  
          ],*/

      "grid_fields" => array(
        "agent_id" => array("label" => "Agent", "model" => array("Account_executive", "id", array("first_name", "last_name"), ["conditions" => ['account_id=?', Session::user('account_id')]])),
        "enquiry_id" => array("label" => "Lead", "model" => array("Enquiry", "id", array("name"), ["conditions" => ["account_id=?", Session::user("account_id")], "selected" => $enquiry_id])),
        "created_at" => array("label" => "Followup Time", "type" => "date", "value" => function ($result) {
          return the_future(3, 'hour', $result->created_at, 'Y-m-d H:i');
        }),
        "followup_type_id" => array("label" => "Followup Type", "model" => array("Followup_type", "id", array("title"))),
        "description" => array("label" => "Notes", "type" => "textarea"),

        "lead_interest_level_id" => array("label" => "Interest Level", 'model' => array(
          'Lead_interest_level', 'id',
          ['title'], ["conditions" => ["account_id=?", Acl_user::account_id()], "prepend" => ["0" => "--Interest Level--"]]
        )),
      ),

      "cols" => 2,
      "conditions" => array("deleted=? AND account_id=?", 0, Acl_user::account_id()),
      "limit" => 1000,
      "grid_actions" => [
        'view_actions' => [
          'label' => 'View',
          'text' => 'View',
          'href' => Url::batch_panel('Followup/followup_actions/{@id}')
        ]
      ],
      "form_actions" => static::form_actions(['save']),
      "form" => static::form_attrs(['window_location' => Url::entry_panel('Followup/enquiry_id/' . $enquiry_id)]),
    );
  }

  public static function config_all($vars)
  {
    static::$title = "Scheduled & Past Followups";
    return array(
      "fields" => array(
        "agent_id" => array("label" => "Account Exec", "model" => array("Account_executive", "id", array("first_name", "middle_name", "last_name"))),
        "enquiry_id" => array("label" => "Client", "model" => array("Enquiry", "id", array("name"))),
        "followup_date" => array("label" => "Followup Date", "type" => "date", "value" => date('Y-m-d')),
        "followup_type_id" => array("label" => "Followup Type", "model" => array("Acc_followup_type", "id", array("title"))),
        "description" => array("label" => "Notes", "type" => "textarea"),
        // "reminder_date"=>array("label"=>"Reminder Date","type"=>"date"),
      ),
      "cols" => 2,
      "conditions" => array("enquiry_id=? AND deleted=? AND account_id=?", $enquiry_id, 0, Acl_user::account_id()),
      "grid_actions" => static::grid_actions(),
      "form_actions" => static::form_actions(),
      "form" => static::form_attrs(['window_location' => Url::entry_panel('Followup/enquiry_id/' . $enquiry_id)]),
    );
  }

  public static function config_summary($vars)
  {

    static::$title = "Followup Types : Summary";
    $sql = "SELECT followup_types.title,COUNT(*) AS followups_count FROM followups 
        INNER JOIN followup_types ON followups.followup_type_id=followup_types.id  
        WHERE  followups.account_id=" . Acl_user::account_id() . " 
        GROUP BY followup_types.title";
    return array(
      "find_by_sql" => $sql,
      "fields" => array(
        "title" => array("label" => "Followup Type"),
        "followups_count" => array("label" => "Followup Count"),
      ),
      "cols" => 2,
      "grid" => ["chart" => ["type" => "pie", "show_grid" => true]],
      "grid_actions" => [],
      "conditions" => ['account_id=?', Acl_user::account_id()],
      "form" => [],
    );
  }





  public static function config_summary_today($vars)
  {
    static::$title = "Followup Types : Summary";
    $sql = "SELECT followup_types.title,COUNT(*) AS followups_count FROM followups 
        INNER JOIN followup_types ON followups.followup_type_id=followup_types.id  WHERE followups.account_id=" . Acl_user::account_id() . " AND followup_date LIKE '%" . date('Y-m-d') . "%'
        GROUP BY followup_types.title";
    return array(
      "find_by_sql" => $sql,
      "fields" => array(
        "title" => array("label" => "Followup Type"),
        "followups_count" => array("label" => "Followup Count"),
      ),
      "cols" => 2,
      "grid" => ["chart" => ["type" => "pie", "show_grid" => true]],
      "form" => [],
      "grid_actions" => [],
      "conditions" => ['account_id=?', Acl_user::account_id()],

    );
  }

  public static function config_visits_scheduled($vars)
  {
    static::$title = "Scheduled Visits";


    return array(
      "filter_date" => "followup_date",
      "fields" => array(
        "agent_id" => array("label" => "Account Exec", "model" => array("Account_executive", "id", array("first_name", "middle_name", "last_name"))),
        "enquiry_id" => array("label" => "Client", "model" => array("Enquiry", "id", array("name"))),
        "followup_date" => array("label" => "Followup Date", "format" => 'date', "type" => "date", "value" => date('Y-m-d')),
        "followup_type_id" => array("label" => "Followup Type", "model" => array("Followup_type", "id", array("title"))),

        "description" => array("label" => "Notes", "type" => "textarea"),
        // "reminder_date"=>array("label"=>"Reminder Date","format"=>'date',"type"=>"date"),
      ),

      "front_end_filters" => [
        "col_0" => "select",
        "col_1" => "select",
        "col_2" => "select",
        "col_3" => "select",
        "btn" => "Search"
      ],

      "cols" => 2,
      "grid" => ["responsive" => 0],
      "conditions" => array("deleted=? AND followup_type_id=?
            AND account_id=" . Acl_user::account_id(), Followup_type::alias_id("site_visit_scheduling"), 0),
      "grid_actions" => [],
      "form_actions" => static::form_actions(),
      "form" => static::form_attrs(),
    );
  }

  public static function config_visits_completed($vars)
  {
    $config = static::config_visits_scheduled($vars);
    $config["conditions"] = array("deleted=? AND followup_type_id=? AND followups.account_id=" . Acl_user::account_id(), 0, Followup_type::alias_id('site_visit_checkout'));
    return $config;
  }

  public static function config_visits_scheduled_today($vars)
  {

    $config = static::config_visits_scheduled($vars);
    static::$title = "Visits Planned Today";
    $config["conditions"] = array("deleted=? AND followup_type_id=? AND followup_date LIKE '%" . date('Y-m-d') . "%' AND account_id=" . Acl_user::account_id(), 0, Followup_type::alias_id('site_visit_scheduling'));
    return $config;
  }


  public static function config_visits_completed_today($vars)
  {

    $config = static::config_visits_scheduled($vars);
    static::$title = "Visits Done Today";
    $config["conditions"] = array("deleted=? AND followup_type_id=? AND followup_date LIKE '%" . date('Y-m-d') . "%' AND followups.account_id=" . Acl_user::account_id(), 0, Followup_type::alias_id('site_visit_checkout'));
    return $config;
  }



  public static function config_account_executive($vars)
  {
    $agent_id = arr('agent_id', $vars, false);
    return array(
      "fields" => array(
        "followup_date" => array("label" => "Followup Date", "type" => "date"),
        "followup_type_id" => array("label" => "Followup Type", "model" => array("Acc_followup_type", "id", array("title"), ["conditions" => ['account_id=?', Acl_user::account_id()]])),
        "description" => array("label" => "Notes", "type" => "textarea"),
        "reminder_date" => array("label" => "Schedule Next Followup Date", "type" => "date"),
      ),
      "cols" => 2,
      //"conditions"=>array("created_by=? AND deleted=?",$agent_id,0),
      "conditions" => ['account_id=?', Acl_user::account_id()],
      "grid_actions" => [],
      "form_actions" => static::form_actions(),
    );
  }



  public static function config_account_executives_summary_today($vars)
  {
    static::$title = "Todays Lead_activitys Summary";
    static::$description = "";
    $condition = "";
    if (isset($vars['today'])) {
      $condition = " AND  `epesi_realty`.followups.followup_date LIKE '%" . date('Y-m-d') . "%'";
    } elseif (isset($vars['account_executive'])) {
      $condition = " AND agent_id=" . $vars['account_executive'];
    }


    $followup_date = date('Y-m-d');

    $sql = "SELECT        
        CONCAT(`epesi_acl_master`.`acl_users`.`first_name`,' ',`epesi_acl_master`.`acl_users`.`last_name`,' ',`epesi_acl_master`.`acl_users`.`phone`,' ',`epesi_acl_master`.`acl_users`.`email` ) 
        AS account_executive,
       COUNT(0) AS `leads_allocated_count`,
       (
       SELECT
         COUNT(0)
       FROM
         `epesi_realty`.`followups`
       WHERE
         (
           `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id`
         )
     ) AS `lead_activities_count`,
      (
       SELECT
         COUNT(0)
       FROM
         `epesi_realty`.`followups`
       WHERE
         (
           `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id` AND `epesi_realty`.followups.followup_type_id=1   
           AND epesi_realty.followups.followup_date='" . $followup_date . "'
         )
     ) AS `calls_count`,
     (
       SELECT
         COUNT(0)
       FROM
         `epesi_realty`.`followups`
       WHERE
         (
           `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id` AND `epesi_realty`.followups.followup_type_id=2   
           AND epesi_realty.followups.followup_date='" . $followup_date . "'
         )
     ) AS `email_count`,
     (
       SELECT
         COUNT(0)
       FROM
         `epesi_realty`.`followups`
       WHERE
         (
           `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id` AND `epesi_realty`.followups.followup_type_id=3  
           AND epesi_realty.followups.followup_date='" . $followup_date . "'
         )
     ) AS `sms_count`,
     (
       SELECT
         COUNT(0)
       FROM
         `epesi_realty`.`followups`
       WHERE
         (
           `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id` AND `epesi_realty`.followups.followup_type_id=4  
           AND epesi_realty.followups.followup_date='" . $followup_date . "'
         )
     ) AS `visit_count`
     ,
     (
       SELECT
         COUNT(0)
       FROM
         `epesi_realty`.`followups`
       WHERE
         (
           `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id` AND `epesi_realty`.followups.followup_type_id=5 
           AND epesi_realty.followups.followup_date='" . $followup_date . "'
         )
     ) AS `planned_visit_count`
     ,
     (
       SELECT
         COUNT(0)
       FROM
         `epesi_realty`.`followups`
       WHERE
         (
           `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id` AND `epesi_realty`.followups.followup_type_id=6 AND epesi_realty.followups.followup_date='2019-02-13'
         )
     ) AS `reminder_count`
     FROM
       (
         `epesi_realty`.`enquiries_account_executives`
       JOIN
         `epesi_acl_master`.`acl_users` ON(
           (
             `epesi_realty`.`enquiries_account_executives`.`agent_id` = `epesi_acl_master`.`acl_users`.`id`
           )
         )
       )
     WHERE
       `epesi_acl_master`.`acl_users`.`deleted` = 0  AND `epesi_acl_master`.`acl_users`.account_id=" . Acl_user::account_id() . " 
     GROUP BY
       `epesi_realty`.`enquiries_account_executives`.`agent_id`";
    return array(
      "find_by_sql" => $sql,
      "fields" => array(
        "account_executive" => array("label" => "Account Executive"),
        "leads_allocated_count" => array("label" => "Leads Allocated"),
        "lead_activities_count" => array("label" => "Lead_activitys Count"),
        "calls_count" => array("label" => "Calls Count"),
        "email_count" => array("label" => "Email Count"),
        "sms_count" => array("label" => "Sms Count"),
        "visit_count" => array("label" => "Visit Count"),
        "planned_visit_count" => array("label" => "Planned Visit Count"),
        "reminder_count" => array("label" => "Reminder Count"),
      ),
      "cols" => 2,
      //"grid"=>["chart"=>["type"=>"column","show_grid"=>true]],
      "grid_actions" => [],
      "conditions" => ['account_id=?', Acl_user::account_id()],
      "form" => [],
    );
  }



  public static function config_account_executives_summary($vars)
  {
    static::$title = "Lead_activitys Summary";
    static::$description = "";
    $condition = "";
    if (isset($vars['today'])) {
      $condition = " AND  `epesi_realty`.followups.followup_date LIKE '%" . date('Y-m-d') . "%'";
    } elseif (isset($vars['account_executive'])) {
      $condition = " AND agent_id=" . $vars['account_executive'];
    }



    $sql = "SELECT        
         CONCAT(`epesi_acl_master`.`acl_users`.`first_name`,' ',`epesi_acl_master`.`acl_users`.`last_name`,' ',`epesi_acl_master`.`acl_users`.`phone`,' ',`epesi_acl_master`.`acl_users`.`email` ) 
         AS account_executive,
        COUNT(0) AS `leads_allocated_count`,
        (
        SELECT
          COUNT(0)
        FROM
          `epesi_realty`.`followups`
        WHERE
          (
            `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id`
          )
      ) AS `lead_activities_count`,
       (
        SELECT
          COUNT(0)
        FROM
          `epesi_realty`.`followups`
        WHERE
          (
            `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id` AND `epesi_realty`.followups.followup_type_id=1
          )
      ) AS `calls_count`,
      (
        SELECT
          COUNT(0)
        FROM
          `epesi_realty`.`followups`
        WHERE
          (
            `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id` AND `epesi_realty`.followups.followup_type_id=2
          )
      ) AS `email_count`,
      (
        SELECT
          COUNT(0)
        FROM
          `epesi_realty`.`followups`
        WHERE
          (
            `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id` AND `epesi_realty`.followups.followup_type_id=3
          )
      ) AS `sms_count`,
      (
        SELECT
          COUNT(0)
        FROM
          `epesi_realty`.`followups`
        WHERE
          (
            `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id` AND `epesi_realty`.followups.followup_type_id=4
          )
      ) AS `visit_count`
      ,
      (
        SELECT
          COUNT(0)
        FROM
          `epesi_realty`.`followups`
        WHERE
          (
            `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id` AND `epesi_realty`.followups.followup_type_id=5
          )
      ) AS `planned_visit_count`
      ,
      (
        SELECT
          COUNT(0)
        FROM
          `epesi_realty`.`followups`
        WHERE
          (
            `epesi_realty`.`followups`.`created_by` = `epesi_realty`.`enquiries_account_executives`.`agent_id` AND `epesi_realty`.followups.followup_type_id=6
          )
      ) AS `reminder_count`
      FROM
        (
          `epesi_realty`.`enquiries_account_executives`
        JOIN
          `epesi_acl_master`.`acl_users` ON(
            (
              `epesi_realty`.`enquiries_account_executives`.`agent_id` = `epesi_acl_master`.`acl_users`.`id`
            )
          )
        )
      WHERE
        `epesi_acl_master`.`acl_users`.`deleted` = 0  AND `epesi_acl_master`.`acl_users`.account_id=" . Acl_user::account_id() . " 
      GROUP BY
        `epesi_realty`.`enquiries_account_executives`.`agent_id`";
    return array(
      "find_by_sql" => $sql,
      "fields" => array(
        "account_executive" => array("label" => "Account Executive"),
        "leads_allocated_count" => array("label" => "Leads Allocated"),
        "lead_activities_count" => array("label" => "Lead_activitys Count"),
        "calls_count" => array("label" => "Calls Count"),
        "email_count" => array("label" => "Email Count"),
        "sms_count" => array("label" => "Sms Count"),
        "visit_count" => array("label" => "Visit Count"),
        "planned_visit_count" => array("label" => "Planned Visit Count"),
        "reminder_count" => array("label" => "Reminder Count"),
      ),
      "cols" => 2,
      "grid" => ["chart" => ["type" => "column", "show_grid" => arr('show_grid', $vars, false)]],
      "grid_actions" => [],
      "conditions" => ['account_id=?', Acl_user::account_id()],
      "form" => [],
    );
  }



  public static function visits_today()
  {
    return Followup::count(['conditions' => ['followup_date LIKE "%' . date('Y-m-d') . '%" AND followup_type_id=? AND account_id=' . Acl_user::account_id(), Followup_type::alias_id('site_visit_checkout')]]);
  }

  public static function calls_today()
  {
    return Followup::count(['conditions' => ['followup_date LIKE "%' . date('Y-m-d') . '%" AND followup_type_id=? AND account_id=' . Acl_user::account_id(), Followup_type::alias_id('call')]]);
  }


  public static function mails_today()
  {
    return Mail_box::today();
  }

  public static function today()
  {
    return static::count(['conditions' => ['followup_date LIKE "%' . date('Y-m-d') . '%" AND account_id=' . Acl_user::account_id()]]) + static::mails_today();
  }

  public static function visits_today_percentage()
  {
    $followup_today = Followup::today();
    return $followup_today ? Followup::visits_today() / $followup_today * 100 : 0;
  }

  public static function calls_today_percentage()
  {
    $followup_today = Followup::today();
    return $followup_today ? Followup::calls_today() / $followup_today * 100 : 0;
  }


  public static function mails_today_percentage()
  {
    $followup_today = Followup::today();
    return $followup_today ? Mail_box::today() / $followup_today * 100 : 0;
  }
}
