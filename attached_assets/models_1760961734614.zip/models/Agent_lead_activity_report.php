<?php

class Agent_lead_activity_report extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'agent_lead_activity_reports';
    static $title = "Agent Lead_activity Report";
    static $description = "(Agent Lead_activity Report)";

    static $before_create = ["generate_summary_data_records"];
    static $after_create = ["send_sms"];


    public function generate_summary_data_records()
    {
        $agent = Agent::find($this->agent_id);
        $this->agent_phone = $agent->phone;

        $_REQUEST['report_start_date'] = $this->start_date;
        $_REQUEST['report_end_date'] = $this->end_date;


        $this->leads_count = $agent->leads_count;
        $this->calls_count = $agent->get_lead_activity_count("call");
        $this->sms_count = $agent->get_lead_activity_count("sms");
        $this->whatsapp_count = $agent->get_lead_activity_count("whatsapp");
        $this->followup_notes_count = $agent->get_lead_activity_count("followup_note");
        $this->reminders_count = $agent->get_lead_activity_count("reminder");

        foreach (['leads_count', 'calls_count', 'sms_count', 'whatsapp_count', 'followup_notes_count', 'reminders_count'] as $followup_type_alias) {
            $followup_type_key = str_replace("_count", "", $followup_type_alias);
            $followup_summary_entry[$followup_type_key] = pluralize(nice_name($followup_type_key)) . " [" . $this->{$followup_type_alias} . "]";
        }
        $message = "Hello " . $agent->first_name . ", here is your last " . days_difference($this->start_date, $this->end_date) . " DAYS lead_activity summary." . implode(",", $followup_summary_entry);
        $this->sms_report = $message;
    }

    public function send_sms()
    {
        if ($this->is_sms_enabled && $this->sms_report) {
            $phone = $this->agent_phone;
            $phone = "0729934932";
            Sms::send($this->sms_report, $phone);
        }
    }



    public static function fields_config()
    {
        return array(
            "start_date" => array("label" => "Start Date", "value" => the_past("1", "week"), "required" => true, "type" => "date"),
            "end_date" => array("label" => "End Date", "value" => date("Y-m-d"), "required" => true, "type" => "date"),
            "agent_id" => array("label" => "Agent", "model" => array("Agent", "id", ["first_name", "last_name"], ["conditions" => ["account_id=? AND deleted=0", Session::user("account_id")]])),
            "call" => array("label" => "Calls", "readonly" => true),
            "email" => array("label" => "Email", "readonly" => true),
            "sms" => array("label" => "Sms", "readonly" => true),
            "followup_note" => array("label" => "Followup Note", "readonly" => true),
            "reminder" => array("label" => "Reminder", "readonly" => true),
            "is_sms_enabled" => array("label" => "Send SMS", "params" => ["0" => "No", "1" => "Yes"]),
            "sms_report" => array("label" => "Message", "readonly" => true),
        );
    }

    public static function config($vars = [])
    {
        $config_data = array(
            "fields" => static::fields(["start_date", "end_date", "agent_id", "is_sms_enabled"]),
            "grid_fields" => static::fields()
        );
        return $config_data;
    }
}
