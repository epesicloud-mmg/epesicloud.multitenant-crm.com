<?php
/**
 *
 * @author <Martin Muriithi> <martin@pporting.org>
 */
class Commision_setting extends pPort_model
{

    static $table_name="commision_settings";
    static $primary_key="id";
    static $connection='smart_real_estate';

    static $title='Commisions';
    static $description='Manage Commisions';
    


    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "approver_title"=>array("label"=>"Approver Title","required"=>true),
                "approver_name"=>array("label"=>"Approver Name","required"=>true),
                "verifier_title"=>array("label"=>"Verifier Title","required"=>true),
                "verifier_name"=>array("label"=>"Verifier Name","required"=>true),
            ),
            "cols"=>2,
            "build_config"=>true,
            "grid_actions"=>static::grid_actions(),
            "conditions"=>["account_id=?",Acl_user::account_id()]
        );
    }
}

?>