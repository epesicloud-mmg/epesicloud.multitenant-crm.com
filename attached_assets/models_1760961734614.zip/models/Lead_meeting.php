<?php

class Lead_meeting extends pPort_model
{
    static $_where_strings = NULL;
    static $_where_values = NULL;
    static $connection = 'smart_real_estate';
    static $table = 'lead_meetings';
    static $enabled_for_time_range = true;
    static $title = "Activity";
    static $description = "Schedule Meeting";
    static $filter_date = "meeting_date";


    static $before_create = [
        "update_meeting_time", "update_meeting_title",
        "update_lead_details", "update_agent_details", "update_project_details"
    ];
    static $before_save = ['check_if_duplicate', 'add_default_action', "add_lead_activity_times"];

    static $belongs_to = [
        "meeting_type" => [
            "meeting_type", "class_name" => "Meeting_type", "foreign_key" => "meeting_type_id"
        ],
        "lead_interest_level" => [
            "lead_interest_level", "class_name" => "Lead_interest_level", "foreign_key" => "lead_interest_level_id"
        ],
        "enquiry" => [
            "enquiry", "class_name" => "Enquiry", "foreign_key" => "enquiry_id"
        ]
    ];

    static $after_save = ["create_lead_activity"];
    static $after_create = ["add_to_calendar"];

    public  function check_if_duplicate()
    {

        if (Lead_meeting::exists(['conditions' => ['enquiry_id=? AND meeting_date LIKE "%' . $this->meeting_date . '%"', $this->enquiry_id]])) {
            json_render(['info' => 'success', 'message' => 'You have already scheduled another meeting for the same client on ' . $this->meeting_date]);
        }
    }

    public static function ajaxfy_update_lead_source_id()
    {
        foreach (static::all(['limit' => 500, 'conditions' => ['lead_source_id IS NULL']]) as $meeting) {
            $enquiry = Enquiry::find($meeting->enquiry_id);
            $meeting->lead_source_id = $enquiry->lead_source_id;
            if (!$meeting->description) {
                $meeting->description = "";
            }
            $meeting->save();
        }
    }


    public static function global_grid_actions()
    {
        return [
            'client_feed' => [
                "text" => 'Client Feed',
                'target' => '_blank',
                'href' => Url::component_panel("Enquiry/timeline/{@enquiry_id}"),
                //Exclude in these configs
                'excluded_configs' => []
            ]
        ];
    }


    public function add_to_calendar()
    {
        $user_id = $this->user_id ? $this->user_id : $this->agent_id;

        Calendar_item::create(
            [
                'calendar_item_type_id' => Calendar_item_type::alias_id_or_create("meeting"),
                'linked_entity' => 'Lead_meeting',
                'linked_entity_id' => $this->id,
                'account_id' => $this->account_id,
                'title' => $this->title,
                'start_date' => $this->meeting_date,
                'start_time' => $this->meeting_time,
                'created_by' => $user_id

            ]
        );
    }



    public function update_meeting_time()
    {

        if ($this->start_time != NULL) {
            $this->meeting_time = $this->start_time;
        }

        if ($this->start_time == NULL) {
            $this->start_time = $this->meeting_time;
        }
    }

    public function add_default_action()
    {
        if (!$this->action) {
            $this->action = "scheduling";
        }
    }

    public function add_lead_activity_times()
    {


        if ($this->action_time == NULL) {
            $this->action_time = date("Y-m-d H:i:s");
            $this->action_date = date("Y-m-d");
        }
    }

    public function create_lead_activity()
    {
        /**if(!Lead_activity::exists(['conditions'=>['meeting_id=?',$this->id]]))
        {**/
        //Create Site-Visit Lead_activity
        $_REQUEST['account_id'] = $this->account_id;
        $params_data = [
            "meeting_id" => $this->id,
            'enquiry_id' => $this->enquiry_id,
            'account_id' => $this->account_id,
            'agent_id' => $this->agent_id,
            'description' => $this->description,
            'meeting_date' => $this->meeting_date,
            'start_time' => $this->start_time,
            'end_time' => $this->end_time,
            'meeting_time' => $this->meeting_time,
            'followup_time' => $this->action_time,
            'followup_date' => $this->action_date,
            "lead_interest_level_id" => $this->lead_interest_level_id,
            "meeting_id" => $this->id,
            'enquiry_id' => $this->enquiry_id,
            'linked_entity' => 'Lead_meeting',
            'linked_entity_reference' => $this->id,
            'location_meta_data' => $this->location_meta_data,
            "meta_data" => json_encode($this->to_array()),
        ];


        /**
         * 
         * 
         * If agent has set end_time and start time. Take the followup date to be meeting_date.
         */
        if ($this->is_quick_schedule) {
            $params_data['followup_date'] = $this->meeting_date;
        }


        $meeting_type = Meeting_type::find($this->meeting_type_id);

        if ($meeting_type->alias == "site_visit") {
            $lead_activity_type_id = Lead_activity_type::alias_id("site_visit_" . $this->action);
        } else {
            $lead_activity_type_id = Lead_activity_type::alias_id("meeting_" . $this->action);
        }
        $params_data['followup_type_id'] = $lead_activity_type_id;
        $lead_activity = Lead_activity::create($params_data);
        //$this->lead_activity_id=$lead_activity->id;
        /**}**/
    }

    public function update_lead_details()
    {
        $enquiry = Enquiry::find($this->enquiry_id);
        $this->lead_name = $enquiry->name;
    }

    public function update_agent_details()
    {
        if (Session::has_user()) {
            $agent = Agent::find(Session::user("id"));
            if ($agent) {
                $this->agent_name = $agent->first_name . " " . $agent->last_name;
                $this->supervisor_id = $agent->supervisor_id;
                $this->agent_id = $agent->id;
            }
        }
    }


    public static function ajaxfy_sync_projects()
    {
        return;
        $meetings = static::all();

        foreach ($meetings as $meeting) {
            $enquiry = Enquiry::find($meeting->enquiry_id);
            $meeting->project_id = $enquiry->project_id;
            $meeting->save();
        }
    }




    public function update_project_details()
    {
        $enquiry = Enquiry::find($this->enquiry_id);
        $this->project_id = $enquiry->project_id;
        $this->lead_source_id = $enquiry->lead_source_id;
    }


    public function update_meeting_title()
    {
        $meeting_type = Meeting_type::find($this->meeting_type_id);

        $meeting_for = "";
        if ($this->enquiry_id) {
            $enquiry = Enquiry::find($this->enquiry_id);
            $meeting_for = " for " . $enquiry->name;
        }

        $this->title = $meeting_type->title ? $meeting_type->title . " meeting " . $meeting_for : NULL;
    }

    public static function ajaxfy_send_meetings()
    {
        $query = 'SELECT * FROM ' . static::t() . ' WHERE meeting_date LIKE "%' . date("Y-m-d") . '%"';
        $results = static::find_by_sql($query);
        $meetings_sent = [];
        foreach ($results as $result) {
            $meeting_user = Acl_user::find($result->user_id);
            $message = $result->title . " (" . $result->description . ")";
            $meeting = Lead_meeting::find($result->id);
            $meeting->sent_count += 1;
            $meeting->save();
            $meeting_phone = $meeting_user->phone;
            //$meeting_phone="0729934932";
            $meetings_sent[] = $message . " sent to " . $meeting_phone;
            Sms::send($message, $meeting_phone);
        }
        echo implode("\n", $meetings_sent);
    }

    public static function config_site_visit_completed($vars)
    {
        ini_set("display_errors", "On");
        error_reporting(1);

        $config = static::config($vars);
        $config['conditions'] = ["account_id=? 
        AND action='checkout' 
        AND meeting_type_id=?", Acl_user::account_id(), Meeting_type::alias_id("site_visit_checkout")];
        return $config;
    }

    public static function config_site_visit_scheduled($vars)
    {
        $config = static::config($vars);
        $config['filter_date'] = "meeting_date";
        $config['conditions'] = ["account_id=? AND action='scheduling' AND meeting_type_id=?", Acl_user::account_id(), Meeting_type::alias_id("site_visit")];
        return $config;
    }


    public static function fields_config()
    {
        if (static::$model_id) {
            $lead_meeting = Lead_meeting::find(static::$model_id);
            $enquiry_id = $lead_meeting->enquiry_id;
            $conditions = ["account_id=? AND id=" . $enquiry_id, Acl_user::account_id()];
        } else {
            $conditions = ["account_id=?", Acl_user::account_id()];
        }
        $fields_config = array(
            "meeting_type_id" => array(
                "label" => "Activity For",
                "model" => ["Meeting_type", "id", "title", ["conditions" => ["account_id=?", Acl_user::account_id()]]], "required" => true
            ),
            "enquiry_id" => array("label" => "Lead", "model" => [
                "Enquiry", "id", "name",
                ["prepend" => ["" => "-Select Client-"], "limit" => 500, "conditions" => $conditions]
            ]),
            "project_id" => array(
                "label" => "Project",
                "model" => ["Project", "id", "title", ["conditions" => ["account_id=?", Acl_user::account_id()]]], "required" => true
            ),
            "lead_source_id" => array(
                "label" => "Lead Source",
                "model" => ["Lead_source", "id", "title"], "required" => true
            ),

            /**"supervisor_id" => array("label" => "Supervisor", "model" => ["Acl_user", "id", ["first_name", "last_name"], [
                "prepend" => ["" => "-Select Supervisor-"],
                "conditions" => ["account_id=? AND role_id=?", Acl_user::account_id(), Role::alias_id("supervisor")]
            ]]),**/

            //"lead_name"=>array("label"=>"Lead Name","required"=>true),               
            "meeting_date" => array("required" => true, "label" => "Activity Date", "type" => "date"),
            "start_time" => array("required" => true, "label" => "Activity Time", "params" => hours_range()),
            //"end_time" => array("required" => true, "label" => "End Time", "params" => hours_range()),
            /**"lead_interest_level_id" => array(
                "label" => "Interest Level",
                "model" => ["Lead_interest_level", "id", "title"], "required" => true
            ),**/
            "meeting_location" => array("required" => true, "label" => "Activity Location"),
            //"status"=>array("label"=>"Status","required"=>true),
            //"description" => array("label" => "Additional Note", "required" => true),
        );

        if (Session::user()->role->alias == "supervisor" || Session::user()->role->alias == "admin") {
            $fields_config["agent_id"] = array("label" => "Agent ", "model" => ["Agent", "id", ["first_name", "last_name"], ['conditions' => ['role_id=' . Role::alias_id("agent")]]]);
        }
        return $fields_config;
    }


    public static function config($vars = [])
    {
        $enquiry_id = NULL;

        $config_data = array(
            "limit" => 200,
            "conditions" => ["account_id=? AND deleted=0", Acl_user::account_id()],
            "filters" => 1,
            "fields" => static::fields(['supervisor_id', 'lead_interest_level_id', 'lead_source_id'], false),
            "grid_fields" => static::fields(),
            "grid_actions" => static::grid_actions(['view','delete']),
            "form_actions" => static::form_actions(['save'])
        );
        if (isset($_REQUEST['filter_check'])) {
            $config_data['results'] = static::fetch_all();
        } else {
            $config_data['filter'] = true;
        }
        if (Session::user("account_id") == 2) {
            unset($config_data["fields"]['supervisor_id']);
        }
        //unset($config_data["fields"]['start_time']);
        unset($config_data["fields"]['end_time']);
        if (isset($_REQUEST['enquiry_id'])) {
            $config_data["fields"]["enquiry_id"] = ["label" => "Enquiry", "value" => $_REQUEST['enquiry_id'], "type" => "hidden"];
        }

        if (isset($_REQUEST['agent_id'])) {
            $config_data["fields"]["agent_id"] = ["label" => "Agent", "value" => $_REQUEST['agent_id'], "type" => "hidden"];
        }



        return $config_data;
    }





    public static function fetch_all($filter = NULL, $count = NULL, $alias = NULL)
    {

        $filter_request = isset($_REQUEST['filter_check']) ? $_REQUEST['filter_check'] : $filter;
        $filter = $filter ?: $filter_request;
        $meeting_type_sql = $alias ? " AND meeting_type_id=" . Meeting_type::alias_id($alias) : "";
        if ($filter) {
            if ($filter == "all_planned") {
                $filter_sql = "  AND is_checked_out=0  AND (meeting_date > '" . date("Y-m-d") . "' OR meeting_date LIKE  '%" . date("Y-m-d") . "%') ";
            } elseif ($filter == "planned_today") {
                $filter_sql = " AND is_checked_in=0 AND meeting_date LIKE '%" . date("Y-m-d") . "'";
            } elseif ($filter == "done") {
                $filter_sql = " AND is_checked_out=1";
            } elseif ($filter == "done_today") {
                $filter_sql = " AND is_checked_in=1 AND is_checked_out=1 AND  meeting_date LIKE '%" . date("Y-m-d") . "'";
            } elseif ($filter == "ongoing") {
                $filter_sql = " AND is_checked_out=0 AND is_checked_in=1 AND meeting_date LIKE '%" . date("Y-m-d") . "'";
            } elseif ($filter == "cancelled") {
                $filter_sql = " AND is_cancelled=1 ";
            } elseif ($filter == "rescheduled") {
                $filter_sql = " AND is_rescheduled=1 ";
            } else {
                $filter_sql = " AND " . $filter . "=1 ";
                /**if($filter!="is_closed")
                {
                    $filter_sql.=" AND is_closed=0";
                }**/
            }
        }

        $filter_sql = $filter_sql . $meeting_type_sql;

        if ($count) {

            $sql = "SELECT COUNT(*) AS meetings_count FROM lead_meetings WHERE 
            account_id=" . Session::user('account_id') . " " . $filter_sql;
            $meetings = Lead_meeting::find_by_sql($sql);
            return $meetings[0]->meetings_count;
        } else {
            $sql = "SELECT * FROM lead_meetings WHERE account_id=" . Session::user('account_id') . " " . $filter_sql . " 
        ORDER BY id DESC";
            return Lead_meeting::find_by_sql($sql);
        }
    }



    public static function config_rescheduled($vars = [])
    {
        $config_data = static::config($vars);
        $config_data['results'] = static::fetch_all('is_rescheduled');
        return $config_data;
    }

    public static function config_cancelled($vars = [])
    {
        $config_data = static::config($vars);
        $config_data['results'] = static::fetch_all('is_cancelled');
        return $config_data;
    }

    public static function config_all_planned($vars = [])
    {
        $config_data = static::config($vars);
        $config_data['conditions'] = ['is_checked_in=0 AND meeting_date>=? AND account_id=?', date("Y-m-d"), Session::user("account_id")];

        return $config_data;
    }




    public static function count_checked_in()
    {
        return static::count(
            [
                'order' => 'id DESC',
                'conditions' => ['agent_id=? AND is_checked_in=1 AND is_checked_out=0', Session::user('id')]
            ]
        );
    }

    public static function count_missed()
    {
        return static::count(
            [
                'order' => 'id DESC',
                'conditions' => ['agent_id=? AND is_closed=0 AND meeting_date<?', Session::user('id'), date("Y-m-d")]
            ]
        );
    }

    public static function count_scheduled_for_check_in()
    {
        return static::count(
            [
                'order' => 'id DESC',
                'conditions' => ['agent_id=? AND is_checked_in=0 AND is_checked_out=0  AND meeting_date LIKE "%' . date("Y-m-d") . '%"', Session::user('id')]
            ]
        );
    }

    public static function count_today()
    {
        return static::count(
            [
                'order' => 'id DESC',
                'conditions' => ['agent_id=?  AND is_cancelled=0 AND is_checked_in=0 AND meeting_date LIKE "%' . date("Y-m-d") . '%"', Session::user('id')]
            ]
        );
    }

    public static function count_planned()
    {
        return static::count(
            [
                'order' => 'id DESC',
                'conditions' => ['agent_id=? AND is_checked_in=0 AND meeting_date>=?', Session::user('id'), date("Y-m-d")]
            ]
        );
    }

    public static function count_rescheduled()
    {
        return static::count(
            [
                'order' => 'id DESC',
                'conditions' => ['agent_id=? AND is_rescheduled=1 AND is_checked_in=0 AND meeting_date>=?', Session::user('id'), date("Y-m-d")]
            ]
        );
    }


    public static function count_cancelled()
    {
        return static::count(
            [
                'order' => 'id DESC',
                'conditions' => ['agent_id=? AND is_cancelled=1', Session::user('id')]
            ]
        );
    }

    public static function count_closed()
    {
        return static::count(
            [
                'order' => 'id DESC',
                'conditions' => ['agent_id=? AND is_closed=1', Session::user('id')]
            ]
        );
    }



    public static function bot_save($parameters)
    {
        return "Sample response" . mt_rand();
    }
}
