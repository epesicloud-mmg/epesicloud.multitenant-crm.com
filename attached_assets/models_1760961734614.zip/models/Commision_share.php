<?php
class Commision_share extends Title_description
{
    static $connection='smart_real_estate';
    static $table='commision_shares';
    static $title="Commision Share";
    static $description="(Commision Share)";
    static $before_save=['check_if_exists','add_user_id'];
    static $after_create=['generate_commission'];

    public function add_user_id()
    {
        $this->user_id=$this->shared_to_id;
    }

    public function check_if_exists()
    {
        if(Commision_share::exists(['conditions'=>['user_id=? AND commision_id=?',$this->user_id,$this->commision_id]]))
        {
            json_error("Commission Share Already Exists For Manager");
        }
    }
    
    public function generate_commission()
    {
        $commision=Commision::find($this->commision_id);
        

        $newCommission=Commision::create([
            'account_id'=>$this->account_id,
            'user_id'=>$this->user_id,
            'bill_to'=>$commision->bill_to,
            'commision_date'=>$commision->commision_date,
            'commision_status_type_id'=>Commision_status_type::alias_id('approved')
        ]);
        $total_amount=0;

        foreach($commision->commision_items as $commision_item)
        {
            $amount=$this->percentage*0.01*$commision_item->sale_price;
            Commision_item::create([
                'account_id'=>$this->account_id,
                'commision_id'=>$newCommission->id,
                'user_id'=>$newCommission->user_id,
                'sale_interest_id'=>$commision_item->sale_interest_id,
                'enquiry_id'=>$commision_item->enquiry_id,

                "sale_price"=>$commision_item->sale_price,
                "deposit_paid"=>$commision_item->deposit_paid,
                "unit_id"=>$commision_item->unit_id,

                "amount"=>$amount
            ]);
            
            $total_amount+=$amount;
        }
        $this->amount=$total_amount;
        $this->commision_id=$newCommission->id;
        $this->save();
   }

    public static function config($vars=[])
    {
        return array(
            "fields"=>array(
                "commision_id"=>array("label"=>"Commision","model"=>["Commision",'id',['id']]),
                "shared_to_id"=>array("label"=>"User","model"=>['User','id',['first_name','last_name']]),
                "percentage"=>array("label"=>"Percentage","default"=>"1","type"=>"number","required"=>true),
                "amount"=>array("label"=>"Calculated Amount","readonly"=>true,"type"=>"number"),
            ),

            "grid_actions"=>[]
        );
    }    

    public function get_name()
    {
        return $this->first_name." ".$this->last_name;
    }
    
}