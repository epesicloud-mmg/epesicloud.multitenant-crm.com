<?php
class Nationality extends Title_description
{
    
    static $table='nationalities';
    static $title='Nationality';
    static $connection='smart_real_estate';


}