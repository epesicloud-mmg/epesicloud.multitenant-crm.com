<?php
class User_visited_location extends Location_log
{
    static $title="Visited Locations";
    static $name="Visited Locations";
}