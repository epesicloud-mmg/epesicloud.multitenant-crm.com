<?php

/**
 * Handles User to Groups Many-to-many Lead_activitys
 *
 * User_group Model
 * @author Martin Muriithi <martin@pporting.org>
 * @date 03/19/2015
 *
 **/
class Unit_group_item extends pPort_model
{
    static $connection = 'smart_property';
    static $table = 'unit_group_items';
    static $title = "Unit Pricing Item";


    static $belongs_to = array(
        'project' => array("project", "class_name" => "Project", "foreign_key" => "project_id"),
        'unit_group' => array("unit_group", "class_name" => "Unit_group", "foreign_key" => "unit_group_id")
    );


    public static function config($vars = [])
    {


        return array(
            "fields" => array(
                "item_id" => array("label" => "Rent Item ", 'model' => array('Item', 'id', 'title')),
                "amount" => array("label" => "Amount"),


            ),
            "grid_actions" => []
        );
    }
}
