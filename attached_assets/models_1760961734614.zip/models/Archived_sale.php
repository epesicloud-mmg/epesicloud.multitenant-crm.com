<?php
class Archived_sale extends pPort_model
{
    static $table='archived_sales';
    static $connection='smart_real_estate';

    public static function ajaxfy_clean_phone()
    {
        foreach(static::all(['conditions'=>['phone_fixed=0']]) as $archived_sale)
        {
            $archived_sale->client_phone=str_replace("+","",$archived_sale->client_phone);
            $archived_sale->phone_fixed=1;
            $archived_sale->save();
        }
        
    }

    public static function ajaxfy_fix_prices()
    {
        foreach(static::all() as $archived_sale)
        {
            $archived_sale->sale_price=str_replace(",","",$archived_sale->sale_price);
            $archived_sale->sale_price=str_replace(".00","",$archived_sale->sale_price);
            $archived_sale->total_paid=str_replace(",","",$archived_sale->total_paid);
            $archived_sale->total_paid=str_replace(".00","",$archived_sale->total_paid);
            $archived_sale->save();
        }
        
    }

    public static function ajaxfy_fix_enquiry_id()
    {
        
        foreach(static::all() as $archived_sale)
        {
            //$phone=str_replace("254","",$archived_sale->client_phone);
            $emails=explode(",",$archived_sale->client_email);  
                    
            $enquiries=Enquiry::all(['conditions'=>['email LIKE "%'.$emails[0].'%"']]);
            if(isset($enquiries[0]) && $enquiries[0])
            {
                $archived_sale->enquiry_id=$enquiries[0]->id;
                $archived_sale->save();
            }

            if(isset($emails[1]) AND $archived_sale->enquiry_id==NULL)
            {
                $enquiries=Enquiry::all(['conditions'=>['email LIKE "%'.$emails[1].'%"']]);
                if(isset($enquiries[0]) && $enquiries[0])
                {
                    $archived_sale->enquiry_id=$enquiries[0]->id;
                    $archived_sale->save();
                }
            }  
        }
    }

    public static function ajaxfy_fix_lead_sources()
    {
        
        foreach(static::all(['conditions'=>['enquiry_id>0']]) as $archived_sale)
        {
            $enquiry=Enquiry::find($archived_sale->enquiry_id);
            $archived_sale->lead_source_id=$enquiry->lead_source_id;
            $archived_sale->save();
        }

    }

    public static function ajaxfy_fix_enquiry_id_by_phone()
    {
        
        foreach(static::all() as $archived_sale)
        {
            //$phone=str_replace("254","",$archived_sale->client_phone);
            $phones=explode(",",$archived_sale->client_phone);  
                 
            $phone=str_replace("254","",$phones[0]);
            $enquiries=Enquiry::all(['conditions'=>['phone LIKE "%'.$phone.'%"']]);
            if(isset($enquiries[0]) && $enquiries[0])
            {
                $archived_sale->enquiry_id=$enquiries[0]->id;
                $archived_sale->lead_source_id=$enquiries[0]->lead_source_id;
                $archived_sale->save();
            }

            if(isset($phones[1]) AND $archived_sale->enquiry_id==NULL)
            {
                $phone=str_replace("254","",$phones[1]);                
                $enquiries=Enquiry::all(['conditions'=>['phone LIKE "%'.$phone.'%"']]);
                if(isset($enquiries[0]) && $enquiries[0])
                {
                    $archived_sale->enquiry_id=$enquiries[0]->id;
                    $archived_sale->save();
                }
            }  
        }
    }

    public static function ajaxfy_fix_unit_ids()
    {
        
        foreach(static::all() as $archived_sale)
        {
            $unit=Unit::find_by_title($archived_sale->unit_code);
            if($unit)
            {
                $archived_sale->unit_id=$unit->id;
                $archived_sale->apartment_id=$unit->apartment_id;
                $archived_sale->block_id=$unit->block_id;
                $archived_sale->court_id=$unit->court_id;
                $archived_sale->save();
            }
            
        }
    }

    public static function ajaxfy_customer_type()
    {
        foreach(static::all(['conditions'=>['account_id=?',Acl_user::account_id()]]) as $archived_sale)
        {
            $mode_of_payment=trim($archived_sale->mode_of_payment," ");
           if($mode_of_payment=="cash")
           {
                $archived_sale->customer_type_id=1;
           }
           elseif($mode_of_payment=="Instalment")
           {
                $archived_sale->customer_type_id=3;
           }
           elseif($mode_of_payment=="Mortgage")
           {
            $archived_sale->customer_type_id=2;
           }
            $archived_sale->save();
        }
        
    }

    public static function config($vars=[])
    {
        return array(
            "row_conditional"=>function($result){
                return !Sale_offer::exists(['conditions'=>['archived_sale_id=?',$result->id]]);
            },
            "fields"=>array(
                    //"unit_code"=>array("label"=>"Unit Code"),
                    "name"=>array("label"=>"Name","required"=>true),
                    "email"=>array("label"=>"Email"),
                    "phone"=>array("label"=>"Phone"),
                    "sale_price"=>array("label"=>"Sale Price"),
                    "total_paid"=>array("label"=>"Total Paid"),
                    //"mode_of_payment"=>array("label"=>"Payment Mode"),
                    "unit_id"=>array("label"=>"Unit","model"=>["Unit","id","title",["conditions"=>['account_id=?',Acl_user::account_id()]]]),
                    "project_id"=>array("label"=>"Project","model"=>["Project","id","title",["conditions"=>['account_id=?',Acl_user::account_id()]]]),
                    "court_id"=>array("label"=>"Court","model"=>["Court","id","title",
                        ["prepend"=>[""=>"-Select Court-"],"conditions"=>['account_id=?',Acl_user::account_id()]]]
                    ),
                    
                    "enquiry_id"=>array("label"=>"Enquiry","model"=>["Enquiry","id","name",["conditions"=>['account_id=?',Acl_user::account_id()]]]),
                    "customer_type_id"=>array("label"=>"Customer Type","model"=>["Customer_type","id","title",["conditions"=>['account_id=?',Acl_user::account_id()]]]),
                    
            ),
            "conditions"=>["account_id=".Acl_user::account_id()],
            "grid_actions"=>[
                    "convert_sale_interest"=>[
                        "label"=>"Create BIF",
                        "href"=>Url::batch_panel("Sale_offer/payment_plans/clone/Archived_sale/id/{@id}")

                    ]
                ]
            );
    }

    public static function config_list($vars=[])
    {
        $config_data=static::config($vars);
        unset($config_data['row_conditional']);
        return $config_data;
    }

    public static function config_without_units($vars=[])
    {
        $config=static::config($vars);
        $config['conditions']=['unit_id IS NULL'];
        return $config;
    }

}