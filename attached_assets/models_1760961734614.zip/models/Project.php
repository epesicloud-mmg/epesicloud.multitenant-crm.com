<?php
class Project extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'projects';
    static $title = "Project";
    static $description = "(Manage Projects)";
    static $before_save = array('add_account_creator');
    static $after_save = array('sync_locations_to_unit_group');
    static $belongs_to = [
        "location" => ["location", "class_name" => "Location", "foreign_key" => "location_id"],

    ];

    static $has_many = [

        'enquiries' => ['enquiries', 'class_name' => 'Enquiry', 'foreign_key' => 'project_id'],
        'sale_interests' => ['sale_interests', 'class_name' => 'Sale_interest', 'foreign_key' => 'project_id'],
        'sales' => ['sales', 'class_name' => 'Sale', 'foreign_key' => 'project_id'],
        'sale_payments' => ['sale_payments', 'class_name' => 'Sale_payment', 'foreign_key' => 'project_id', 'summary_metric' => 'SUM(amount)'],


    ];

    public function sync_locations_to_unit_group()
    {
        if (Unit_group::exists(['conditions' => ['project_id=?', $this->id]])) {
            foreach (Unit_group::all(['conditions' => ['project_id=?', $this->id]]) as $unit_group) {
                $unit_group->location_id = $this->location_id;
                $unit_group->save();
            }
        }
    }

    public function add_account()
    {
        $this->account_id = Acl_user::account_id();
        $this->created_by = Session::user('id');
    }

    public static function fields_config()
    {
        $fields = array(
            "photo_1" => array(
                "label" => "Photo (1)",
                "title" => " ",
                "type" => "file",
            ),
            "photo_2" => array(
                "label" => "Photo (2)",
                "title" => " ",
                "type" => "file",
            ),
            "photo_3" => array(
                "label" => "Photo (3)",
                "title" => " ",
                "type" => "file",
            ),
            "photo_4" => array(
                "label" => "Photo (4)",
                "title" => " ",
                "type" => "file",
            ),
            "sale_pipeline_id" => array("label" => "Sale Pipeine", "model" => ["Sale_pipeline", "id", "title"]),


            "title" => array("label" => "Project Name", "required" => true),
            "offer" => array("label" => "Offer Details"),
            "excerpt" => array("label" => "Short Description *", "type" => "textarea"),
            "description" => array("label" => "Project Description *", "type" => "textarea", "class" => "wysiwig form-control"),
            "value_proposition" => array("label" => "Why clients should buy into this service the project?", "type" => "textarea", "class" => "wysiwig form-control"),
            "unit_groups_count" => array("label" => "Service Items", "value" => function ($result) {
                return Unit_group::count(['conditions' => ['project_id=?', $result->id]]);
            }),
            "audience_id" => array(
                "label" => "Marketing List",  'model' => array(
                    'Audience', 'id', 'title', ['order' => 'id ASC']
                ),
            ),
        );






        return $fields;
    }





    public static function config($vars = [])
    {
        if (Session::user()->role->alias == 'admin') {
            $conditions = array("account_id=?", Acl_user::account_id());
        } else {
            $conditions = array("user_id=?", Session::user("id"));
        }
        return array(
            "fields" => static::fields(["photo_1", "photo_2", "photo_3", "photo_4", "sale_pipeline_id", "title", "offer", "excerpt", "description", "value_proposition", "audience_id"]),
            "conditions" => array("account_id=?", Acl_user::account_id()),
            "grid_fields" => static::fields(['title', 'sale_pipeline_id', 'location_id']),
            "cols" => 2,
            "limit" => 30,
            "order" => "id DESC",
            "form_actions" => static::form_actions(),
            "grid_actions" => static::grid_actions(['view', 'delete']),
            "form" => static::form_attrs(),
        );
    }
}
