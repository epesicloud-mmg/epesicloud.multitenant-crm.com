<?php
class Call_type extends Title_description
{
    static $connection = 'smart_real_estate';
    static $table = 'call_types';
    static $title = "Call Types";
}