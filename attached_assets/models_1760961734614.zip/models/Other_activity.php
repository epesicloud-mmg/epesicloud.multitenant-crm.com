<?php

class Other_activity extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'other_activities';
    static $enabled_for_time_range = true;
    static $title = "Other_activity";
    static $description = "(Other_activity)";
    static $before_create = ["add_activity_creator"];
    static $after_create = ["add_to_calendar", "add_followup"];


    public function add_followup()
    {
        //Add to followup
        $activity_data = [
            'followup_date' => date('Y-m-d'),
            'agent_id' => $this->user_id,
            'created_by' => $this->agent_id,
            'account_id' => $this->account_id,
            'followup_type_id' => Followup_type::alias_id_or_create("other_activity"),
            'enquiry_id' => $this->enquiry_id,
            'activity_date' => $this->activity_date,
            'activity_time' => $this->activity_time,
            'description' => $this->description,
            'title' => $this->title,

            'linked_entity' => 'Other_activity',
            'linked_entity_reference' => $this->id,
            'location_meta_data' => $this->location_meta_data,
            "meta_data" => json_encode($this->to_array()),
        ];

        Followup::create($activity_data);
    }

    public function add_activity_creator()
    {
        if (!$this->user_id) {
            if ($this->agent_id) {
                $this->user_id = $this->agent_id;
            } else {
                $this->user_id = Session::user("id");
            }
        } else {
            $this->agent_id = $this->user_id;
        }
    }

    public function add_to_calendar()
    {
        $user_id = $this->user_id ? $this->user_id : $this->agent_id;
        Calendar_item::create(
            [
                'calendar_item_type_id' => Calendar_item_type::alias_id_or_create("other_activity"),
                'linked_entity' => 'Other_activity',
                'linked_entity_id' => $this->id,
                'account_id' => $this->account_id,
                'title' => $this->title,
                'start_date' => $this->activity_date,
                'start_time' => $this->activity_time,
                'created_by' => $user_id
            ]
        );
    }




    public static function fields_config()
    {
        $description = "";
        return array(
            "agent_id"=>array("label"=>"Agent","model"=>['Agent','id',['first_name','last_name']]),                

            "title"=>array("label"=>"Title","required"=>true),                
            "activity_date" => array("required" => true, "label" => "Activity Date", "type" => "date"),
            "activity_time" => array("required" => true, "label" => "Activity Time", "params" => hours_range()),
            "description" => array("label" => "Additional Note", "value" => $description, "required" => true),

        );
    }




    public static function config($vars = [])
    {
        $config_data = array(
            "conditions" => ["account_id=? AND deleted=0", Acl_user::account_id()],
            "fields" => static::fields(),
            "form_actions" => static::form_actions(["save"]),
            "grid_actions"=>static::grid_actions()
        );

        if (isset($_REQUEST['enquiry_id'])) {
            $config_data["fields"]["enquiry_id"] = ["label" => "Enquiry", "value" => $_REQUEST['enquiry_id'], "type" => "hidden"];
        }
        return $config_data;
    }
}