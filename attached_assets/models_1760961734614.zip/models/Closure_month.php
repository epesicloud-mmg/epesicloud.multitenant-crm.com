<?php

class Closure_month extends pPort_model
{
    static $connection = 'smart_real_estate';
    static $table = 'closure_months';
    static $title = "Closure Month";



    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "title" => array("label" => "Title", "required" => true),
                "alias" => array("label" => "Alias", "required" => true),
                "description" => array("label" => "Description", "required" => true),
            ),
        );
    }
}