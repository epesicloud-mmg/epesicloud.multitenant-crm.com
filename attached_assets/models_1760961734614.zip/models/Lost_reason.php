<?php

class Lost_reason extends Title_description
{
    static $connection = 'smart_real_estate';
    static $table = 'lost_reasons';
    static $title = "Lost Reasons";
}