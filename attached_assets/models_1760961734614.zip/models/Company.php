<?php

/**
 *
 * @author <Martin Muriithi> <martin@pporting.org>
 */
class Company extends pPort_model
{

    static $table_name = "companies";
    static $primary_key = "id";
    static $connection = 'smart_real_estate';
    static $before_create = ["check_if_lead_exists"];

    static $title = 'Company';

    static $belongs_to = [
        /**"industry" => [
            "industry", "foreign_key" => "industry_id", "class_name" => "Industry"
        ],**/
    ];

    static $has_many = [
        "contacts" => [
            "contacts", "foreign_key" => "company_id", "class_name" => "Contact"
        ],
        "deals" => [
            "deals", "foreign_key" => "company_id", "class_name" => "Enquiry"
        ]
    ];

    public function check_if_lead_exists()
    {

        $company = Company::find(['conditions' => ['account_id=? AND (name LIKE "%' . $this->name . '%")', Acl_user::account_id()]]);
        if ($company) {
            //$this->errors->add('email', "A company already exists with those details including e-mail  (" . $this->email . ").");
            //exit(json_encode(["info" => "error", "message" => "A company already exists with those details including e-mail  (" . $this->email . ")."]));
        }
        return;


        $post_data = [];

        if ($this->email != NULL && $this->email != "" && $this->email != strtolower(str_replace("/", "", str_replace(" ", "", "NA")))) {
            $company = Company::find(['conditions' => ['account_id=? AND (email LIKE "%' . $this->email . '%")', Acl_user::account_id()]]);
            if ($company) {
                //$this->errors->add('email', "A company already exists with those details including e-mail  (" . $this->email . ").");
                exit(json_encode(["info" => "error", "message" => "A company already exists with those details including e-mail  (" . $this->email . ")."]));
            }
        }


        if ($this->phone != NULL && $this->phone != "" && $this->phone != strtolower(str_replace("/", "", str_replace(" ", "", "NA")))) {
            $last_9_digits_check = $this->phone;
            if (strlen($last_9_digits_check) > 8) {
                $last_9_digits_check = substr($last_9_digits_check, -9);
            }
            $company = Company::find(['conditions' => ['account_id=? AND (phone LIKE "%' . $last_9_digits_check . '%")', Acl_user::account_id()]]);
            if ($company) {
                //$this->errors->add('email', "A company already exists with those details including phone (" . $this->phone . ").");
                exit(json_encode(["info" => "error", "message" => "A company already exists with those details including phone  (" . $this->email . ")."]));
            }
        }
    }

    public static function grid_actions_config()
    {
        return [
            "create_contact" => [
                "text" => function ($result) {
                    return "New Contact (" . count($result->contacts) . ")";
                },
                "href" => function ($result) {
                    return Url::form_panel("Contact/" . $result->id . "/company_id/" . $result->id);
                }
            ],

        ];
    }

    public static function fields_config()
    {
        return [

            "name" => ["label" => "Name", "required" => true, "type" => "text"],

            //"company_id" => ["label" => "Company",  "type" => "text", "model" => ["Company", "id", "name"]],

            "email" => ["label" => "Email",  "type" => "text"],

            "phone" => ["label" => "Phone", "type" => "phone"],

            "industry_id" => ["label" => "Industry",   "required" => true, "model" => ["Industry", "id", "title"]],

            "location" => array("label" => "Location"),

            "contacts_count" => ["label" => "Contacts Count", "href" => function ($result) {
                return Url::report_panel("Contact", ['company_id' => $result->id, "action" => "view"]);
            }, "type" => "text"],

            "enquiries_count" => ["label" => "Opportunities Count", "href" => function ($result) {
                return Url::report_panel("Enquiry", ['company_id' => $result->id, "action" => "view"]);
            },  "type" => "text"],

            "description" => array("label" => "Additional Notes", "type" => "textarea"),

        ];
    }

    public function get_contacts_count()
    {
        return Contact::count(['conditions' => ['company_id=?', $this->id]]);
    }

    public function get_enquiries_count()
    {
        return Enquiry::count(['conditions' => ['company_id=?', $this->id]]);
    }

    public static function config($vars = [])
    {
        $config_data = array(
            "fields" => static::fields(['enquiries_count', 'contacts_count'], false),
            "grid_fields" => static::fields(['description'], false),
            "conditions" => array("account_id=?", Acl_user::account_id()),
            "form" => static::form_attrs(),
            "grid_actions" => static::grid_actions(['view', 'delete']),
            "form_actions" => static::form_actions(['save'])

        );
        return $config_data;
    }
}