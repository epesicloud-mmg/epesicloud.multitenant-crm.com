<?php
class Lead_other_lead_activity extends pPort_model
{
    static $table = 'lead_other_lead_activities';
    static $name = "Other Activity";
    static $title = 'Other Activity';
    static $description = 'Activities';
    static $connection = 'smart_real_estate';



    static $before_create = ['check_lead_email', "add_agent_id"];
    static $after_create = ["add_lead_activity"];

    function add_agent_id()
    {
        if (!$this->agent_id) {
            $this->agent_id = Session::get("user_id");
        }
    }

    function add_lead_activity()
    {
        Lead_activity::create([
            'enquiry_id' => $this->lead_id,
            'followup_type_id' => $this->followup_type_id,
            'description' => $this->description,
            "account_id" => $this->account_id,
            'linked_entity' => 'Lead_other_lead_activity',
            'linked_entity_id' => $this->id,
            'followup_date' => date("Y-m-d"),
            'agent_id' => $this->agent_id,
            'location_meta_data' => $this->location_meta_data,
            "meta_data" => json_encode($this->to_array()),

        ]);
    }


    public function check_lead_email()
    {
        if ($lead = Enquiry::last(['conditions' => ['email=? OR phone =? AND account_id=?', $this->lead_email, $this->lead_phone, Acl_user::account_id()]])) {
            $this->lead_id = $lead->id;
        } else {
            json_error("Lead could not be found");
        }
    }

    public function post_followup()
    {
    }


    public static function config($vars = [])
    {
        return array(
            "fields" => array(
                "followup_type_id" => array("label" => "Followup Type", "model" => array("Followup_type", "id", array("title"))),
                "agent_id" => array("label" => "Agent", "model" => array("Account_executive", "id", array("first_name", "last_name"), ["conditions" => ['account_id=?', Session::user('account_id')]])),
                "lead_email" => array("label" => "Lead Email", "type" => "email"),
                "lead_phone" => array("label" => "Lead Phone", "type" => "phone"),
                "lead_activity_date" => array("label" => "Followup Date", "type" => "date"),
                "description" => array("label" => "Notes", "type" => "textarea"),
            ),
            "form_actions" => static::form_actions(['save']),
        );
    }
}